/**
 * Cutting Length Service
 *
 * Determines the recommended PT cut length (SetLen) for the HORUS machine controller.
 * Ported from VB6: Set_Length_Automatically() and Ptflawallocation()
 */

const { getConnection } = require('../config/db');
const { PLANTS } = require('../constants');

/**
 * Get standard cut length from CUTTING_LOGIC table by tower number
 * @param {number} towerNo
 * @param {string} plant
 * @param {object} conn
 * @returns {number} standard length in km
 */
async function getStandardLength(towerNo, plant, conn) {
  let standardLen = 50.85; // default

  const result = await conn.execute(
    `SELECT LENGTH FROM CUTTING_LOGIC WHERE TWNO = :towerNo`,
    { towerNo: String(towerNo) }
  );

  if (result.rows.length > 0) {
    const dbLen = result.rows[0].LENGTH;
    const isWaluj = plant === PLANTS.WALUJ;

    const lengthMap = isWaluj
      ? {
          48.8: 49.15,
          50.4: 50.85,
          24.4: 24.75,
          25.2: 25.6,
          54.6: 59.2,
          58.8: 59.2,
        }
      : {
          48.8: 49.3,
          50.4: 50.85,
          24.4: 24.8,
          25.2: 25.6,
          54.6: 59.2,
          58.8: 59.2,
        };

    if (lengthMap[dbLen] !== undefined) {
      standardLen = lengthMap[dbLen];
    }
  }

  return standardLen;
}

/**
 * Check if PT-50km bobbin is eligible based on recent quality indicators
 * Ported from VB6: ChkPT50()
 * @param {string} drawId
 * @param {number} balQtyM - balance in metres
 * @param {number} fault   - fault position in metres from current end
 * @param {object} conn
 * @returns {boolean} true if 50km bobbin is eligible
 */
async function checkPT50Eligible(drawId, balQtyM, fault, conn) {
  let pt50Flag = true;
  const towerSubstr = drawId.substring(8, 10);

  if (balQtyM < 50600) return false;

  // Check break rate in last 3 days for this tower
  const breakRateResult = await conn.execute(
    `SELECT ROUND((SUM(NBREAK)/SUM(OKLEN+SCRAP1+SCRAP2))*100,3) AS BRKRATE
     FROM PT
     WHERE PRODDATE BETWEEN SYSDATE-3 AND SYSDATE
       AND SUBSTR(FID,1,1) IN ('I','P')
       AND SUBSTR(FID,9,2) = :towerNo`,
    { towerNo: towerSubstr }
  );
  if (breakRateResult.rows[0]?.BRKRATE >= 2) return false;

  // Check draw yield over last 7 days
  const drawKmResult = await conn.execute(
    `SELECT SUM(DRLEN) AS TOTALKM FROM DRAW
     WHERE PDATE BETWEEN SYSDATE-7 AND SYSDATE
       AND SUBSTR(FID,1,1) IN ('I','P')
       AND SUBSTR(FID,9,2) = :towerNo`,
    { towerNo: towerSubstr }
  );
  const drawnKm = drawKmResult.rows[0]?.TOTALKM || 0;

  const optOkResult = await conn.execute(
    `SELECT SUM(OPTLEN) AS OPTOK FROM PTFIBRE
     WHERE TESTDATE BETWEEN SYSDATE-7 AND SYSDATE
       AND SUBSTR(FID,1,1) IN ('I','P')
       AND MATNO = '330000127'
       AND GRADE NOT IN ('REW','FAIL','D','CATV','CATV-SL','MECH','AOTDR','BOTDR')
       AND SUBSTR(FID,9,2) = :towerNo`,
    { towerNo: towerSubstr }
  );
  const optOk = (optOkResult.rows[0]?.OPTOK || 0) / 1000;

  if (drawnKm > 0 && (optOk / drawnKm) < 0.6) return false;

  // Check last 2 entries for continuous breaks
  const lastEntriesResult = await conn.execute(
    `SELECT OKLEN, SCRAP1, SCRAP2, NBREAK, FLAG50
     FROM (SELECT * FROM PT WHERE FID = :drawId ORDER BY PRODDATE DESC)
     WHERE ROWNUM < 3`,
    { drawId }
  );
  let brkCnt = 0;
  let ptSum = 0;
  for (const row of lastEntriesResult.rows) {
    brkCnt += (row.NBREAK || 0);
    ptSum += (row.OKLEN || 0);
  }
  if (brkCnt >= 4) return false;

  // Check total scrap
  const scrapResult = await conn.execute(
    `SELECT SUM(SCRAP1+SCRAP2) AS TOTALSCRAP FROM PT
     WHERE PTID LIKE :pattern`,
    { pattern: drawId.substring(0, 11) + '%' }
  );
  if ((scrapResult.rows[0]?.TOTALSCRAP || 0) > 10) return false;

  // Re-check: if 2 consecutive 24.4km bobbins with no breaks → allow 50km
  if (!pt50Flag) {
    if (ptSum > 24.4 && brkCnt === 0) pt50Flag = true;
  }

  return pt50Flag;
}

/**
 * Calculate recommended PT cut length
 * Ported from VB6: Set_Length_Automatically()
 *
 * @param {object} params
 * @param {string} params.drawId
 * @param {string} params.plant
 * @param {string} params.productType
 * @param {number} params.balQtyM         - balance quantity in metres
 * @param {number} params.drQtyM          - total draw quantity in metres
 * @param {number} params.bottomScrapM    - bottom scrap in metres
 * @param {string} params.flawMsg         - current flaw message (e.g. 'NEXT PITCH CHANGE AT 5.2 KM')
 * @param {number} params.nextFlawPosKm   - next flaw position in km from current pos
 * @param {number} params.cuttingLenKm    - cutting len from flaw grid
 * @param {number} params.totalPTDoneKm   - total PT done so far in km
 * @param {boolean} params.scratchFlag    - scratch observation flag
 * @param {boolean} params.isPTContBrkFlag - continuous break flag (1=3brks, 2=after3brks)
 * @param {boolean} params.isFlagPMD      - ZTPMD mode flag
 * @param {number} params.bobbinLength    - max bobbin length (km), from config
 * @param {string} params.barcodeId       - barcode ID (for reliability sample check)
 * @param {string} params.ptId            - current PTID
 * @param {boolean} params.tagDrrej       - draw rejection tag
 * @returns {{ setLen: number, standardLen: number, goForSample: boolean }}
 */
async function calculateCuttingLength(params) {
  const {
    drawId, plant, productType,
    balQtyM, drQtyM, bottomScrapM,
    flawMsg = '', nextFlawPosKm = 0,
    cuttingLenKm = 0,
    totalPTDoneKm = 0,
    scratchFlag = false,
    isPTContBrkFlag = 0,
    isFlagPMD = false,
    bobbinLength = 52,
    barcodeId = '',
    ptId = '',
    tagDrrej = false,
  } = params;

  const conn = await getConnection();
  try {
    const towerNo = parseInt(drawId.substring(8, 10)) || 0;
    const drawPrefix = drawId[0]?.toUpperCase();
    const balKm = balQtyM / 1000;
    const drKm = drQtyM / 1000;
    const bsKm = bottomScrapM / 1000;

    // K/D/L/Q/A type → standard 26 km
    const shortLenPrefixes = ['K', 'D', 'L', 'Q', 'A'];
    let standardLen = shortLenPrefixes.includes(drawPrefix)
      ? 26
      : await getStandardLength(towerNo, plant, conn);

    // Override for SHENDRA L1 product type
    if (plant === PLANTS.SHENDRA && productType === 'L1') {
      standardLen = 24.8;
    }

    let setLen = standardLen;
    let goForSample = nextFlawPosKm >= 2 ? 1 : 0;
    let cutFlag = 0;

    // Determine SetLen based on flaw message and plant
    if (plant === PLANTS.WALUJ) {
      if (flawMsg.startsWith('CUT')) {
        setLen = cuttingLenKm;
        goForSample = 0;
        cutFlag = 1;
      } else if (flawMsg.startsWith('NEXT')) {
        if (nextFlawPosKm < 4.6) {
          setLen = 4.6;
        } else if (nextFlawPosKm >= standardLen) {
          setLen = standardLen;
        } else {
          setLen = nextFlawPosKm - 0.15;
        }
      } else {
        setLen = standardLen;
        if (scratchFlag && totalPTDoneKm === 0) setLen = 4.2;
        const balMinusBs = balKm - bsKm;
        if (balMinusBs <= standardLen && balMinusBs >= 4.2) {
          setLen = balMinusBs;
        }
      }
    } else {
      // SHENDRA / MEDAK
      if (flawMsg.startsWith('CUT')) {
        setLen = cuttingLenKm;
        goForSample = 0;
        cutFlag = 1;
      } else {
        setLen = standardLen;
        if (scratchFlag && totalPTDoneKm === 0) setLen = 4.2;
        const balMinusBs = balKm - bsKm;
        if (balMinusBs <= standardLen && balMinusBs >= 4.2) {
          setLen = balMinusBs;
        }
        if (nextFlawPosKm < 26) {
          setLen = 25.6;
        } else if (nextFlawPosKm > 38.6 && nextFlawPosKm < 50.85) {
          setLen = 25.6;
        }
      }
    }

    // Continuous break override
    if (isPTContBrkFlag === 1 || isPTContBrkFlag === 2) {
      setLen = 4.2;
      goForSample = 0;
    }

    // ZTPMD override
    if (isFlagPMD) {
      setLen = 0.22;
      goForSample = 0;
    }

    // WALUJ: PREFORM_END first bobbin check
    if (plant === PLANTS.WALUJ && !isFlagPMD && cutFlag === 0) {
      if (nextFlawPosKm > 12.6) {
        const preformResult = await conn.execute(
          `SELECT PRREMARKS FROM DRAW WHERE FID = :drawId`,
          { drawId }
        );
        if (preformResult.rows[0]?.PRREMARKS === 'PREFORM_END') {
          const okResult = await conn.execute(
            `SELECT COUNT(*) AS CNT FROM PT WHERE FID = :drawId AND OKLEN > 0`,
            { drawId }
          );
          if ((okResult.rows[0]?.CNT || 0) === 0) {
            setLen = 12.75;
            goForSample = 0;
          }
        }
      }

      // WALUJ: Long PTID (12-char) first sample check
      if ((ptId || '').length === 12 && nextFlawPosKm > 12.6) {
        const firstAResult = await conn.execute(
          `SELECT COUNT(*) AS CNT FROM PT
           WHERE PTID LIKE :pattern AND OKLEN > 0 AND SUBSTR(PTID,12,1) = 'A'`,
          { pattern: drawId + '%' }
        );
        if ((firstAResult.rows[0]?.CNT || 0) === 0) {
          setLen = 17;
          goForSample = 0;
        }
      }

      // WALUJ length adjustments for 12-char PTID
      if ((ptId || '').length === 12) {
        const lastChar = ptId[11];
        if (lastChar === 'A' || lastChar === 'B') {
          if (setLen > 26) setLen = 25.4;
        }
      }
      if (balKm < 76 && setLen > 26) setLen = 25.4;

      // Avoid awkward middle lengths (38-50 km range)
      if (setLen > 38.2 && setLen < 50.45) {
        if (setLen - 25.45 >= 12.7) setLen = 25.6;
      }
    } else if (cutFlag === 0) {
      // SHENDRA length adjustments
      if (setLen > 38.2 && setLen < 50.45) {
        if (setLen - 25.45 >= 12.7) setLen = 25.6;
      }

      // SHENDRA: first bobbin check
      if (plant === PLANTS.SHENDRA && cutFlag === 0) {
        if (balQtyM === drQtyM) {
          setLen = 12.75;
          goForSample = 0;
        }
        const firstAResult = await conn.execute(
          `SELECT COUNT(*) AS CNT FROM PT
           WHERE PTID LIKE :pattern AND OKLEN > 0 AND SUBSTR(PTID,12,1) = 'A'`,
          { pattern: drawId + '%' }
        );
        if ((firstAResult.rows[0]?.CNT || 0) === 0) {
          setLen = 12.75;
          goForSample = 0;
        }
      }
    }

    // E1 product type: complex multi-bobbin length logic
    if (productType === 'E1' && setLen >= 12.6 && bobbinLength < 100) {
      if (balKm < 76) {
        setLen = 50.85;
        if (balKm < 76 && setLen > 26) setLen = 25.4;

        if (balKm <= 50) {
          const bobbinsDone = await conn.execute(
            `SELECT COUNT(*) AS CNT FROM PT
             WHERE FID = :drawId AND OKLEN > 4.2 AND FACTOR <= 50`,
            { drawId }
          );
          const bobbinPrefend = bobbinsDone.rows[0]?.CNT || 0;

          if (bobbinPrefend === 0) {
            setLen = 25.75;
            const remainder = balKm - 25.75 - bsKm;
            if (remainder <= 0) {
              setLen = Math.max(balKm - bsKm, bsKm);
            }
            if (flawMsg.startsWith('NEXT')) {
              if (nextFlawPosKm < 4.6) setLen = 4.6;
              else if (nextFlawPosKm >= setLen) setLen = setLen;
              else setLen = nextFlawPosKm - 0.15;
            }
          } else if (bobbinPrefend >= 1) {
            setLen = 13;
            const remainder = balKm - 13 - bsKm;
            if (remainder <= 0) {
              setLen = Math.max(balKm - bsKm, bsKm);
            }
            if (flawMsg.startsWith('NEXT')) {
              if (nextFlawPosKm < 4.6) setLen = 4.6;
              else if (nextFlawPosKm >= setLen) setLen = setLen;
              else setLen = nextFlawPosKm - 0.15;
            }
          }
        }
      }
    }

    // PT_CUTTING_LOGIC table: final override by product type + plant + range
    const ptCutResult = await conn.execute(
      `SELECT LENGTH FROM PT_CUTTING_LOGIC
       WHERE PLANT = :plant AND PRODUCT_TYPE = :productType
         AND :setLen >= MIN_VAL AND :setLen <= MAX_VAL
       ORDER BY EDATE DESC`,
      {
        plant: plant.toUpperCase(),
        productType: productType.toUpperCase(),
        setLen,
      }
    );
    if (ptCutResult.rows.length > 0) {
      const tableLen = ptCutResult.rows[0].LENGTH;
      if (tableLen !== null && tableLen <= bobbinLength) {
        setLen = tableLen;
      }
    }

    // Reliability sample check
    if (goForSample === 1 && barcodeId && !tagDrrej) {
      const relSample = await checkReliabilitySample(barcodeId, ptId, conn);
      if (relSample) {
        setLen = plant === PLANTS.WALUJ ? 0.2 : 0.5;
      }
    }

    return {
      setLen: Math.round(setLen * 1000) / 1000,
      standardLen: Math.round(standardLen * 1000) / 1000,
      goForSample: goForSample === 1,
    };
  } finally {
    await conn.close();
  }
}

/**
 * Check if a reliability sample is required for this barcode/PTID
 * Queries pt_inst_ztpmd for pending samples
 * @param {string} barcodeId
 * @param {string} ptId
 * @param {object} conn
 * @returns {boolean}
 */
async function checkReliabilitySample(barcodeId, ptId, conn) {
  // Simplified: actual VB6 called Check_Sample_For_Reliability() which is in a module
  // Placeholder – check against pt_inst_ztpmd for pending tests
  const result = await conn.execute(
    `SELECT COUNT(*) AS CNT FROM PT_INST_ZTPMD
     WHERE BARCODEID = :barcodeId AND STATUS IS NULL`,
    { barcodeId }
  );
  return (result.rows[0]?.CNT || 0) > 0;
}

module.exports = {
  calculateCuttingLength,
  getStandardLength,
  checkPT50Eligible,
};
