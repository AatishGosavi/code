/**
 * Draw Spool Service
 * Handles loading of spool data: stock, flaws, pitch changes, previous PT log
 */

const { getConnection } = require('../config/db');

/**
 * Load draw spool details from MATSTOCK and DRAW tables
 * @param {string} drawId
 * @returns {object} spool details
 */
async function loadSpoolDetails(drawId) {
  const conn = await getConnection();
  try {
    // Validate spool exists in MATSTOCK with available stock
    const stockResult = await conn.execute(
      `SELECT MATNO, ID, STOCKQTY, PTYPE, CREATEDATE, PLANT
       FROM MATSTOCK
       WHERE PROCESS = 'DRAW' AND ID = :drawId AND STOCKQTY > 0`,
      { drawId }
    );
    if (stockResult.rows.length === 0) {
      throw new Error(`Draw ID ${drawId} not found or out of stock`);
    }
    const stockRow = stockResult.rows[0];

    // Load draw movement quantity (original draw quantity)
    const moveResult = await conn.execute(
      `SELECT QTY FROM MATMOVE WHERE PROCESS = 'DRAW' AND ID = :drawId`,
      { drawId }
    );
    const drawQty = moveResult.rows.length > 0 ? moveResult.rows[0].QTY * 1000 : 0;

    // Load draw table details
    const drawResult = await conn.execute(
      `SELECT BOTSCRAP, PRREMARKS, WINDING, APPEAR, DRLEN,
              ATTN1310, ATTN1550, CUTOFF, MFD, CLADO,
              PT_INSTR, COATTYPE, SCR_OBS, DRAW_BARCODEID,
              MAINSPOOL, NEWMAINSPOOL_NO, PRODUCT_TYPE
       FROM DRAW
       WHERE MATNO = '330000126' AND FID = :drawId`,
      { drawId }
    );

    const drawData = drawResult.rows.length > 0 ? drawResult.rows[0] : {};

    // Detect SSRC / LUVANTIX coating flags
    const coatType = (drawData.COATTYPE || '').toUpperCase();
    const ssrcCoatFlag = coatType.startsWith('SSRC');
    const luvantixCoatFlag = coatType.includes('LUVANTIX');
    const scratchFlag = drawData.SCR_OBS === 'YES';

    return {
      matNo: stockRow.MATNO,
      drawId,
      balanceQty: stockRow.STOCKQTY * 1000,      // metres
      drawQty,                                     // metres (original)
      ptype: stockRow.PTYPE || (drawId[0] || ''),
      createDate: stockRow.CREATEDATE,
      plant: stockRow.PLANT,
      bottomScrap: (drawData.BOTSCRAP || 0) * 1000,
      prRemarks: drawData.PRREMARKS || '',
      coatType: drawData.COATTYPE || '',
      ssrcCoatFlag,
      luvantixCoatFlag,
      drawBarcodeId: drawData.DRAW_BARCODEID || '',
      newMainSpoolNo: drawData.NEWMAINSPOOL_NO || '',
      scratchFlag,
      productType: drawData.PRODUCT_TYPE || '',
      ptInstruction: drawData.PT_INSTR || '',
    };
  } finally {
    await conn.close();
  }
}

/**
 * Load flaw records for a draw spool from DRAWFLAW table
 * @param {string} drawId
 * @param {number} drQtyKm - total draw quantity in km
 * @returns {Array} list of flaw objects with position in km from start
 */
async function loadDrawFlaws(drawId, drQtyKm) {
  const conn = await getConnection();
  try {
    const result = await conn.execute(
      `SELECT POSITION, POSITION1, REMARK
       FROM DRAWFLAW
       WHERE FID = :drawId
       ORDER BY POSITION DESC`,
      { drawId }
    );

    return result.rows.map(row => ({
      positionKmFromEnd: row.POSITION,
      positionKmFromStart: drQtyKm - row.POSITION,
      position1KmFromEnd: row.POSITION1,
      remark: row.REMARK || '',
    }));
  } finally {
    await conn.close();
  }
}

/**
 * Load pitch change segments for a draw spool
 * @param {string} drawId
 * @param {number} drQtyKm - total draw length in km
 * @returns {Array} pitch change segments
 */
async function loadPitchChanges(drawId, drQtyKm) {
  const conn = await getConnection();
  try {
    const result = await conn.execute(
      `SELECT PITCH_START, PITCH_END, PITCH_REASON, PITCH_STOP, PITCH_CUT
       FROM DRAWPITCHCHANGE
       WHERE FID = :drawId
       ORDER BY PITCH_START ASC`,
      { drawId }
    );

    const segments = [];
    let prevEnd = 0;
    const towerNo = parseInt(drawId.substring(8, 10)) || 0;

    for (const row of result.rows) {
      if (row.PITCH_START - prevEnd > 4.2 || segments.length === 0) {
        // Determine stop-gap based on tower number
        let stopGap = 0.25;
        if (towerNo >= 20 && towerNo < 40) stopGap = 0.35;
        else if (towerNo >= 40) stopGap = 0.4;

        const fromKm = drQtyKm - row.PITCH_START + stopGap;
        const toKm = row.PITCH_END > 0 ? drQtyKm - row.PITCH_END : fromKm - 0.4;
        const cuttingLen = Math.max(0, Math.round((fromKm - toKm) * 100) / 100);

        segments.push({
          index: segments.length + 1,
          fromKm,
          toKm: toKm < 0 ? 0 : toKm,
          reason: row.PITCH_REASON || 'PITCHCHANGE',
          pitchStopped: row.PITCH_STOP === 'Y',
          pitchCut: row.PITCH_CUT === 'Y',
          cuttingLen,
          pitchStart: row.PITCH_START,
          pitchEnd: row.PITCH_END,
        });
      } else {
        // Extend previous segment's end
        const last = segments[segments.length - 1];
        if (row.PITCH_END > 0) last.toKm = drQtyKm - row.PITCH_END;
      }
      prevEnd = row.PITCH_END;
    }

    return segments;
  } finally {
    await conn.close();
  }
}

/**
 * Load previous PT entries for a draw spool (summary for log display)
 * @param {string} drawId
 * @returns {Array}
 */
async function loadPreviousPTLog(drawId) {
  const conn = await getConnection();
  try {
    const result = await conn.execute(
      `SELECT PTID, OKLEN, SCRAP1, SCRAP2, DRREJ, NBREAK, SAMPLE_NO, PRODDATE
       FROM PT
       WHERE PTID LIKE :drawIdPattern
       ORDER BY PRODDATE`,
      { drawIdPattern: drawId + '%' }
    );
    return result.rows;
  } finally {
    await conn.close();
  }
}

/**
 * Load allocated spool for a PT machine
 * @param {number} machineNo
 * @returns {{ spoolId: string, priority: string } | null}
 */
async function getAllocatedSpool(machineNo) {
  const conn = await getConnection();
  try {
    const result = await conn.execute(
      `SELECT SPOOL_ID, PRIORITY FROM PT_ALLOCATION
       WHERE MCNO = :machineNo
       ORDER BY PRIORITY`,
      { machineNo }
    );
    if (result.rows.length === 0) return null;
    return { spoolId: result.rows[0].SPOOL_ID, priority: result.rows[0].PRIORITY };
  } finally {
    await conn.close();
  }
}

/**
 * Update allocation priority from '2' to '1' after spool is loaded
 * @param {number} machineNo
 * @param {object} conn - existing connection (for transaction)
 */
async function resetAllocationPriority(machineNo, conn) {
  await conn.execute(
    `UPDATE PT_ALLOCATION SET PRIORITY = '1'
     WHERE MCNO = :machineNo AND PRIORITY = '2'`,
    { machineNo }
  );
}

/**
 * Get product type for a draw ID from multiple source tables
 * @param {string} drawId
 * @param {object} conn
 * @returns {string} product type or ''
 */
async function getProductType(drawId, conn) {
  // Try DRAW table first
  let result = await conn.execute(
    `SELECT PRODUCT_TYPE FROM DRAW WHERE PREID = :preid`,
    { preid: drawId.substring(0, 8) }
  );
  if (result.rows.length > 0 && result.rows[0].PRODUCT_TYPE) {
    return result.rows[0].PRODUCT_TYPE;
  }

  // Try COREDEP
  result = await conn.execute(
    `SELECT PRODUCT_TYPE FROM COREDEP
     WHERE PREID = :preid AND PRODUCT_TYPE IS NOT NULL`,
    { preid: drawId.substring(0, 7) }
  );
  if (result.rows.length > 0 && result.rows[0].PRODUCT_TYPE) {
    return result.rows[0].PRODUCT_TYPE;
  }

  // Try RIC_PREFORM_ASSEMBLY
  result = await conn.execute(
    `SELECT PROD_TYPE FROM RIC_PREFORM_ASSEMBLY
     WHERE PREID = :preid AND PROD_TYPE IS NOT NULL`,
    { preid: drawId.substring(0, 8) }
  );
  if (result.rows.length > 0 && result.rows[0].PROD_TYPE) {
    return result.rows[0].PROD_TYPE;
  }

  return '';
}

module.exports = {
  loadSpoolDetails,
  loadDrawFlaws,
  loadPitchChanges,
  loadPreviousPTLog,
  getAllocatedSpool,
  resetAllocationPriority,
  getProductType,
};
