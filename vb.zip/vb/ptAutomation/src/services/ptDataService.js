/**
 * PT Data Service  –  savePTEntry()
 *
 * Full port of VB6 Storedata() function.
 * Handles every table write in the correct order, including:
 *   - SPOS / EPOS calculation
 *   - FACTOR / POS calculation
 *   - SAMPLE_NO logic (F / L / sequential)
 *   - DRAW_INFO / DRAW_CLAD / DRAW_AIR zone overlap
 *   - PT25TRACKING / PT50TRACKING
 *   - PRODREPORT_DRAW / PRODREPORT upserts
 *   - PTBARCODE with RELLEN / PREFPOS
 *   - PTCOLOR
 *   - PTIME_LOSS
 *   - RIC Preform Rod tracking (post-commit)
 *   - MATSTOCK reduce + MATMOVE 261 / 551 / 101
 */

'use strict';

const { getConnection } = require('../config/db');
const { generatePTID, getMaterialNo, getShift } = require('../utils/helpers');
const { MOVETYPE, MC_SPEED } = require('../constants');

/**
 * Determine minimum acceptable PT length (metres) based on draw prefix.
 * @param {string} drawPrefix
 * @returns {number}
 */
function getMinLen(drawPrefix) {
  if (['D', 'N', 'A', 'Q'].includes(drawPrefix)) return 4250;
  if (['M', 'R'].includes(drawPrefix)) return 2200;
  return 4200;
}

/**
 * Compute PT_25 bucket (used in production report).
 * @param {number} ptLenM  metres
 * @returns {number}  0 / 25.2 / 50.4 / 58.8
 */
function getPT25Bucket(ptLenM) {
  if (ptLenM >= 58900) return 58.8;
  if (ptLenM >= 50550) return 50.4;
  if (ptLenM >= 25350) return 25.2;
  return 0;
}

/**
 * Calculate TimeLoss and SpeedLoss from machine timestamps.
 *
 * @param {Date} machineStopDT   d1t1 – this stop event datetime
 * @param {Date} prevStopDT      d2t2 – previous stop event datetime
 * @param {Date} machineStartDT  d3t3 – machine start datetime
 * @param {number} ptLenM        actual PT length metres
 * @param {number} machineNo
 * @param {boolean} isBEScrap    Check2 flag (BE Scrap disables time calc)
 * @returns {{ timeLoss: number, speedLoss: number }}
 */
function calcTimeLoss(machineStopDT, prevStopDT, machineStartDT, ptLenM, machineNo, isBEScrap) {
  if (isBEScrap) return { timeLoss: 0, speedLoss: 0 };

  const timeLossRaw = (machineStartDT - prevStopDT) / 60000; // ms → minutes
  const timeLoss = (timeLossRaw > 10000 || timeLossRaw < 0) ? 0 : Math.round(timeLossRaw * 1000) / 1000;

  const bobbinActTime = (machineStopDT - machineStartDT) / 60000;
  const speed = machineNo >= 20 ? MC_SPEED.HIGH : MC_SPEED.DEFAULT;
  const bobbinIdleTime = Math.round((ptLenM / speed) * 1000) / 1000;
  const speedLossRaw = bobbinActTime - bobbinIdleTime;
  const speedLoss = (speedLossRaw > 10000 || speedLossRaw < 0) ? 0 : Math.round(speedLossRaw * 1000) / 1000;

  return { timeLoss, speedLoss };
}

/**
 * Fetch product type from DRAW, COREDEP, RIC_PREFORM_ASSEMBLY (in priority order).
 * Mirrors the VB6 sequence in Storedata().
 *
 * @param {string} drawId
 * @param {object} conn
 * @returns {string}
 */
async function resolveProductType(drawId, conn) {
  // 1. DRAW table (preid = first 8 chars)
  let r = await conn.execute(
    `SELECT PRODUCT_TYPE FROM DRAW WHERE PREID = :p`,
    { p: drawId.substring(0, 8) }
  );
  if (r.rows.length && r.rows[0].PRODUCT_TYPE) return r.rows[0].PRODUCT_TYPE;

  // 2. COREDEP.PRODUCT_TYPE_E (preid = first 7 chars)
  r = await conn.execute(
    `SELECT PRODUCT_TYPE_E FROM COREDEP
     WHERE PREID = :p AND PRODUCT_TYPE_E IS NOT NULL`,
    { p: drawId.substring(0, 7) }
  );
  if (r.rows.length && r.rows[0].PRODUCT_TYPE_E) return r.rows[0].PRODUCT_TYPE_E;

  // 3. COREDEP.PRODUCT_TYPE (preid = first 7 chars)
  r = await conn.execute(
    `SELECT PRODUCT_TYPE FROM COREDEP
     WHERE PREID = :p AND PRODUCT_TYPE IS NOT NULL`,
    { p: drawId.substring(0, 7) }
  );
  if (r.rows.length && r.rows[0].PRODUCT_TYPE) return r.rows[0].PRODUCT_TYPE;

  // 4. RIC_PREFORM_ASSEMBLY (preid = first 8 chars)
  r = await conn.execute(
    `SELECT PROD_TYPE FROM RIC_PREFORM_ASSEMBLY
     WHERE PREID = :p AND PROD_TYPE IS NOT NULL`,
    { p: drawId.substring(0, 8) }
  );
  if (r.rows.length && r.rows[0].PROD_TYPE) return r.rows[0].PROD_TYPE;

  return '';
}

/**
 * Load RIC Preform Assembly rod data if available.
 * Used to determine which preform rod a bobbin comes from.
 *
 * @param {string} drawId
 * @param {object} conn
 * @returns {{ ricPrefFlag: boolean, rods: Array<{id:string, cumulativeKm:number}> }}
 */
async function loadRICAssembly(drawId, conn) {
  const r = await conn.execute(
    `SELECT PREFWT, RODASSEMBLYWT, NO_ROD_USED,
            ROD1_WT, ROD1_ID, ROD2_WT, ROD2_ID, ROD3_WT, ROD3_ID,
            ROD4_WT, ROD4_ID, ROD5_WT, ROD5_ID, ROD6_WT, ROD6_ID,
            ROD7_WT, ROD7_ID
     FROM RIC_PREFORM_ASSEMBLY WHERE PREID = :p`,
    { p: drawId.substring(0, 8) }
  );
  if (!r.rows.length) return { ricPrefFlag: false, rods: [] };

  const row = r.rows[0];
  const fibDrawnPerKG = (row.PREFWT * 37) / row.RODASSEMBLYWT;
  const rods = [];
  let cumKm = 0;
  for (let i = 1; i <= 7; i++) {
    const wt = row[`ROD${i}_WT`];
    const id = row[`ROD${i}_ID`];
    if (wt == null) break;
    cumKm += fibDrawnPerKG * wt;
    rods.push({ id, cumulativeKm: cumKm });
  }
  return { ricPrefFlag: true, rods };
}

/**
 * Main PT entry save function.
 *
 * @param {object} p  - all parameters (documented below)
 *
 * Required parameters:
 *   drawId {string}           - draw spool ID (e.g. 'IB01234101')
 *   machineNo {number}        - PT machine number
 *   operator {string}         - operator ID
 *   shiftIncharge {string}    - shift incharge name
 *   barcodeId {string}        - scanned barcode ID for this bobbin
 *   plant {string}            - 'WALUJ' | 'SHENDRA' | 'MEDAK'
 *   ptLenM {number}           - raw PT length from machine (metres)
 *   balQtyM {number}          - current balance qty in metres (from MATSTOCK)
 *   drQtyM {number}           - original draw qty in metres (from MATMOVE)
 *
 * Optional parameters with defaults:
 *   brkCntLenM {number=0}     - break counter length (metres)
 *   nBreak {number=0}         - 1 if sensor break, 0 otherwise
 *   nBreak1 {number=0}        - 1 if machine stop (not sensor break)
 *   actBrk {number=0}         - 1 if confirmed actual break
 *   tagDrrej {boolean=false}  - automatic draw rejection flag (from machine)
 *   isCheckRejection {boolean=false} - Check1: manual draw rejection
 *   isBEScrap {boolean=false} - Check2: balance draw rejection (BE scrap)
 *   isPTScrap {boolean=false} - PTscrap checkbox
 *   isZTPMD {boolean=false}   - ZTPMD sample
 *   isDocSample {boolean=false} - DOC/reliability sample
 *   isMERej {boolean=false}   - Multiple End rejection
 *   isCheckScratch {boolean=false} - Scratch rejection
 *   drReasonCode {string=''}  - B/L/S/M/D/P/U/A/C
 *   remark {string=''}        - rejection remark text
 *   scrapReason {string=''}   - PT scrap reason code
 *   multiEndReason {string=''}
 *   timeLoss {number=0}       - pre-calculated (override) or pass 0 to auto-calculate
 *   speedLoss {number=0}      - pre-calculated (override) or pass 0 to auto-calculate
 *   machineStopDT {Date}      - d1t1: machine stop datetime
 *   prevStopDT {Date}         - d2t2: previous stop datetime
 *   machineStartDT {Date}     - d3t3: machine start datetime
 *   logDate {Date}            - same as machineStopDT (d1t1)
 *   factor {number=0}         - position factor (km); required for first bobbin of spool
 *   txtFactor1 {number=0}     - last POS from previous entry; used for subsequent bobbins
 *   isFirstBobbin {boolean=false} - true when drQty === balQty (Stag=1)
 *   scrType {string=''}       - scratch type
 *   tlReason {string=''}      - time loss reason
 *   vibration {string=''}
 *   dancerVibration {string=''}
 *   bobbinColor {string=''}
 *   bobbinType {string=''}
 *   bobbinNo {number=0}
 *   deviationSpool {number=0}
 *   ptype {string=''}         - fibre type prefix (first char of drawId)
 *   ptMode {string=''}        - P/R/D
 *   logname {string=''}       - logged-in user
 *   coatType {string=''}
 *   prefStretch {boolean=false}
 *   pt50Flag {boolean=false}  - from ChkPT50 check
 *   spindleNo {string=''}     - from OVDD
 *   pitchSegments {Array}     - Grid3/4/5 rows [{fromKm, toKm, grid}]
 *   sapEntryDone {boolean=false}
 *
 * @returns {{ success:boolean, ptid:string, spos:number, epos:number, message:string }}
 */
async function savePTEntry(p) {
  // --- Defaults ---
  const drawId       = (p.drawId || '').toUpperCase();
  const machineNo    = Number(p.machineNo) || 0;
  const operator     = (p.operator || '').substring(0, 4);
  const shiftIncharge = (p.shiftIncharge || '').substring(0, 10);
  const barcodeId    = (p.barcodeId || '').toUpperCase().trim();
  const plant        = (p.plant || '').toUpperCase();
  const ptype        = (p.ptype || drawId[0] || '').toUpperCase();

  const brkCntLenM  = Number(p.brkCntLenM) || 0;
  const nBreak      = Number(p.nBreak) || 0;
  const nBreak1     = Number(p.nBreak1) || 0;
  const actBrk      = Number(p.actBrk) || 0;
  const tagDrrej    = !!p.tagDrrej;
  const isMERej     = !!p.isMERej;
  const isBEScrap   = !!p.isBEScrap;

  const scrType        = p.scrType || '';
  const tlReason       = p.tlReason || '';
  const vibration      = (p.vibration || '').toUpperCase();
  const dancerVibration = (p.dancerVibration || '').toUpperCase();
  const bobbinColor    = p.bobbinColor || '';
  const bobbinType     = (p.bobbinType || '').toUpperCase();
  const bobbinNo       = Number(p.bobbinNo) || 0;
  const deviationSpool = Number(p.deviationSpool) || 0;
  const ptMode         = (p.ptMode || '').substring(0, 1);
  const logname        = p.logname || '';
  const coatType       = p.coatType || '';
  const prefStretch    = !!p.prefStretch;
  const pt50Flag       = !!p.pt50Flag;
  const spindleNo      = p.spindleNo || null;
  const pitchSegments  = p.pitchSegments || [];
  const multiEndReason = p.multiEndReason || '';
  const isFirstBobbin  = !!p.isFirstBobbin;

  if (!p.sapEntryDone) throw new Error('SAP entry must be completed before PT save');
  if (!machineNo) throw new Error('Machine number is required');
  if (!operator) throw new Error('Operator is required');
  if (!shiftIncharge) throw new Error('Shift Incharge is required');
  if (!bobbinType) throw new Error('Bobbin type is required');
  if (!bobbinColor) throw new Error('Bobbin color is required');
  if (!vibration) throw new Error('Vibration status is required');
  if (!dancerVibration) throw new Error('Dancer vibration status is required');
  if (!bobbinNo) throw new Error('Bobbin number is required');

  // --- Min length ---
  const minLen = getMinLen(ptype);

  // --- Entry type classification ---
  let ptLenM   = Number(p.ptLenM) || 0;
  let scrQtyM  = 0;
  let drRejM   = 0;

  if (p.isCheckRejection || isBEScrap || isMERej || p.isCheckScratch) {
    // Draw rejection: full ptlen becomes drrej
    drRejM  = ptLenM;
    ptLenM  = 0;
  } else if (p.isPTScrap && ptLenM >= minLen) {
    scrQtyM = ptLenM;
    ptLenM  = 0;
  } else if (ptLenM < minLen) {
    // Too short to be OK fibre → becomes scrap
    scrQtyM = ptLenM;
    ptLenM  = 0;
  }

  const balQtyM = Number(p.balQtyM) || 0;
  const drQtyM  = Number(p.drQtyM) || 0;

  // Absorb rounding tail into scrap
  const totalConsumed = ptLenM + scrQtyM + drRejM + brkCntLenM;
  if (Math.abs(balQtyM - totalConsumed) <= (minLen - 300)) {
    scrQtyM = balQtyM - ptLenM - drRejM - brkCntLenM;
    if (scrQtyM < 0) scrQtyM = 0;
  }

  if ((ptLenM + scrQtyM + drRejM + brkCntLenM) > (balQtyM + 200)) {
    throw new Error('Total PT quantity exceeds available balance quantity');
  }

  // --- Time / speed loss ---
  const machineStopDT  = p.machineStopDT  ? new Date(p.machineStopDT)  : new Date();
  const prevStopDT     = p.prevStopDT     ? new Date(p.prevStopDT)     : new Date();
  const machineStartDT = p.machineStartDT ? new Date(p.machineStartDT) : new Date();

  const { timeLoss, speedLoss } = calcTimeLoss(
    machineStopDT, prevStopDT, machineStartDT, ptLenM, machineNo, isBEScrap
  );

  const conn = await getConnection();
  try {
    // --- Resolve product type ---
    const protype = await resolveProductType(drawId, conn);

    // --- Load RIC assembly ---
    const { ricPrefFlag, rods } = await loadRICAssembly(drawId, conn);

    // --- Validate draw stock ---
    const stockR = await conn.execute(
      `SELECT MATNO, STOCKQTY FROM MATSTOCK
       WHERE PROCESS='DRAW' AND ID=:id AND STOCKQTY>0`,
      { id: drawId }
    );
    if (!stockR.rows.length) throw new Error(`Draw spool ${drawId} not found or out of stock`);

    // --- Generate PTID ---
    const cntR = await conn.execute(
      `SELECT COUNT(*) AS CNT FROM MATSTOCK WHERE PROCESS='PT' AND ID LIKE :p`,
      { p: drawId + '%' }
    );
    const ptSeqCount = cntR.rows[0].CNT || 0;
    const ptid = generatePTID(drawId, ptSeqCount);

    // --- FACTOR / POS ---
    let factor;
    if (isFirstBobbin) {
      factor = Number(p.factor) || 0;
    } else {
      factor = Number(p.txtFactor1) || 0;
    }
    const totalThisBobbin = ptLenM + scrQtyM + drRejM + brkCntLenM;
    const pos = Math.round((factor - totalThisBobbin / 1000) * 1000) / 1000;

    // --- SPOS / EPOS (relative to this draw spool) ---
    const spos = Math.round(((drQtyM - balQtyM) / 1000) * 1000) / 1000;
    const epos = Math.round((spos + totalThisBobbin / 1000) * 1000) / 1000;

    // --- SAMPLE_NO ---
    let sampleNo = null;
    if (ptLenM > 0) {
      if (spos < 50) {
        sampleNo = 'F';
      } else if ((drQtyM / 1000) - epos < 50) {
        sampleNo = 'L';
      } else {
        // Retrieve current sequential counter from already-saved PT entries
        const snR = await conn.execute(
          `SELECT MAX(TO_NUMBER(SAMPLE_NO)) AS MAXNO FROM PT
           WHERE PTID LIKE :p AND REGEXP_LIKE(SAMPLE_NO, '^[0-9]+$')`,
          { p: drawId + '%' }
        );
        const prevNo = snR.rows[0]?.MAXNO || 0;
        sampleNo = String(prevNo + 1);
      }
    }

    // --- Zone overlap markers (DRAW_INFO / DRAW_CLAD / DRAW_AIR) ---
    let drawInfo  = false; // Grid3 – silicone/pitch
    let drawClad  = false; // Grid5 – BCSL/clad
    let drawAir   = false; // Grid4 – airline
    for (const seg of pitchSegments) {
      const { fromKm, toKm, grid } = seg;
      if (fromKm > spos && fromKm < epos) {
        if (grid === 'Grid3') drawInfo = true;
        if (grid === 'Grid5') drawClad = true;
        if (grid === 'Grid4') drawAir  = true;
      }
      if (toKm > spos && toKm < epos) {
        if (grid === 'Grid3') drawInfo = true;
        if (grid === 'Grid5') drawClad = true;
        if (grid === 'Grid4') drawAir  = true;
      }
    }

    // --- SLREASON ---
    let slReason = null;
    if (tagDrrej) slReason = 'D';
    else if (nBreak1 === 1 || nBreak === 1) {
      slReason = actBrk === 1 ? 'B' : 'M';
    }

    // --- SAMPLE field ---
    let sample = null;
    if (p.isZTPMD) sample = 'ZTPMD';
    else if (p.isDocSample) sample = 'DOC SAMPLE';
    else if (p.isPTScrap && p.scrapReason) sample = p.scrapReason;

    // --- BREAK ID ---
    let breakId = null;
    if (nBreak > 0) {
      const brkR = await conn.execute(
        `SELECT SUM(NBREAK) AS TOTBRK FROM PT WHERE PTID LIKE :p`,
        { p: drawId + '%' }
      );
      const brkCnt = Number(brkR.rows[0]?.TOTBRK || 0);
      breakId = drawId[10] + (brkCnt + 1);
    }

    // --- Material numbers ---
    const drawMatNo = getMaterialNo(ptype, 'draw');
    const ptMatNo   = getMaterialNo(ptype, 'pt');

    // --- PT_25 bucket for production report ---
    const pt25Bucket = getPT25Bucket(ptLenM);

    // --- Shift ---
    const sf = getShift(machineStopDT);

    // --- PRDate (current Oracle sysdate) ---
    const prDateR = await conn.execute(`SELECT SYSDATE AS DT FROM DUAL`);
    const prDate  = prDateR.rows[0].DT;

    // ========================================================================
    //  BEGIN TRANSACTION
    // ========================================================================
    await conn.execute(`BEGIN NULL; END;`); // placeholder; real: conn.beginTransaction not needed – autoCommit=false

    // 1. INSERT MATSTOCK for new PT fibre
    if (ptLenM > 0) {
      await conn.execute(
        `INSERT INTO MATSTOCK (MATNO, ID, STOCKQTY, CREATEDATE, PROCESS, PTYPE, COLR, PLANT)
         VALUES (:m,:id,:qty,:dt,'PT',:pt,:colr,:plant)`,
        {
          m: ptMatNo, id: ptid,
          qty: Math.round(ptLenM / 1000 * 1000) / 1000,
          dt: prDate, pt: ptype, colr: 'NATURAL', plant,
        }
      );
    }

    // 2. UPDATE MATSTOCK – reduce draw spool balance
    await conn.execute(
      `UPDATE MATSTOCK
       SET STOCKQTY = STOCKQTY - :reduce
       WHERE ID=:id AND PROCESS='DRAW'`,
      { reduce: Math.round(totalThisBobbin / 1000 * 1000) / 1000, id: drawId }
    );

    // 3. MATMOVE 261 – draw consumed (OK + scrap + brkLen)
    if (ptLenM + scrQtyM + brkCntLenM > 0) {
      await conn.execute(
        `INSERT INTO MATMOVE
         (MATNO,ID,MDATE,QTY,PROCESS,MCNO,OPR,PTYPE,MOVETYPE,ENTRYTYPE,EDATE,SHIFT,BARCODEID,PLANT)
         VALUES(:m,:id,:dt,:qty,'PT',:mc,:opr,:pt,'261','I',:dt,:sf,:bc,:plant)`,
        {
          m: drawMatNo, id: drawId, dt: prDate,
          qty: Math.round((ptLenM + scrQtyM + brkCntLenM) / 1000 * 1000) / 1000,
          mc: String(machineNo), opr: operator, pt: ptype,
          sf, bc: barcodeId, plant,
        }
      );
    }

    // 4. MATMOVE 551 – draw rejection
    if (drRejM > 0) {
      await conn.execute(
        `INSERT INTO MATMOVE
         (MATNO,ID,MDATE,QTY,PROCESS,MCNO,OPR,PTYPE,MOVETYPE,ENTRYTYPE,EDATE,SHIFT,BARCODEID,PLANT)
         VALUES(:m,:id,:dt,:qty,'PT',:mc,:opr,:pt,'551','I',:dt,:sf,:bc,:plant)`,
        {
          m: drawMatNo, id: drawId, dt: prDate,
          qty: Math.round(drRejM / 1000 * 1000) / 1000,
          mc: String(machineNo), opr: operator, pt: ptype,
          sf, bc: barcodeId, plant,
        }
      );
    }

    // 5. MATMOVE 101 – PT fibre receipt
    if (ptLenM > 0) {
      await conn.execute(
        `INSERT INTO MATMOVE
         (MATNO,ID,MDATE,QTY,PROCESS,MCNO,OPR,PTYPE,MOVETYPE,ENTRYTYPE,EDATE,SHIFT,BARCODEID,PLANT)
         VALUES(:m,:id,:dt,:qty,'PT',:mc,:opr,:pt,'101','R',:dt,:sf,:bc,:plant)`,
        {
          m: ptMatNo, id: ptid, dt: prDate,
          qty: Math.round(ptLenM / 1000 * 1000) / 1000,
          mc: String(machineNo), opr: operator, pt: ptype,
          sf, bc: barcodeId, plant,
        }
      );
    }

    // 6. PT INSERT – main production record
    await conn.execute(
      `INSERT INTO PT
       (MATNO,FID,PRODDATE,OKLEN,SCRAP1,SCRAP2,BRKCNT,PROCESS,PTID,
        MCNO,BREAKID,NBREAK,PTYPE,DRREJ,DRREJ1,REMARK,SAMPLE,OPR,SHIFT_INCHARGE,
        FACTOR,POS,SCRTYPE,TIMELOSS,SPEEDLOSS,LOGDATE,SPOS,EPOS,SAMPLE_NO,
        DRAW_INFO,DRAW_CLAD,DRAW_AIR,SLREASON,PTMODE,VIBRATION,DANCER_VIBRATION,
        PLANT,LOGNAME,COATTYPE,PREF_STRETCH,FLAG50,SPINDLE,PRODUCT_TYPE,
        MULTIEND_REASON)
       VALUES
       (:m,:fid,:dt,
        :oklen,:scrap1,0,:brkcnt,'PT',:ptid,
        :mc,:breakid,:nbreak,:ptype,:drrej,:drrej1,:remark,:sample,:opr,:si,
        :factor,:pos,:scrtype,:tl,:sl,:logdate,:spos,:epos,:sampleno,
        :di,:dc,:da,:slr,:ptmode,:vib,:dvib,
        :plant,:logname,:coattype,:pref,:flag50,:spindle,:protype,
        :mend)`,
      {
        m: drawMatNo, fid: drawId, dt: prDate,
        oklen:  Math.round(ptLenM  / 1000 * 1000) / 1000,
        scrap1: Math.round(scrQtyM / 1000 * 1000) / 1000,
        brkcnt: Math.round(brkCntLenM / 1000 * 1000) / 1000,
        ptid,
        mc: String(machineNo),
        breakid: breakId,
        nbreak: nBreak,
        ptype,
        drrej:  Math.round(drRejM / 1000 * 1000) / 1000,
        drrej1: drRejM > 0 ? p.drReasonCode || null : null,
        remark: drRejM > 0 ? p.remark || null : null,
        sample,
        opr: operator,
        si: shiftIncharge,
        factor,
        pos,
        scrtype: scrType || null,
        tl: timeLoss,
        sl: speedLoss,
        logdate: machineStopDT,
        spos,
        epos,
        sampleno: sampleNo,
        di: drawInfo ? 'T' : null,
        dc: drawClad ? 'Q' : null,
        da: drawAir  ? 'A' : null,
        slr: slReason,
        ptmode: ptMode || null,
        vib: vibration || null,
        dvib: dancerVibration || null,
        plant,
        logname: logname || null,
        coattype: coatType || null,
        pref: prefStretch ? 'YES' : 'NO',
        flag50: pt50Flag ? 'Y' : 'N',
        spindle: spindleNo,
        protype: protype || null,
        mend: isMERej ? multiEndReason || null : null,
      }
    );

    // 7. PTBARCODE INSERT (only when ptlen >= minLen)
    if (ptLenM >= minLen) {
      const rellen = Math.round(((drQtyM - balQtyM + ptLenM) / 1000) * 1000) / 1000;
      const prefPos = pos; // same as PT.POS
      await conn.execute(
        `INSERT INTO PTBARCODE
         (BARCODEID,FID,LENGTH,MCNO,PDATE,RELLEN,DIRECTION,STATUS,POPR,PROCESS,PLANT,PREFPOS)
         VALUES(:bc,:fid,:len,:mc,:dt,:rl,'E','D',:opr,'PT',:plant,:pp)`,
        {
          bc: barcodeId, fid: ptid,
          len: Math.round(ptLenM * 1000) / 1000,
          mc: String(machineNo), dt: prDate,
          rl: rellen, opr: operator.toUpperCase(), plant, pp: prefPos,
        }
      );
    }

    // 8. PTCOLOR INSERT/UPDATE
    if (ptLenM > 0) {
      const existsR = await conn.execute(
        `SELECT COUNT(*) AS CNT FROM PTCOLOR WHERE FID=:fid`, { fid: ptid }
      );
      if (existsR.rows[0].CNT > 0) {
        await conn.execute(
          `UPDATE PTCOLOR SET COLOR=:c,PDATE=:dt,BOBBIN_TYPE=:bt,DEV_SPOOL=:ds,
           BOB_NO=:bn,PLANT=:pl,PTLEN=:len WHERE FID=:fid`,
          {
            c: bobbinColor, dt: prDate, bt: bobbinType, ds: deviationSpool,
            bn: bobbinNo, pl: plant,
            len: Math.round(ptLenM / 1000 * 1000) / 1000, fid: ptid,
          }
        );
      } else {
        await conn.execute(
          `INSERT INTO PTCOLOR (FID,COLOR,PDATE,BOBBIN_TYPE,DEV_SPOOL,BOB_NO,PLANT,PTLEN)
           VALUES(:fid,:c,:dt,:bt,:ds,:bn,:pl,:len)`,
          {
            fid: ptid, c: bobbinColor, dt: prDate, bt: bobbinType, ds: deviationSpool,
            bn: bobbinNo, pl: plant,
            len: Math.round(ptLenM / 1000 * 1000) / 1000,
          }
        );
      }
    }

    // 9. PT25TRACKING (ptlen >= 24,450 m, non M/R/D/Q/N/A)
    if (ptLenM >= 24450 && !['M','R','D','Q','N','A'].includes(ptype)) {
      await conn.execute(
        `INSERT INTO PT25TRACKING (FID,LENGTH,STATUS,PDATE,PLANT)
         VALUES(:fid,:len,'O',:dt,:plant)`,
        { fid: ptid, len: Math.round(ptLenM * 1000) / 1000, dt: prDate, plant }
      );
    }

    // 10. PT50TRACKING (SHENDRA only, ptlen >= 48,850 m)
    if (plant === 'SHENDRA' && ptLenM >= 48850) {
      await conn.execute(
        `INSERT INTO PT50TRACKING (FID,LENGTH,STATUS,PDATE,PLANT)
         VALUES(:fid,:len,'O',:dt,:plant)`,
        { fid: ptid, len: ptLenM, dt: prDate, plant }
      );
    }

    // 11. PRODREPORT_DRAW upsert
    const procKey = ptype; // drawId[0]
    const dtno    = parseInt(drawId.substring(8, 10)) || 0;
    const dateStr = prDate.toISOString().substring(0, 10);
    const prDrawR = await conn.execute(
      `SELECT COUNT(*) AS CNT FROM PRODREPORT_DRAW
       WHERE PDATE=:d AND PROCESS=:p AND DTNO=:n`,
      { d: dateStr, p: procKey, n: dtno }
    );
    if (prDrawR.rows[0].CNT === 0) {
      await conn.execute(
        `INSERT INTO PRODREPORT_DRAW (PDATE,PROCESS,DTNO,TOT_PT,PT_OK,DRAW_REJ,PT_25,PT_BRK)
         VALUES(:d,:p,:n,:tot,:ok,:dr,:p25,:brk)`,
        {
          d: dateStr, p: procKey, n: dtno,
          tot: (ptLenM + scrQtyM + brkCntLenM) / 1000,
          ok: ptLenM / 1000,
          dr: drRejM / 1000,
          p25: pt25Bucket,
          brk: nBreak,
        }
      );
    } else {
      await conn.execute(
        `UPDATE PRODREPORT_DRAW
         SET TOT_PT=TOT_PT+:tot, PT_OK=PT_OK+:ok, DRAW_REJ=DRAW_REJ+:dr,
             PT_25=PT_25+:p25, PT_BRK=PT_BRK+:brk
         WHERE PDATE=:d AND PROCESS=:p AND DTNO=:n`,
        {
          tot: (ptLenM + scrQtyM + brkCntLenM) / 1000,
          ok: ptLenM / 1000, dr: drRejM / 1000,
          p25: pt25Bucket, brk: nBreak,
          d: dateStr, p: procKey, n: dtno,
        }
      );
    }

    // 12. PRODREPORT upsert
    const prR = await conn.execute(
      `SELECT COUNT(*) AS CNT FROM PRODREPORT WHERE PDATE=:d AND PROCESS=:p`,
      { d: dateStr, p: procKey }
    );
    if (prR.rows[0].CNT === 0) {
      await conn.execute(
        `INSERT INTO PRODREPORT (PDATE,PROCESS,TOT_PT,PT_OK,DRAW_REJ,PT_25,PT_BRK)
         VALUES(:d,:p,:tot,:ok,:dr,:p25,:brk)`,
        {
          d: dateStr, p: procKey,
          tot: (ptLenM + scrQtyM + brkCntLenM) / 1000,
          ok: ptLenM / 1000, dr: drRejM / 1000,
          p25: pt25Bucket, brk: nBreak,
        }
      );
    } else {
      await conn.execute(
        `UPDATE PRODREPORT
         SET TOT_PT=TOT_PT+:tot, PT_OK=PT_OK+:ok, DRAW_REJ=DRAW_REJ+:dr,
             PT_25=PT_25+:p25, PT_BRK=PT_BRK+:brk
         WHERE PDATE=:d AND PROCESS=:p`,
        {
          tot: (ptLenM + scrQtyM + brkCntLenM) / 1000,
          ok: ptLenM / 1000, dr: drRejM / 1000,
          p25: pt25Bucket, brk: nBreak,
          d: dateStr, p: procKey,
        }
      );
    }

    // 13. PTIME_LOSS (if timeLoss >= 1 min)
    if (timeLoss >= 1 && tlReason) {
      await conn.execute(
        `INSERT INTO PTIME_LOSS (LDATE,FIBREID,AREA,LOSSTYPE,TIMELOSS,OPR,MCNO)
         VALUES(:dt,:fid,'PT',:lt,:tl,:opr,:mc)`,
        {
          dt: prDate, fid: ptid,
          lt: tlReason.toUpperCase(), tl: timeLoss,
          opr: operator.substring(0, 3),
          mc: machineNo,
        }
      );
    }

    // ========================================================================
    //  COMMIT
    // ========================================================================
    await conn.commit();

    // ========================================================================
    //  POST-COMMIT: RIC Preform Rod tracking
    // ========================================================================
    if (ricPrefFlag && rods.length > 0) {
      const prefPosEnd   = factor;
      const prefPosStart = pos;
      const midpoint     = (prefPosStart + prefPosEnd) / 2;
      let ricPreID = '';
      for (const rod of rods) {
        if (midpoint <= rod.cumulativeKm) {
          ricPreID = rod.id;
          break;
        }
      }
      if (ricPreID && ptLenM >= minLen) {
        await conn.execute(
          `UPDATE PTBARCODE SET RICPREID=:rid WHERE BARCODEID=:bc`,
          { rid: ricPreID, bc: barcodeId }
        );
        await conn.execute(
          `UPDATE PT SET RICPREID=:rid WHERE PTID=:ptid`,
          { rid: ricPreID, ptid }
        );
        await conn.commit();
      }
    }

    return {
      success: true, ptid, spos, epos,
      factor, pos,
      message: `Saved ${ptid}: OK=${(ptLenM/1000).toFixed(3)}km Scrap=${(scrQtyM/1000).toFixed(3)}km DrRej=${(drRejM/1000).toFixed(3)}km SPOS=${spos} EPOS=${epos}`,
    };

  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    await conn.close();
  }
}

module.exports = {
  savePTEntry,
  getMinLen,
  getPT25Bucket,
  calcTimeLoss,
  resolveProductType,
};
