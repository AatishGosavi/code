/**
 * Event Log Service
 * Reads the PT machine daily log file and inserts events into PTLOGIN table
 * Ported from VB6: EventRead() and Timer1_Timer()
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { getConnection } = require('../config/db');

const MC_LOG_PATH = process.env.MC_LOG_PATH || 'C:\\GFP\\LOG\\';

/**
 * Get today's log file name (dd-MM-yyyy.txt)
 * @returns {string}
 */
function getTodayLogFileName() {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, '0');
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const yyyy = now.getFullYear();
  return `${dd}-${mm}-${yyyy}.txt`;
}

/**
 * Parse a line from the Medak machine log file (semicolon-delimited)
 * Format: [event_description];[...];[date];[time];[...];[...];[length];...
 * @param {string} line
 * @returns {{ date: Date|null, time: string, length: number, description: string, rawParts: string[] }}
 */
function parseLogLine(line) {
  const parts = line.split(';');
  let date = null;
  let time = '';
  let length = 0;
  const description = (line.substring(0, 42) || '').trim();

  try {
    if (parts[2]) date = new Date(parts[2]);
    if (parts[3]) time = parts[3];
    if (parts[6]) length = parseFloat(parts[6]) || 0;
  } catch (_) { /* ignore parse errors */ }

  return { date, time, length, description, rawParts: parts };
}

/**
 * Check if a log line is a significant machine event
 * @param {string} line
 * @returns {boolean}
 */
function isSignificantEvent(line) {
  return (
    line.startsWith('MACHINE Start') ||
    line.startsWith('FAULT DRAW CUTTING INSTRUCTION') ||
    line.startsWith('FAULT MACHINE STOP BY') ||
    line.startsWith('FAULT MINIMUM STRAIN ON PROOF TEST') ||
    line.startsWith('COVER OPEN') ||
    line.startsWith('FAULT THREADING NOT GOOD TO REW. MODE')
  );
}

/**
 * Read new events from the machine log file and insert into PTLOGIN.
 * Picks up from last-read line number stored in PTLOGINSTATUS table.
 *
 * @param {number} machineNo
 * @param {string} operator
 * @returns {number} count of new events inserted
 */
async function readAndSaveEvents(machineNo, operator) {
  const fileName = getTodayLogFileName();
  const filePath = path.join(MC_LOG_PATH, fileName);

  if (!fs.existsSync(filePath)) {
    console.warn(`Event log file not found: ${filePath}`);
    return 0;
  }

  const conn = await getConnection();
  let insertCount = 0;

  try {
    // Load last-read position from PTLOGINSTATUS
    const statusResult = await conn.execute(
      `SELECT LASTLINENO, LASTLINEDESC, FIRSTLINEDESC, LASTTIMEDIFF, SYSDATE AS ORADATE
       FROM PTLOGINSTATUS WHERE PTNO = :ptno`,
      { ptno: machineNo }
    );

    let lastLineNo = 0;
    let firstLineDesc = '';
    let lastLineDesc = '';
    const oraDate = statusResult.rows.length > 0 ? statusResult.rows[0].ORADATE : new Date();
    const pcDate = new Date();
    const dateDiffSec = Math.round((oraDate - pcDate) / 1000);

    if (statusResult.rows.length > 0) {
      lastLineNo = statusResult.rows[0].LASTLINENO || 0;
      firstLineDesc = statusResult.rows[0].FIRSTLINEDESC || '';
      lastLineDesc = statusResult.rows[0].LASTLINEDESC || '';
    }

    // Read file line by line
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const lines = fileContent.split('\n');

    let lineNumber = 0;
    let newLastLineNo = lastLineNo;
    let newLastLineDesc = lastLineDesc;
    let newFirstLineDesc = firstLineDesc;
    let newEntryFlag = false;

    for (let i = 0; i < lines.length; i++) {
      lineNumber = i + 1;
      const line = lines[i].trim();
      if (!line) continue;

      // Track first line
      if (lineNumber === 1) {
        if (line === firstLineDesc) {
          // Same first line, skip to where we left off
          if (lastLineNo > 1) {
            i = lastLineNo - 1; // jump to last-read line
            continue;
          }
        } else {
          newFirstLineDesc = line;
        }
      }

      if (lineNumber <= lastLineNo) continue;

      newEntryFlag = true;

      if (isSignificantEvent(line)) {
        const parsed = parseLogLine(line);
        if (!parsed.date) continue;

        // Adjust date for PC-Oracle time drift
        const adjustedDate = new Date(parsed.date.getTime() + dateDiffSec * 1000);

        await conn.execute(
          `INSERT INTO PTLOGIN (PTNO, DESCR, PDATE, VAL1, VAL2, OPR)
           VALUES (:ptno, :descr, :pdate, :val1, :val2, :opr)`,
          {
            ptno: machineNo,
            descr: parsed.description,
            pdate: adjustedDate,
            val1: parsed.length,
            val2: 0,
            opr: operator,
          }
        );
        insertCount++;

        if (insertCount >= 5) break; // max 5 per cycle
      }

      newLastLineNo = lineNumber;
      newLastLineDesc = line;
    }

    // Update PTLOGINSTATUS
    if (newEntryFlag) {
      if (statusResult.rows.length === 0) {
        await conn.execute(
          `INSERT INTO PTLOGINSTATUS (PTNO, LASTLINENO, LASTLINEDESC, FIRSTLINEDESC, LASTTIMEDIFF)
           VALUES (:ptno, :lastLineno, :lastLineDesc, :firstLineDesc, :diff)`,
          {
            ptno: machineNo,
            lastLineno: newLastLineNo,
            lastLineDesc: newLastLineDesc,
            firstLineDesc: newFirstLineDesc,
            diff: dateDiffSec,
          }
        );
      } else {
        await conn.execute(
          `UPDATE PTLOGINSTATUS
           SET LASTLINENO = :lastLineno, LASTLINEDESC = :lastLineDesc,
               FIRSTLINEDESC = :firstLineDesc, LASTTIMEDIFF = :diff
           WHERE PTNO = :ptno`,
          {
            ptno: machineNo,
            lastLineno: newLastLineNo,
            lastLineDesc: newLastLineDesc,
            firstLineDesc: newFirstLineDesc,
            diff: dateDiffSec,
          }
        );
      }
    }

    await conn.commit();
    return insertCount;
  } finally {
    await conn.close();
  }
}

/**
 * Parse the Medak machine log file to extract the latest machine stop event
 * Looks for STOP events after the last recorded timestamp.
 *
 * @param {string} machineLogPath - full path to the log file
 * @param {Date} afterDate        - only process events after this date
 * @param {Date} afterTime        - only process events after this time
 * @returns {{ length: number, nBreak: number, barcodeId: string, isDrawRej: boolean } | null}
 */
function parseLatestStopEvent(machineLogPath, afterDate, afterTime) {
  if (!fs.existsSync(machineLogPath)) return null;

  const content = fs.readFileSync(machineLogPath, 'utf8');
  const lines = content.split('\n');

  let result = null;
  let lengthGet = false;
  const afterDT = new Date(`${afterDate.toISOString().split('T')[0]}T${afterTime}`);

  for (const line of lines) {
    const parts = line.split(';');
    if (parts.length < 7) continue;

    let eventDate;
    try { eventDate = new Date(parts[2]); } catch (_) { continue; }
    const eventTime = parts[3] || '';
    const eventDT = new Date(`${parts[2]}T${eventTime.replace(/\./g, ':').substring(0, 8)}`);

    if (eventDT <= afterDT) continue;

    if (
      line.startsWith('STOP -> Stop Length reached') ||
      line.startsWith('STOP -> request by remote') ||
      line.startsWith('STOP -> Fiber Break at TU Fiber Sensor')
    ) {
      const length = parseFloat(parts[6]) || 0;
      const nBreak = line.startsWith('STOP -> Fiber Break at TU Fiber Sensor') ? 1 : 0;
      const isDrawRej = false;

      if (length > 4200) {
        lengthGet = true;
        result = { length, nBreak, nBreak1: nBreak === 0 ? 1 : 0, barcodeId: '', isDrawRej };
      } else {
        result = null;
      }
    }

    if (line.includes('BCODE') && lengthGet) {
      if (line.includes('SCRAP')) {
        if (result) {
          result.isDrawRej = true;
          result.remark = result.nBreak === 1 ? 'Fiber Break at Sensor' : 'Automatic Draw Rejection';
        }
      } else {
        const bcParts = line.split(';');
        if (bcParts[1] && result) {
          result.barcodeId = bcParts[1].toUpperCase().trim();
        }
      }
    }
  }

  return result;
}

module.exports = {
  readAndSaveEvents,
  parseLatestStopEvent,
  getTodayLogFileName,
};
