/**
 * PT Automation Main Entry Point (Node.js)
 * REST API for PT machine automation business logic
 */

const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();

const drawSpoolService = require('./services/drawSpoolService');
const cuttingLengthService = require('./services/cuttingLengthService');
const ptDataService = require('./services/ptDataService');
const eventLogService = require('./services/eventLogService');
const { validateBarcodeWaluj, validateBarcodeShendra } = require('./utils/helpers');
const { PLANTS } = require('./constants');

const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;

// ============================
// API ENDPOINTS
// ============================

/**
 * GET /api/pt/allocation/:machineNo
 * Get allocated spool for a PT machine
 */
app.get('/api/pt/allocation/:machineNo', async (req, res) => {
  try {
    const machineNo = parseInt(req.params.machineNo);
    const allocation = await drawSpoolService.getAllocatedSpool(machineNo);

    if (!allocation) {
      return res.status(404).json({ error: 'No spool allocated for this machine' });
    }

    res.json(allocation);
  } catch (error) {
    console.error('Error fetching allocation:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/pt/spool/:drawId
 * Load draw spool details
 */
app.get('/api/pt/spool/:drawId', async (req, res) => {
  try {
    const drawId = req.params.drawId.toUpperCase();
    const spoolDetails = await drawSpoolService.loadSpoolDetails(drawId);

    const flaws = await drawSpoolService.loadDrawFlaws(drawId, spoolDetails.drawQty / 1000);
    const pitchChanges = await drawSpoolService.loadPitchChanges(drawId, spoolDetails.drawQty / 1000);
    const previousPT = await drawSpoolService.loadPreviousPTLog(drawId);

    res.json({
      spool: spoolDetails,
      flaws,
      pitchChanges,
      previousPT,
    });
  } catch (error) {
    console.error('Error loading spool:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/pt/cutting-length
 * Calculate recommended PT cut length
 * Body:
 * {
 *   drawId, plant, productType, balQtyM, drQtyM, bottomScrapM,
 *   flawMsg, nextFlawPosKm, cuttingLenKm, totalPTDoneKm,
 *   scratchFlag, isPTContBrkFlag, isFlagPMD, bobbinLength,
 *   barcodeId, ptId, tagDrrej
 * }
 */
app.post('/api/pt/cutting-length', async (req, res) => {
  try {
    const result = await cuttingLengthService.calculateCuttingLength(req.body);
    res.json(result);
  } catch (error) {
    console.error('Error calculating cutting length:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/pt/save
 * Save PT production entry (main transaction)
 * Body:
 * {
 *   drawId, machineNo, operator, shiftIncharge, barcodeId, plant,
 *   ptLenM, scrQtyM, drRejM, balQtyM, drQtyM,
 *   brkCntLenM, nBreak, nBreak1,
 *   isCheckRejection, isPTScrap,
 *   drReasonCode, remark, scrapReason,
 *   isZTPMD, isDocSample,
 *   factor, pos, scrType, timeLossMins, speedLossMins,
 *   logDate, spos, epos,
 *   vibration, dancerVibration, logname, coatType, productType,
 *   prefStretch, tagDrrej, actBrk, ptMode,
 *   bobbinColor, bobbinType, bobbinNo, ptype, minLen,
 *   drawInfo, drawClad, drawAir, sapEntryDone
 * }
 */
app.post('/api/pt/save', async (req, res) => {
  try {
    // Validate barcode
    const { barcodeId, drawId, plant, productType } = req.body;

    let validation;
    if (plant === PLANTS.WALUJ) {
      validation = validateBarcodeWaluj(barcodeId, drawId, productType);
    } else if (plant === PLANTS.SHENDRA || plant === PLANTS.MEDAK) {
      validation = validateBarcodeShendra(barcodeId, productType);
    } else {
      return res.status(400).json({ error: 'Invalid plant' });
    }

    if (!validation.valid) {
      return res.status(400).json({ error: validation.error });
    }

    // Save entry
    const result = await ptDataService.savePTEntry(req.body);
    res.json(result);
  } catch (error) {
    console.error('Error saving PT entry:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/pt/events/:machineNo
 * Read new machine log events and insert into PTLOGIN
 */
app.get('/api/pt/events/:machineNo', async (req, res) => {
  try {
    const machineNo = parseInt(req.params.machineNo);
    const operator = req.query.operator || 'SYSTEM';

    const count = await eventLogService.readAndSaveEvents(machineNo, operator);
    res.json({ message: `${count} new events logged` });
  } catch (error) {
    console.error('Error reading events:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/pt/parse-log
 * Parse machine log file for latest stop event
 * Body: { logPath, afterDate, afterTime }
 */
app.post('/api/pt/parse-log', async (req, res) => {
  try {
    const { logPath, afterDate, afterTime } = req.body;
    const event = eventLogService.parseLatestStopEvent(logPath, new Date(afterDate), afterTime);

    if (!event) {
      return res.status(404).json({ message: 'No new stop event found' });
    }

    res.json(event);
  } catch (error) {
    console.error('Error parsing log:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Health check
 */
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'PT Automation API', version: '1.0.0' });
});

// Start server
app.listen(PORT, () => {
  console.log(`PT Automation API listening on port ${PORT}`);
});
