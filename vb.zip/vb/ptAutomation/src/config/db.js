/**
 * Oracle DB connection configuration
 * Uses oracledb npm package
 */
const oracledb = require('oracledb');

const dbConfig = {
  user: process.env.DB_USER || 'your_user',
  password: process.env.DB_PASSWORD || 'your_password',
  connectString: process.env.DB_CONNECT_STRING || 'localhost/ORCL',
  poolMin: 2,
  poolMax: 10,
  poolIncrement: 1,
};

let pool;

async function getPool() {
  if (!pool) {
    pool = await oracledb.createPool(dbConfig);
  }
  return pool;
}

async function getConnection() {
  const p = await getPool();
  return p.getConnection();
}

async function executeQuery(sql, params = [], options = {}) {
  const conn = await getConnection();
  try {
    const result = await conn.execute(sql, params, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: false,
      ...options,
    });
    return result;
  } finally {
    await conn.close();
  }
}

module.exports = { getConnection, executeQuery, getPool };
