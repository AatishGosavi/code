/**
 * Utility / helper functions
 */

const { SHIFTS } = require('../constants');

/**
 * Determine current shift based on hour of day
 * @param {Date} date
 * @returns {string} 'A', 'B', or 'C'
 */
function getShift(date = new Date()) {
  const hour = date.getHours();
  if (hour >= SHIFTS.A.start && hour < SHIFTS.A.end) return 'A';
  if (hour >= SHIFTS.B.start && hour < SHIFTS.B.end) return 'B';
  return 'C';
}

/**
 * Generate PTID from drawId and existing PT count for that draw ID
 * @param {string} drawId - 11-char draw spool ID
 * @param {number} count - existing PT entries count for this drawId
 * @returns {string} new PTID
 */
function generatePTID(drawId, count) {
  if (count >= 40) {
    return drawId + 'Z' + String.fromCharCode(count + 65 - 40);
  } else if (count >= 24) {
    return drawId + 'Y' + String.fromCharCode(count + 65 - 24);
  } else {
    return drawId + String.fromCharCode(count + 65);
  }
}

/**
 * Determine material number for drawn fibre based on ptype prefix
 * @param {string} ptype - single-char fibre type (N, D, Q, A, M, R, or default)
 * @param {'draw'|'pt'} process
 * @returns {string} material number
 */
function getMaterialNo(ptype, process) {
  const MATNO_MAP = {
    draw: {
      N: '330001937', D: '330001937', Q: '330001937', A: '330001937',
      M: '330000155',
      R: '330000183',
      default: '330000126',
    },
    pt: {
      N: '330001939', D: '330001939', Q: '330001939', A: '330001939',
      M: '330000156',
      R: '330000184',
      default: '330000127',
    },
  };
  const map = MATNO_MAP[process];
  return map[ptype] || map.default;
}

/**
 * Determine shift from a datetime string (ISO or Date object)
 * @param {string|Date} dateInput
 * @returns {string} shift code A/B/C
 */
function getShiftFromDate(dateInput) {
  return getShift(new Date(dateInput));
}

/**
 * Validate a WALUJ barcode ID
 * Rules:
 *   - Length must be 7
 *   - Must not start with 'Z'
 *   - First char must be digit 4-9
 *   - Second char must be A-Z
 *   - Chars 4-7 must be digits
 *   - Only alphanumeric characters
 * @param {string} barcodeId
 * @param {string} drawId
 * @param {string} productType
 * @returns {{ valid: boolean, error?: string }}
 */
function validateBarcodeWaluj(barcodeId, drawId, productType) {
  const id = (barcodeId || '').toUpperCase().trim();

  if (id.length !== 7) return { valid: false, error: 'Barcode ID must be 7 characters' };
  if (id[0] === 'Z') return { valid: false, error: 'Barcode ID cannot start with Z' };

  const firstDigit = parseInt(id[0]);
  if (isNaN(firstDigit) || firstDigit < 4 || firstDigit > 9) {
    return { valid: false, error: 'First character of Barcode ID must be digit 4-9' };
  }

  const secondChar = id[1];
  if (secondChar < 'A' || secondChar > 'Z') {
    return { valid: false, error: 'Second character of Barcode ID must be A-Z' };
  }

  for (let i = 3; i < 7; i++) {
    const c = id.charCodeAt(i);
    if (c < 48 || c > 57) {
      return { valid: false, error: 'Characters 4-7 of Barcode ID must be digits' };
    }
  }

  for (let k = 0; k < 7; k++) {
    const c = id.charCodeAt(k);
    if (!((c >= 48 && c <= 57) || (c >= 65 && c <= 90))) {
      return { valid: false, error: 'Barcode ID must contain only alphanumeric characters' };
    }
  }

  // D/Q/A type draw → barcode must start with '7'
  const drawPrefix = (drawId || '')[0]?.toUpperCase();
  if (['D', 'Q', 'A'].includes(drawPrefix)) {
    if (id[0] !== '7') return { valid: false, error: 'For D/Q/A type draw, Barcode ID must start with 7' };
  } else {
    if (id[0] === '7') return { valid: false, error: 'Barcode ID starting with 7 is only for D/Q/A type' };
  }

  // Product type lock rules (WALUJ)
  const ptLocks = {
    E1: ['2', '6'], L2: ['2', '6'], B: ['2', '6'],
    E2: ['5'], E3: ['5'],
    A: ['7'], Q: ['7'],
    L1: ['4'],
  };
  if (ptLocks[productType]) {
    if (!ptLocks[productType].includes(id[0])) {
      return { valid: false, error: `For product type ${productType}, Barcode ID must start with ${ptLocks[productType].join(' or ')}` };
    }
  }

  return { valid: true };
}

/**
 * Validate a SHENDRA barcode ID
 * Rules:
 *   - Length must be 10
 *   - Must start with 'S'
 *   - Second char must be A-Z
 *   - All chars alphanumeric only
 * @param {string} barcodeId
 * @param {string} productType
 * @returns {{ valid: boolean, error?: string }}
 */
function validateBarcodeShendra(barcodeId, productType) {
  const id = (barcodeId || '').toUpperCase().trim();

  if (id.length !== 10) return { valid: false, error: 'Barcode ID must be 10 characters' };
  if (id[0] !== 'S') return { valid: false, error: 'Barcode ID must start with S' };

  const secondChar = id[1];
  if (secondChar < 'A' || secondChar > 'Z') {
    return { valid: false, error: 'Second character of Barcode ID must be A-Z' };
  }

  for (let k = 0; k < 10; k++) {
    const c = id.charCodeAt(k);
    if (!((c >= 48 && c <= 57) || (c >= 65 && c <= 90))) {
      return { valid: false, error: 'Barcode ID must contain only alphanumeric characters' };
    }
  }

  // Product type prefix locks (SHENDRA)
  const ptLocks = {
    E1: 'SAE', E2: 'SAR', B: 'SAE',
    L1: 'SAL', L3: 'SAL',
    SRB: 'SAS', S: 'SA0',
  };
  if (ptLocks[productType]) {
    if (!id.startsWith(ptLocks[productType])) {
      return { valid: false, error: `For product type ${productType}, Barcode ID must start with ${ptLocks[productType]}` };
    }
  }

  return { valid: true };
}

module.exports = {
  getShift,
  getShiftFromDate,
  generatePTID,
  getMaterialNo,
  validateBarcodeWaluj,
  validateBarcodeShendra,
};
