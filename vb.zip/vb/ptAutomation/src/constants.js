/**
 * Constants used across PT Automation business logic
 */

// Material numbers for different fibre types
const MATNO = {
  DRAW_SMF: '330000126',
  PT_SMF: '330000127',
  DRAW_MULTIMODE: '330000155',
  PT_MULTIMODE: '330000156',
  DRAW_REW: '330000183',
  PT_REW: '330000184',
  DRAW_DOF: '330001937',
  PT_DOF: '330001939',
};

// Movement types for MATMOVE table
const MOVETYPE = {
  GOODS_ISSUE: '261',   // draw spool consumed
  REJECTION: '551',     // draw rejection
  GOODS_RECEIPT: '101', // PT fibre produced
};

// Draw rejection reason codes
const REJECTION_REASONS = {
  BFD: 'B',
  LUMPS: 'L',
  AIRLINE: 'A',
  SCD: 'C',
  BE_SCRAP: 'S',
  MULTIPLE_END: 'M',
  SCRATCH: 'D',
  PITCH_CHANGE: 'P',
  UNKNOWN: 'U',
};

// Plants
const PLANTS = {
  WALUJ: 'WALUJ',
  SHENDRA: 'SHENDRA',
  MEDAK: 'MEDAK',
};

// Minimum acceptable PT length (metres) to be considered OK fibre
const MIN_PT_LENGTH = 4200;

// Default bobbin length (km)
const DEFAULT_BOBBIN_LENGTH = 52;

// Machine speed (metres/min) for time loss calculation
const MC_SPEED = {
  DEFAULT: 2200,
  HIGH: 2500, // for machine numbers >= 20
};

// Shift time ranges (24h)
const SHIFTS = {
  A: { start: 7, end: 15 },
  B: { start: 15, end: 23 },
  C: { start: 23, end: 7 },
};

module.exports = { MATNO, MOVETYPE, REJECTION_REASONS, PLANTS, MIN_PT_LENGTH, DEFAULT_BOBBIN_LENGTH, MC_SPEED, SHIFTS };
