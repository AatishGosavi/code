# PT Automation – Medak : Business Logic Documentation (v2 – Full Detail)

## Overview

`frmptautomation_medak` is a **Proof Test (PT) Automation** form used in an optical fibre manufacturing plant (Sterlite Technologies).  
It automates data capture from the HORUS PT machine, computes cut lengths, and saves production records to an Oracle database.

Plants: **WALUJ** and **SHENDRA** (auto-detected via IP address).

---

## Process Flow

```
Draw Machine → Drawn Spool (MATSTOCK DRAW) → PT Machine → PT Fibre (MATSTOCK PT) → QA
```

1. Operator selects machine number; system allocates a draw spool from `PT_ALLOCATION`
2. `drawid_lostfocus` loads all spool metadata, flaw grid, previous PT log
3. Timer2 fires every 10 s → calls `EventRead` → logs events to `PTLOGIN`
4. Timer1 fires every 15 s → reads machine log file (`C:\GFP\LOG\dd-MM-yyyy.txt`)
5. On STOP/FAULT line: parses length, barcode, break flag → calls `Storedata`
6. `Storedata` runs a single Oracle transaction writing to 10+ tables
7. After commit: recalculates next cut length, refreshes flaw type, triggers `AllocateNextID` if balance ≤ 50 km

---

## All Tables Affected

| Table | Operations | Purpose |
|-------|-----------|---------|
| `MATSTOCK` | SELECT / INSERT / UPDATE | Stock register – draw spool decremented, PT fibre inserted |
| `MATMOVE` | INSERT (3 rows) | Movement log: 261=draw consumed, 551=draw rejection, 101=PT receipt |
| `PT` | INSERT | Main production record per bobbin (all fields detailed below) |
| `PTBARCODE` | SELECT / INSERT | Barcode–PTID mapping, RELLEN, PREFPOS, RICPreID |
| `PTCOLOR` | INSERT / UPDATE | Bobbin colour, bobbin type, deviation spool, bobbin number |
| `PT25TRACKING` | INSERT | Tracks bobbins ≥ 24,450 m (25 km class) |
| `PT50TRACKING` | INSERT | Tracks bobbins ≥ 48,850 m (50 km class, SHENDRA only) |
| `PTFLAW` | INSERT | Records missed/unresolved draw flaws at PT stop position |
| `PTIME_LOSS` | INSERT | Time-loss record if timeLoss ≥ 1 minute |
| `PRODREPORT_DRAW` | INSERT / UPDATE | Daily production report by draw tower |
| `PRODREPORT` | INSERT / UPDATE | Daily production report by process type |
| `DRAW` | SELECT | Spool metadata: drlen, botscrap, prremarks, coattype, product_type |
| `DRAWFLAW` | SELECT | Flaw positions – used for rejection reason lookup |
| `DRAWPITCHCHANGE` | SELECT / UPDATE | Pitch change segments; PITCH_STOP / PITCH_CUT updated |
| `PT_PITCH_STATUS` | INSERT / DELETE | Active pitch change tracking |
| `PTLOGIN` | INSERT | Machine event log (every 10 s via EventRead) |
| `PTLOGINSTATUS` | SELECT / INSERT / UPDATE | Tracks last-read file line per machine |
| `PT_ALLOCATION` | SELECT / UPDATE / DELETE | Spool-to-machine assignment |
| `MAINSPOOLREJECTION` | SELECT / INSERT | Spool unloaded due to Multiple End |
| `CUTTING_LOGIC` | SELECT | Standard PT cut length by tower number |
| `PT_CUTTING_LOGIC` | SELECT | Cut length override by product type + plant + length range |
| `STRETCH_TEMP` | SELECT | Preform stretch flag |
| `COREDEP` | SELECT | Product type lookup (PRODUCT_TYPE_E, PRODUCT_TYPE) |
| `RIC_PREFORM_ASSEMBLY` | SELECT | RIC preform rod assembly – product type + rod weights for RICPreID |
| `ORA_GLOBAL_PARAMS` | SELECT | Global flags (e.g. CHECK_PMD_TESTING) |
| `OPID_NEW` | SELECT | Operator / shift incharge list |
| `FORM_ACCESS_MASTER` | SELECT | Per-user access control to specific buttons |
| `MCSTATUS` | SELECT | Machine status (triggers AllocateNextID) |
| `TBL_RETRIVAL_TIMELOSS_STATUS` | SELECT | Config: bobbin length |
| `SINT_TRIAL` | SELECT | Special PT instructions per preform |
| `OVDD` | SELECT | Deposition machine, spindle number |
| `OVDS` | SELECT | Sintering machine number |
| `CORE_SINTER` | SELECT | Core sintering machine |
| `TL_ASSIGN` | SELECT | Time loss reason codes |
| `MASTER_CONSFACTOR` | SELECT | Consumable norms (alert/lock) |
| `CHILD_CONSFACTOR` | SELECT | Consumable change history |
| `MSENTRY` | SELECT | Main spool entry lock check |
| `PT_INST_ZTPMD` | SELECT / INSERT | ZTPMD reliability sample instructions |
| `ZTPMD_COIL_ENTRY` | SELECT | PMD coil entry records |
| `PTLOGINSTATUS` | SELECT / INSERT / UPDATE | Last-read event log line tracking |

---

## Storedata – Complete PT Table INSERT (every column)

This is the single most important function. All writes happen inside `cn.BeginTrans` / `cn.CommitTrans`.

### Step 0 – Pre-save time calculations (before any DB write)

| Variable | Formula | Purpose |
|----------|---------|---------|
| `d1t1` | DATE1 + TIME1 (machine stop time) | Machine stop datetime |
| `d2t2` | date2 + TIME2 (previous stop time) | Previous event datetime |
| `d3t3` | McStdate + McStTIME (machine start time) | Machine start datetime |
| `txtTimeLoss` | `(d3t3 - d2t2) * 24 * 60` capped to [0, 10000] | Minutes idle between last stop and this start |
| `BobbinActTime` | `(d1t1 - d3t3) * 24 * 60` | Minutes machine actually ran |
| `McSpeed` | 2200 m/min (or 2500 if machineNo ≥ 20) | Speed constant |
| `BobbinIdleTime` | `ptlen / McSpeed` | Expected run time at full speed |
| `txtSpeedLoss` | `BobbinActTime - BobbinIdleTime` capped to [0, 10000] | Speed-loss minutes |

> TimeLoss and SpeedLoss are both 0 when Check2 (BE Scrap) is active.

---

### Step 1 – Validations before transaction

| Check | Rule |
|-------|------|
| Shift Incharge | Must not be blank |
| Operator | Must not be blank |
| Bobbin Type | Must not be blank |
| Bobbin Color | Must not be blank |
| Vibration | Must not be blank |
| Dancer Vibration | Must not be blank |
| Bobbin Number | Must not be blank |
| Time Loss Reason | Required if timeLoss ≥ 1 minute |
| iPTContBrkFlag=2 | PTScrap length ≤ 4,300 m |
| iPTContBrkFlag=1 | PTScrap length ≤ 4,300 m |
| Normal | PTScrap length ≤ 4,225 m |
| ZTPMD | PTScrap length ≤ 250 m |
| Check1 + len > 4,200 | Confirm dialog (user must confirm draw rejection > 4.2 km) |
| Check1 + len > 40,000 | Hard block – draw rejection > 40 km not allowed |
| Check2 + DRReason ≠ S | Must select S for BE Scrap |
| Check2 + BE Scrap > txtBS + Minlen | Hard block |

---

### Step 2 – Minimum length (Minlen) rules

| Draw prefix | Minlen (metres) |
|-------------|----------------|
| D, N, A, Q | 4,250 |
| M, R | 2,200 |
| All others | 4,200 |

---

### Step 3 – Entry type classification

| Condition | ptlen result | scrqty | drrej |
|-----------|-------------|--------|-------|
| `Check1=1` (draw rejection) | 0 | 0 | original ptlen |
| `PTscrap=1 AND ptlen >= Minlen` | 0 | original ptlen | 0 |
| `ptlen < Minlen AND Check1=0` | 0 | original ptlen (becomes scrap) | 0 |
| Otherwise (OK fibre) | original ptlen | 0 | 0 |

Balance guard: if `abs(balqty - ptlen - scrqty - drrej) ≤ (Minlen-300)` → adjust scrqty to absorb remainder.

---

### Step 4 – PTID generation

```
Count = existing MATSTOCK PT rows with ID LIKE drawId%
If count >= 25  → PTID = drawId + 'Z' + Chr(count + 65 - 25)
Else            → PTID = drawId + Chr(count + 65)   → A, B, C … Y
```

---

### Step 5 – PT table INSERT (all columns)

| PT Column | Value | Notes |
|-----------|-------|-------|
| MATNO (RS(0)) | 330000126 / 330001937 / 330000155 / 330000183 | Based on draw prefix |
| FID (RS(1)) | drawId | |
| PRODDATE (RS(2)) | PRDate (Oracle SYSDATE at save time) | |
| OKLEN (RS(3)) | `Round(ptlen / 1000, 3)` km | 0 if scrap/rejection |
| SCRAP1 (RS(4)) | `Round(scrqty / 1000, 3)` km | PT scrap before OK |
| RS(5) (BRKCNT) | `Round(txtBrkCntLen / 1000, 3)` km | Break counter length |
| PROCESS (RS(6)) | 'PT' | |
| PTID (RS(7)) | Generated PTID | |
| MCNO (RS(8)) | machineNo | |
| BREAKID (RS(9)) | `drawId[10] + (totalBreaks+1)` | Only if nbreak > 0 |
| NBREAK (RS(10)) | nbreak (0 or 1) | |
| PTYPE (RS(11)) | ptype (first char of drawId) | |
| DRREJ (RS(12)) | `Round(drrej / 1000, 3)` km | |
| RS(13) | 0 | drrej2 placeholder |
| PREF_STRETCH | 'YES' / 'NO' | From STRETCH_TEMP table |
| REMARK | Remark.Text | Only if drrej > 0 |
| RS(15) / DRREJ1 | DRReason code (B/L/S/M/D/P/U) | Only if drrej > 0 |
| SAMPLE | 'ZTPMD' / 'DOC SAMPLE' / scrapReason | Mutually exclusive |
| OPR | operator[0..3] | |
| SHIFT_INCHARGE | shiftIncharge[0..9] | |
| FACTOR | `Round(Factor, 3)` if first bobbin (Stag=1), else `Round(txtFactor1, 3)` | km position of bobbin start |
| POS | `FACTOR - (ptlen + scrqty + drrej + brkCntLen) / 1000` | km position of bobbin end |
| SCRTYPE | txtScr.Text | |
| TIMELOSS | `Round(timeLossMins, 3)` | |
| LOGDATE | d1t1 | Machine log datetime |
| SPEEDLOSS | `Round(speedLossMins, 3)` | |
| **SPOS** | `Round((drQty - balQty) / 1000, 3)` km | **Start position in draw spool (from top)** |
| **EPOS** | `Round(SPOS + (ptlen + scrqty + drrej + brkCntLen) / 1000, 3)` km | **End position in draw spool** |
| SAMPLE_NO | 'F' if SPOS < 50 km / 'L' if (drQty/1000 - EPOS) < 50 km / else sequential integer | Only when OKLEN > 0 |
| DRAW_INFO | 'T' | If any silicone pitch segment (Grid3) overlaps [SPOS, EPOS] |
| DRAW_CLAD | 'Q' | If any BCSL/clad segment (Grid5) overlaps [SPOS, EPOS] |
| DRAW_AIR | 'A' | If any airline segment (Grid4) overlaps [SPOS, EPOS] |
| SLREASON | 'D'=draw reject / 'B'=actual break / 'M'=machine stop | |
| PTMODE | ptMode[0] (P/R/D) | |
| VIBRATION | txtVibration (uppercase) | |
| DANCER_VIBRATION | txtDancer (uppercase) | |
| PLANT | Get_Plant(drawId) | |
| LOGNAME | uname (logged-in user) | |
| COATTYPE | txtCoatType | |
| PRODUCT_TYPE | protype (resolved from DRAW/COREDEP/RIC_PREFORM_ASSEMBLY) | |
| FLAG50 | 'Y' if PT50=1 / 'N' otherwise | PT50 flag from ChkPT50 logic |
| SPINDLE | From OVDD.SPINDLE where DPREID like preid% | |
| MULTIEND_REASON | cmbmutiend.Text | Only if chkMERej = 1 |

---

### Step 6 – SPOS and EPOS exact formulas

```
SPOS = Round( (drQty_metres - balQty_metres) / 1000, 3 )  -- km from spool top

totalThisBobbin = ptlen + scrqty + drrej + brkCntLen       -- metres

EPOS = Round( SPOS + totalThisBobbin / 1000, 3 )           -- km from spool top
```

Both drQty and balQty are in **metres**. SPOS/EPOS are in **km**.

---

### Step 7 – PTBARCODE INSERT (only when ptlen >= Minlen)

| Column | Value |
|--------|-------|
| BARCODEID (RS(0)) | barcodeId (uppercase) |
| FID (RS(1)) | PTID |
| LENGTH (RS(2)) | `Round(ptlen, 3)` metres |
| MCNO (RS(3)) | machineNo |
| PDATE (RS(4)) | PRDate |
| RELLEN | `Round((drQty - balQty + ptlen) / 1000, 3)` km — distance from start of original draw spool |
| DIRECTION | 'E' |
| STATUS | 'D' |
| POPR | operator[0..3] uppercase |
| PROCESS | 'PT' |
| PLANT | Get_Plant(drawId) |
| PREFPOS | Same as PT.POS — `FACTOR - totalThisBobbin/1000` |
| RICPreID | Set after commit if RICPrefFlag is true (see RIC logic below) |

---

### Step 8 – PTCOLOR INSERT/UPDATE

| Column | Value |
|--------|-------|
| FID (RS(0)) | PTID |
| COLOR (RS(1)) | cboColor.Text |
| DATE (RS(2)) | PRDate |
| BOBBIN_TYPE | txtBobType.Text (uppercase) |
| DEV_SPOOL | chkDeviationSpol.Value |
| BOB_NO | Val(txtBobNo.Text) |
| PLANT | plant |
| PTLEN | `Round(ptlen / 1000, 3)` km |

Logic: if record already exists for PTID → UPDATE, else → INSERT.

---

### Step 9 – PT25TRACKING INSERT (when ptlen ≥ 24,450 m, non M/R/D/Q/N/A)

| Column | Value |
|--------|-------|
| FID | PTID |
| LENGTH | ptlen metres |
| STATUS | 'O' |
| PDATE | PRDate |
| PLANT | plant |

---

### Step 10 – PT50TRACKING INSERT (SHENDRA only, when ptlen ≥ 48,850 m)

Same structure as PT25TRACKING.

---

### Step 11 – PRODREPORT_DRAW upsert

Grouped by `(pdate, process=drawId[0], dtno=drawId[8..9])`:

| Column | Increment |
|--------|-----------|
| TOT_PT | `(ptlen + scrqty + brkCntLen) / 1000` km |
| PT_OK | `ptlen / 1000` km |
| DRAW_REJ | `drrej / 1000` km |
| PT_25 | 25.2 / 50.4 / 58.8 based on ptlen (see below) |
| PT_BRK | nbreak |

PT_25 logic:
- ptlen < 25,350 m → 0
- ptlen ≥ 58,900 m → 58.8
- ptlen ≥ 50,550 m → 50.4
- ptlen ≥ 25,350 m → 25.2

---

### Step 12 – PRODREPORT upsert

Same increments, grouped by `(pdate, process=drawId[0])` only.

---

### Step 13 – PTIME_LOSS INSERT (when timeLoss ≥ 1 minute)

| Column | Value |
|--------|-------|
| LDATE | PRDate |
| FIBREID | PTID |
| AREA | 'PT' |
| LOSSTYPE | txtTLReason.Text (uppercase) |
| TIMELOSS | timeLossMins |
| OPR | operator[0..2] |
| MCNO | machineNo |

---

### Step 14 – RIC Preform Rod Tracking (post-commit, if RICPrefFlag = true)

Source: `RIC_PREFORM_ASSEMBLY` table. For each rod, cumulative drawn km is calculated as:
```
RICFibDrawnperKG = (PREFWT * 37) / RODASSEMBLYWT
RICRod1DrawnKm = RICFibDrawnperKG * ROD1_WT
RICRod2DrawnKm = RICRod1DrawnKm + RICFibDrawnperKG * ROD2_WT
... (up to 7 rods)
```

The midpoint of the current bobbin is:
```
midpoint = (PrefPosStart + PrefPosEnd) / 2
```

The rod whose cumulative km exceeds the midpoint is identified as `RICPreID`.

Then **after commit**:
```sql
UPDATE PTBARCODE SET RICPREID = :RICPreID WHERE BARCODEID = :barcodeId
UPDATE PT         SET RICPREID = :RICPreID WHERE PTID = :ptid
```

---

### Step 15 – Post-commit state refresh (after cn.CommitTrans)

1. Reload `balqty` from MATSTOCK (or set to 0 and delete from PT_ALLOCATION if stock exhausted)
2. Call `GenerateSampleID` for Star bobbin sample IDs
3. If drawId starts with 'E': call `GenerateSampleID_mbend`
4. Update `date2 = DATE1`, `TIME2 = TIME1` (slide the time window forward)
5. Re-query DRAWFLAW at current balance position to refresh TypeOfFlaw
6. Call `PitchChange_Cut` → update DRAWPITCHCHANGE PITCH_CUT='Y'
7. Call `PitchChange_NextPos` → compute next pitch position for display
8. Call `PitchChange_Stop` → if draw rejection near a pitch zone, set PITCH_STOP='Y' + insert PT_PITCH_STATUS
9. Refresh txtFactor1 from `SELECT MIN(POS) FROM PT WHERE PTID LIKE drawId%`
10. Call `PTSOPNew` if nbreak > 0 → check continuous break counter, set iPTContBrkFlag
11. Call `Set_Length_Automatically(Fault)` → compute next SetLen
12. If balance ≤ 50 km and machine status = 'PT': call `AllocateNextID`
13. Set `datasaved = True`
14. Clear: barcodeId, ptlen, scrqty, drrej, timeLoss, speedLoss, bobbin fields, rejection checkboxes

---

## FACTOR and POS explained

`FACTOR` = absolute position (from top of entire multi-spool preform) of the **start** of this bobbin, in km.

`POS` = absolute position of the **end** of this bobbin = `FACTOR - totalConsumed/1000`.

On the first bobbin of a spool (`Stag=1`), `Factor` is calculated by `GetPos()`:
```
Factor = (thisSpoolDrLen - 0) + sum of all previous spools' drLen
```
For subsequent bobbins, `txtFactor1` holds the last saved POS, which becomes the next FACTOR.

`SPOS` and `EPOS` are **different** — they are relative to **this single draw spool**, not the whole preform:
```
SPOS = (drQty - balQty) / 1000       km from top of THIS spool
EPOS = SPOS + totalThisBobbin / 1000  km from top of THIS spool
```

---

## DRAW_INFO / DRAW_CLAD / DRAW_AIR Zone Marking

These flags are set by checking whether the bobbin's [SPOS, EPOS] range overlaps any zone in the pitch-change grids:

| Flag | Grid | Overlap check |
|------|------|--------------|
| DRAW_INFO = 'T' | Grid3 (silicone/pitch zones) | `Grid3.Cell(i,2) > SPOS AND < EPOS` OR `Grid3.Cell(i,3) > SPOS AND < EPOS` |
| DRAW_CLAD = 'Q' | Grid5 (BCSL/clad zones) | same overlap check |
| DRAW_AIR = 'A' | Grid4 (airline zones) | same overlap check |

All three checks run for every plant.

---

## Shift Determination

```
07:00–14:59 → 'A'
15:00–22:59 → 'B'
23:00–06:59 → 'C'
```

Shift is computed from local PC time at the moment Storedata runs.

---

## PTID Generation

```
Count = number of existing MATSTOCK PT rows with ID LIKE drawId%
If count >= 25 → PTID = drawId + 'Z' + Chr(count + 65 - 25)
Else           → PTID = drawId + Chr(count + 65)
```
Sequence: A, B, C … Y (25 values), then ZA, ZB … ZY (25 more)

---

## Material Numbers by Fibre Type

| Draw prefix | Draw MATNO | PT MATNO |
|-------------|-----------|---------|
| I, P, C, H, K, E (default SMF) | 330000126 | 330000127 |
| N, D, Q, A | 330001937 | 330001939 |
| M (multimode) | 330000155 | 330000156 |
| R (REW) | 330000183 | 330000184 |

---

## Minimum Length Rules

| Draw prefix | Minlen |
|-------------|--------|
| D, N, A, Q | 4,250 m |
| M, R | 2,200 m |
| All others | 4,200 m |

For MINLEN_NEW (SAP entry boundary):  
- Non-M/R/D/N/A/Q → 4,200 m  
- M/R/D/N/A/Q → use Minlen

---

## Rejection Codes (DRREJ1 / DRReason)

| Code | Meaning |
|------|---------|
| B | BFD (Bright Fibre Defect) |
| L | Lumps |
| A | Airline |
| C | SCD |
| S | Bottom End Scrap |
| M | Multiple End |
| D | Scratch |
| P | Pitch Change |
| U | Unknown / Machine fault |

---

## What Was Fixed in v2 (vs v1)

| Area | v1 Problem | v2 Fix |
|------|-----------|--------|
| SPOS | Described vaguely | Exact formula: `(drQty - balQty) / 1000` in km |
| EPOS | Described vaguely | Exact formula: `SPOS + (ptlen + scrqty + drrej + brkCntLen) / 1000` |
| FACTOR | Partially described | First bobbin: from `GetPos()`. Subsequent: from `txtFactor1` (MIN(POS) from PT table) |
| POS | Partially described | Exact: `FACTOR - totalThisBobbin / 1000` |
| PREFPOS in PTBARCODE | Missing | Same formula as PT.POS |
| RELLEN in PTBARCODE | Missing | `(drQty - balQty + ptlen) / 1000` km |
| SAMPLE_NO | Simplified | F = SPOS < 50 km; L = drQty/1000 - EPOS < 50 km; else MAX(existing)+1 |
| DRAW_INFO/CLAD/AIR | Described but not coded | Now checks both `fromKm` and `toKm` of each grid segment against [SPOS, EPOS] |
| PTCOLOR table | Missing entirely | Full INSERT/UPDATE with all columns |
| PT25TRACKING | Missing entirely | INSERT when ptlen >= 24,450 m |
| PT50TRACKING | Missing entirely | INSERT when ptlen >= 48,850 m (SHENDRA only) |
| PRODREPORT_DRAW | Missing entirely | Full upsert with PT_25 bucket logic |
| PRODREPORT | Missing entirely | Full upsert |
| PTIME_LOSS | Missing | Full INSERT with tlReason |
| RIC Preform tracking | Mentioned but not coded | Full post-commit rod midpoint lookup + UPDATE to PTBARCODE and PT |
| Product type resolution | 2 sources | All 4 sources: DRAW, COREDEP.PRODUCT_TYPE_E, COREDEP.PRODUCT_TYPE, RIC_PREFORM_ASSEMBLY |
| Time/Speed Loss calc | Passed as params | Auto-calculated from machine timestamps (d1t1, d2t2, d3t3) |
| isBEScrap (Check2) | Not handled | Disables TimeLoss/SpeedLoss calculation |
| PTID generation count | Wrong (used PT count 0..24) | Correct (matches VB6: count 0..24 → A..Y, 25+ → ZA..) |
| Break ID format | Wrong | Correct: `drawId[10] + (totalBreaks + 1)` |
| FLAG50 | Wrong trigger | Correct: from `ChkPT50` result passed as `pt50Flag` |
| SPINDLE | Missing | From OVDD, passed as `spindleNo` param |
| MULTIEND_REASON | Missing | Set when `isMERej = true` |


---

## Complete Operational Workflow

### Overview of All Possible Machine States

Every 15 seconds (Timer1), the system reads the machine log file. The log line tells the system **why** the machine stopped. From that single event, the entire downstream logic branches:

```
Machine stops
      │
      ├─ STOP → Stop Length reached      ← Normal bobbin complete (OK fibre)
      ├─ STOP → request by remote        ← Remote/manual stop (treated as normal)
      ├─ STOP → Fiber Break at TU Fiber Sensor  ← Actual fibre break
      └─ BCODE line with SCRAP flag      ← Automatic draw rejection
```

---

### Scenario 1 – Normal OK Bobbin (Most Common)

**Trigger:** Log line contains `STOP -> Stop Length reached` OR `STOP -> request by remote`

**What the machine log line provides:**
- `ptlen` = length value at field position 6 in the semicolon-delimited line
- `BCODE` line on the very next line = barcode ID scanned at the winder

**Flag states set by Timer1:**
```
nbreak  = 0        (no break)
nBreak1 = 1        (machine stopped, could be break or fault – but nbreak=0 so it's a stop)
tagDrrej = 0       (no draw rejection)
LENGHGET = True    (length was read, wait for BCODE line)
```

**Decision path:**
```
ptlen > 4200?
    YES → LENGHGET = True → wait for next BCODE line
           BCODE found? → txtBarcodeID = barcodeId → call Storedata()
    NO  → length too short, reset flags, do NOT call Storedata
ptlen <= 10? → update date2/TIME2 only, skip entry
```

**Storedata outcome:**
- `ptLenM = ptlen metres`  (OK fibre)
- `scrQtyM = 0`, `drRejM = 0`
- PT table: `OKLEN = ptlen/1000`, `NBREAK = 0`, `SLREASON = 'M'` (machine stop, not confirmed break)
- MATSTOCK: new PT fibre row inserted, draw spool stock reduced
- MATMOVE: 261 (draw consumed) + 101 (PT receipt)
- PTBARCODE: barcode row inserted with RELLEN, PREFPOS

**After save:**
- `Set_Length_Automatically` called → next SetLen computed
- `iPTContBrkCnt` reset to 0 (OK length resets break counter)

---

### Scenario 2 – Fibre Break (Sensor Break)

**Trigger:** Log line contains `STOP -> Fiber Break at TU Fiber Sensor`

**Flag states set by Timer1:**
```
nbreak  = 1        ← confirmed sensor break
nBreak1 = 1        ← machine stopped
tagDrrej = 0       (initially)
```

**Break counter length (txtBrkCntLen):**
```
Default = 250 metres  (length of fibre between break point and counter)
If ptlen < 1300 or ptlen > 23500 → brkCntLen = 50 metres
If brkCntLen > 300 → capped at 180 metres (machine known to display wrong value)
```

**Decision path:**
```
ptlen > 4200?
    YES → LENGHGET = True → wait for BCODE line
           BCODE with SCRAP flag? → tagDrrej = 1, Remark = "Fiber Break at Sensor"
                                  → call Storedata as DRAW REJECTION
           BCODE normal?          → call Storedata as OK fibre with break
    NO  → ptlen < 2200 AND tagDrrej=1 → Check1.value = 1 (auto draw rejection)
```

**Storedata outcome (break, ptlen >= minLen, no SCRAP flag):**
- `ptLenM = ptlen`, `scrQtyM = 0`, `drRejM = 0`
- PT table: `OKLEN = ptlen/1000`, `NBREAK = 1`, `BRKCNT = brkCntLenM/1000`
- `SLREASON = 'B'` (actBrk=1 confirmed actual break)
- `BREAKID = drawId[10] + (totalBreaks+1)`
- MATMOVE 261: qty = (ptlen + brkCntLen) / 1000 (counter length is also consumed from draw stock)

**Storedata outcome (break with SCRAP flag from BCODE line, or ptlen < 2200):**
- Treated as Draw Rejection
- `drRejM = ptlen`, `ptLenM = 0`
- PT table: `DRREJ = drRejM/1000`, `NBREAK = 1`, `SLREASON = 'B'`
- `DRReason = TypeOfFlaw` (auto-detected from DRAWFLAW near current position)
- MATMOVE 551: draw rejection movement

**iPTContBrkCnt increment:**
```
After save:
  If ptlen = 0 AND nbreak > 0 → iPTContBrkCnt++
  If ptlen/1000 > 2.2 → iPTContBrkCnt = 0 (reset)
```

**PTSOPNew called if nbreak > 0:**
```
iPTContBrkCnt == 3 → iPTContBrkFlag = 1 → Alert: "3 Brks, Scrap 4.2 KM"
iPTContBrkCnt > 3  → iPTContBrkFlag = 2 → Alert: "1 Cont. Brk(After 3 Brks) Scrap 4.2 KM"
```

**Next SetLen after break:**
```
iPTContBrkFlag = 1 or 2 → SetLen forced to 4.2 km
                         → goForSample = 0 (no reliability sample)
```

---

### Scenario 3 – Automatic Draw Rejection (tagDrrej)

**Trigger:** BCODE line contains `SCRAP` keyword (machine detected automatic draw rejection)

**Flag states:**
```
tagDrrej = 1
Remark   = "Automatic Draw Rejection"  (or "Fiber Break at Sensor" if nbreak=1)
Check1.value auto-set if ptlen < 2200
```

**How rejection reason (TypeOfFlaw / DRReason) is determined automatically:**

Step 1 – Look at DRAWFLAW position within ±2 km of current balance position:
```sql
SELECT * FROM DRAWFLAW
WHERE FID = drawId
  AND POSITION > (balqty/1000 - 2)
  AND POSITION < (balqty/1000 + 2)
```
Remark matching:
```
Starts with 'L' or = 'LUMPS'       → TypeOfFlaw = 'L', Remark = 'LUMPS'
Starts with 'B' or = 'BFD'         → TypeOfFlaw = 'B', Remark = 'BFD'
Starts with 'A' or = 'AIRLINE'     → TypeOfFlaw = 'A', Remark = 'AIRLINE'
= 'SCD' or 'CD2'                   → TypeOfFlaw = 'C', Remark = 'SCD'
= 'PITCHCHANGE' (if no other set)  → TypeOfFlaw = 'P', Remark = 'PITCHCHANGE'
None found                         → TypeOfFlaw = 'U', Remark = 'UNKNOWN'
```

Step 2 – If still not found, broader search (DRAWFLAW for entire spool, nearest position < balqty/1000):
```sql
SELECT * FROM DRAWFLAW WHERE FID = drawId AND POSITION < balqty/1000
ORDER BY POSITION DESC
```
Same remark matching. Fault distance = `balqty - position * 1000` metres.
If Fault < 2000 m → flaw is close, set TypeOfFlaw.

**Storedata outcome:**
- `drRejM = ptlen`, `ptLenM = 0`, `scrQtyM = 0`
- PT table: `DRREJ = drRejM/1000`, `DRREJ1 = TypeOfFlaw`, `REMARK = TypeOfRemark`
- `SLREASON = 'D'`
- MATMOVE 551: draw rejection
- No PTBARCODE insert (no OK fibre)

**PitchChange_Stop called after save:**
```
If tagDrrej = 1:
  Search grdFlaw for pitch segment within ±3.5 km of current position
  If found:
    DRAWPITCHCHANGE.PITCH_STOP = 'Y'
    INSERT INTO PT_PITCH_STATUS
    chkFlaw.value = 1
    txtFlawMsg = "CUT {cuttingLen} KM FOR DRAW REJECTION"
    Default cutting len = 0.5 km
    If segment cutting len < 0.5 → use 0.5 km
```

**PitchChange_Cut called next cycle:**
```
If (drrej + scrqty)/1000 + 0.25 > txtCuttingLen:
  DRAWPITCHCHANGE.PITCH_CUT = 'Y'
  grdFlaw cell image → Checked
  DELETE FROM PT_PITCH_STATUS
Else:
  txtCuttingLen = txtCuttingLen - drrej/1000  (reduce remaining cut)
  Still showing "CUT X KM" message
```

---

### Scenario 4 – Manual Draw Rejection (Check1)

**Trigger:** Operator checks the "Rejection" checkbox (Check1)

**Auto-fill logic (same as automatic):**
- Queries DRAWFLAW within ±2 km of current balance
- Sets TypeOfFlaw and DRReason automatically
- If Check2 (BE Scrap) is also checked → TypeOfFlaw = 'S', Remark = 'BESCRAP'

**Validation in Storedata:**
```
drRej > 4,200 m → confirmation dialog shown
drRej > 40,000 m → hard block
```

**Storedata outcome:** same as Scenario 3.

---

### Scenario 5 – Balance Draw Rejection / BE Scrap (Check2)

**Trigger:** Operator checks "Balance Draw Rejection" checkbox

**Auto-behaviour:**
```
ptlen = balqty   (set to full remaining balance)
Check1.value = 1
TypeOfFlaw = 'S', DRReason = 'S', Remark = 'BESCRAP'
Storedata called immediately
```

**Validation:**
```
DRReason must = 'S' (else blocked)
ptlen must not exceed txtBS (bottom scrap from draw) + Minlen
```

**Storedata outcome:**
- `drRejM = full remaining balance`, `ptLenM = 0`
- TimeLoss and SpeedLoss both forced to 0 (Check2 disables them)
- SLREASON = 'D'

---

### Scenario 6 – PT Scrap (Short Length)

**Trigger (automatic):** ptlen < Minlen AND Check1 = 0 → auto-classified as scrap

**Trigger (manual):** Operator checks PTscrap checkbox and selects a scrap reason

**Validation:**
```
iPTContBrkFlag = 1 or 2 → scrap must be ≤ 4,300 m
Normal → scrap must be ≤ 4,225 m
ZTPMD mode → scrap must be ≤ 250 m
```

**Storedata outcome:**
- `scrQtyM = ptlen`, `ptLenM = 0`, `drRejM = 0`
- PT table: `SCRAP1 = scrQtyM/1000`
- MATMOVE 261 only (no 101 receipt, no PTBARCODE)
- `SAMPLE = scrapReason` if PTscrap is manual

---

### Scenario 7 – Pitch Change Zone Detected

**Trigger:** On spool load, `PitchChange_Detail` reads `DRAWPITCHCHANGE` table and populates grdFlaw grid.

**What the grid shows per pitch segment:**
```
Col 0 = index
Col 1 = PITCH_STOP flag (checked/unchecked icon)
Col 2 = PITCH_REASON (BFD, LUMPS, SCD, etc.)
Col 3 = toKm (end of flaw zone) = drQty/1000 - PITCH_END
Col 4 = fromKm (start of warning zone) = drQty/1000 - PITCH_START + stopGap
Col 5 = cutting length = fromKm - toKm
Col 6 = PITCH_CUT flag
```

**Stop gap by tower number:**
```
Tower < 20   → stopGap = 0.25 km
Tower 20–39  → stopGap = 0.35 km
Tower ≥ 40   → stopGap = 0.40 km
```

**PitchChange_NextPos – called every cycle when chkFlaw = 0:**
```
Find first pitch segment where toKm > currentPosition AND PITCH_STOP = 'N' (unchecked)
NextFlawPos = segment.toKm - currentPosition    (km remaining to reach flaw)

If NextFlawPos < 60 km → txtFlawMsg = "NEXT PITCH CHANGE AT {x} KM"
If NextFlawPos < 4.2 km → call PitchChange_Reason(i) to set TypeOfFlaw
NextFlawPosGlobal = NextFlawPos   (used by Set_Length_Automatically)
```

**Effect on SetLen (WALUJ):**
```
If flawMsg starts with 'NEXT':
  NextFlawPos < 4.6 km → SetLen = 4.6 km
  NextFlawPos >= StandardLen → SetLen = StandardLen
  Otherwise → SetLen = NextFlawPos - 0.15 km
```

**On first spool load (balqty = drqty):**
```
For each pitch segment where toKm < 4.2 km:
  Auto-set PITCH_STOP = 'Y' in DRAWPITCHCHANGE
  Display "CUT {len} KM FOR DRAW REJECTION"
  chkFlaw = 1
```

---

### Scenario 8 – Multiple End Rejection

**Trigger:** Operator checks chkMERej checkbox

**Flag states:**
```
DRReason = 'M'
TypeOfFlaw = 'M'
TypeOfRemark = 'ME'
Check1 = 1
cmbmutiend → visible (select ME reason)
```

**Two paths:**

**Path A – Unload spool (cmdUnloadME button):**
```
INSERT INTO MAINSPOOLREJECTION (SPOOLID, LENGTH, Operator, Reason='MULTIPLE END')
UPDATE PT_ALLOCATION SET ALLOCATE='H', UNLOAD='T', UNLOAD_REASON='MULTIPLE END'
drawid cleared
```

**Path B – Record and continue (Storedata with DRReason='M'):**
```
drRejM = ptlen
PT.DRREJ1 = 'M'
PT.MULTIEND_REASON = cmbmutiend.Text
SLREASON = 'D'
```

---

### Scenario 9 – Scratch Rejection

**Trigger:** Operator checks ChkScratch checkbox

**Flag states:**
```
DRReason = 'D'
TypeOfFlaw = 'D'
TypeOfRemark = 'SCR'
Check1 = 1
FlagScratch = True (set at spool load if SCR_OBS = 'YES' in DRAW table)
```

**Effect on SetLen when FlagScratch = True AND first bobbin (totalPTDone = 0):**
```
SetLen = 4.2 km   (force minimum cut for first bobbin of a scratched spool)
```

---

### Scenario 10 – ZTPMD Sample (chkpmd)

**Trigger:** Operator checks ZTPMD checkbox, OR `HoldForInst = True` from previous save

**Validation:** ptlen must be ≤ 250 m

**Storedata outcome:**
- `scrQtyM = ptlen` (treated as scrap since very short)
- PT table: `SAMPLE = 'ZTPMD'`
- After save: `FlagPMD = True` → next `Set_Length_Automatically` forces SetLen = 0.22 km

---

### Complete Flag State Summary

| Flag | Default | Set by | Cleared by | Effect |
|------|---------|--------|-----------|--------|
| `nBreak` | 0 | Fiber break log line | After Storedata | nBreak=1 → NBREAK=1, SLREASON='B', brkCntLen=250m default |
| `nBreak1` | 0 | Any machine stop | After Storedata | nBreak1=1 → SLREASON='M' if nBreak=0 |
| `actBrk` | 0 | Currently not set in Medak (commented out) | After Storedata | actBrk=1 → SLREASON='B' |
| `tagDrrej` | 0 | BCODE+SCRAP in log | After Storedata | tagDrrej=1 → treat as draw rejection |
| `LENGHGET` | False | ptlen > 4200 detected | BCODE found + Storedata done | Waits for barcode before saving |
| `chkFlaw` | 0 | PitchChange_Stop / PitchChange_Detail | PitchChange_Cut | chkFlaw=1 → skip PitchChange_NextPos, show cut instruction |
| `iPTContBrkCnt` | 0 | Each break with ptlen=0 | ptlen/1000 > 2.2 at spool load | Triggers PTSOPNew at 3 and 4+ |
| `iPTContBrkFlag` | 0 | PTSOPNew: 1 at 3 brks, 2 after | After Storedata | Forces SetLen = 4.2 km |
| `FlagPMD` | False | HoldForInst=True after save | Set_Length_Automatically | Forces SetLen = 0.22 km |
| `FlagScratch` | False | SCR_OBS='YES' in DRAW + first bobbin | After first bobbin saved | Forces SetLen = 4.2 km |
| `PT50Flag` | True | ChkPT50 analysis | ChkPT50 analysis | True → FLAG50='Y', allows 50km bobbin |
| `datasaved` | False | Start of Timer1 | Set to True after Storedata commits | Prevents double-save in same cycle |
| `Stag` | 0 | drqty=balqty (first bobbin) | After Storedata (Stag=0) | Stag=1 → use GetPos() for Factor |

---

### Break Counter Length (brkCntLenM) Rules

This accounts for the length of fibre that is unwound off the bobbin when a break occurs (between break point and counter reset).

```
If nbreak = 0             → brkCntLen = 0
If nbreak = 1:
  Default                 → brkCntLen = 250 metres
  ptlen < 1300 or > 23500 → brkCntLen = 50 metres
  If brkCntLen > 300      → brkCntLen = 180 metres
  Same edge case applies  → 50 metres
```

brkCntLen is included in:
- MATSTOCK deduction
- MATMOVE 261 quantity
- PT.BRKCNT
- SPOS/EPOS/FACTOR/POS calculations

---

### Cutting Length Decision Tree (Set_Length_Automatically)

```
Is it a K/D/L/Q/A type draw?
  YES → StandardLen = 26 km
  NO  → Read CUTTING_LOGIC table by tower → StandardLen (typically 24.75, 25.6, 49.15, 50.85 km)

Is it SHENDRA plant AND product type L1?
  YES → StandardLen = 24.8 km

iPTContBrkFlag = 1 or 2?
  YES → SetLen = 4.2 km  [STOP - overrides everything below]

FlagPMD = True?
  YES → SetLen = 0.22 km  [STOP]

flawMsg starts with 'CUT'?
  YES → SetLen = cuttingLenKm (from pitch grid)  [STOP]

flawMsg starts with 'NEXT' (WALUJ only)?
  NextFlawPos < 4.6 km      → SetLen = 4.6 km
  NextFlawPos >= StandardLen → SetLen = StandardLen
  Otherwise                 → SetLen = NextFlawPos - 0.15 km

No flaw message:
  SetLen = StandardLen
  FlagScratch=True AND first bobbin → SetLen = 4.2 km
  (balQty - bottomScrap) in [4.2, StandardLen] → SetLen = balQty - bottomScrap

SHENDRA only, no CUT message:
  NextFlawPos < 26 km            → SetLen = 25.6 km
  NextFlawPos in (38.6, 50.85)   → SetLen = 25.6 km

WALUJ adjustments:
  balQty < 76 km AND SetLen > 26  → SetLen = 25.4 km
  PTID 12th char = A or B         → SetLen = 25.4 km if > 26
  SetLen in (38.2, 50.45) AND (SetLen-25.45) >= 12.7 → SetLen = 25.6 km

Product type E1 (both plants):
  Complex multi-bobbin logic based on count of bobbins already cut:
  0 bobbins done → SetLen = 25.75 km (adjusted for remaining balance)
  1+ bobbins done → SetLen = 13 km (adjusted for remaining balance)

PT_CUTTING_LOGIC table override:
  If SetLen falls in a defined [MIN_VAL, MAX_VAL] range for this product type+plant
  AND table length <= bobbinLength → use table length

Reliability sample check (if goForSample=1):
  WALUJ → SetLen = 0.2 km
  SHENDRA → SetLen = 0.5 km
```

---

### What Happens When Balance Reaches Zero

```
After Storedata commit:
  Read fresh MATSTOCK balance
  If balqty = 0:
    DELETE FROM PT_ALLOCATION WHERE SPOOL_ID = drawId
    drawid = ""  (cleared)
    Form auto-closes (cmdexit_Click)
```

---

### AllocateNextID – Pre-loading Next Spool (balance ≤ 50 km)

```
Condition: ptype NOT in (M, R) AND balqty/1000 in (0, 50]
           AND mcstatus.Status = 'PT' for this machine

Action:
  Query PT_ALLOCATION WHERE mcno = machineNo AND priority = '2'
  If found:
    Display next spool ID and its length to operator
    Show DRAW_BARCODEID from DRAW table (the physical label on the spool)
  Else:
    Auto-calculate via frmPTAllocation logic
    Display result
```

---

---

## First Piece and Last Piece Definition

### What is a "First Piece" (FPcFlag)?

A bobbin is the **first piece** of a draw spool if its PTID matches the **minimum (earliest) PTID** ever saved for that spool — i.e., it is the very first OK-length bobbin ever cut from this draw spool.

**How it is detected (in `GenerateSampleID`):**
```sql
SELECT MAX(PTID), MIN(PTID)
FROM PT
WHERE PTID LIKE drawId%  AND OKLEN > 0
```
```
If PTID[0..11] = MIN(PTID)[0..11]  →  FPcFlag = True
```
This means: the first 12 characters of the current PTID match the earliest PTID on record.

**What happens when FPcFlag = True:**
- `L25Flag = True`   → bobbin is within first 25 km zone
- `L50Flag = True`   → bobbin is within first 50 km zone
- `FLTarget = True`  → mark as First/Last target (special handling for OTDR/testing)
- No SamplingID is generated (proceed = 0, function exits early)

**Relationship to SAMPLE_NO = 'F':**
The PT table's `SAMPLE_NO = 'F'` is set independently during Storedata based purely on position:
```
SAMPLE_NO = 'F'  when  SPOS < 50 km
```
This means **any bobbin whose start position is within the first 50 km** of the draw spool gets SAMPLE_NO = 'F', not just the absolute first piece. FPcFlag is a stricter, identity-based check used for the Star Bobbin sampling system.

---

### What is a "Last Piece" (LPcFlag)?

A bobbin is the **last piece** of a draw spool if:
1. The draw spool's MATSTOCK balance has been reduced to **zero** (`stockqty = 0`)
2. The current PTID matches the **maximum (latest) PTID** on record for the spool

**Detection:**
```sql
-- Step 1: check if spool is exhausted
SELECT STOCKQTY FROM MATSTOCK WHERE ID = drawId[0..10]  AND MATNO = '330000126'
If STOCKQTY = 0 → LP = True

-- Step 2: check if this is the final PTID
SELECT MAX(PTID), MIN(PTID) FROM PT WHERE PTID LIKE drawId%  AND OKLEN > 0
If LP = True AND PTID[0..11] = MAX(PTID)[0..11]  →  LPcFlag = True
```

**What happens when LPcFlag = True:**
- `F25Flag = True`   → bobbin is within last 25 km zone
- `F50Flag = True`   → bobbin is within last 50 km zone
- `FLTarget = True`  → mark as First/Last target
- No SamplingID is generated (proceed = 0, function exits early)

**Relationship to SAMPLE_NO = 'L':**
The PT table's `SAMPLE_NO = 'L'` is set during Storedata based on position:
```
SAMPLE_NO = 'L'  when  (drQty/1000 - EPOS) < 50 km
```
Same idea — any bobbin whose end position is within the last 50 km gets SAMPLE_NO = 'L'. LPcFlag is the identity-based check used for the Star Bobbin / OTDR sampling system.

---

### First/Last 50 km Zones (L50Flag / F50Flag) via Position

Computed inside `GenerateSampleID` from PT.EPOS and PT.SPOS:
```
SpStLen = drlen - EPOS       (distance from top of spool to start of bobbin)
SpEdLen = SpStLen + OKLEN    (distance from top of spool to end of bobbin)

L50Flag = True   if SpStLen < 50 km   (bobbin is in first 50 km)
L25Flag = True   if SpStLen < 25 km   (bobbin is in first 25 km)

F50Flag = True   if (drlen - SpEdLen) < 50 km  (bobbin is in last 50 km)
F25Flag = True   if (drlen - SpEdLen) < 25 km  (bobbin is in last 25 km)
```

If `F25Flag = True OR L25Flag = True` → `FLTarget = True`, no SamplingID generated.

---

### Summary Table: First/Last Piece Flags

| Flag | Meaning | How Set | Effect |
|------|---------|---------|--------|
| `FPcFlag` | First OK piece of the spool (by PTID identity) | MIN(PTID) match | FLTarget=T, L25+L50 set, no SamplingID |
| `LPcFlag` | Last OK piece of the spool (stock=0 + MAX PTID) | LP=T + MAX(PTID) match | FLTarget=T, F25+F50 set, no SamplingID |
| `L50Flag` | Bobbin within first 50 km of draw spool | SpStLen < 50 | FLTarget if also L25 |
| `L25Flag` | Bobbin within first 25 km of draw spool | SpStLen < 25 | FLTarget=T, no SamplingID |
| `F50Flag` | Bobbin within last 50 km of draw spool | drlen-SpEdLen < 50 | FLTarget if also F25 |
| `F25Flag` | Bobbin within last 25 km of draw spool | drlen-SpEdLen < 25 | FLTarget=T, no SamplingID |
| `SAMPLE_NO = 'F'` | Position-based first 50 km marker in PT table | SPOS < 50 km | Stored in PT.SAMPLE_NO |
| `SAMPLE_NO = 'L'` | Position-based last 50 km marker in PT table | drQty/1000 - EPOS < 50 | Stored in PT.SAMPLE_NO |

---

## Adjacent Bobbin Flaw Flagging

### What Exists Today

The current code checks whether a bobbin is **adjacent to a draw flaw** only inside `GenerateSampleID`, specifically to block Star Bobbin selection:

```sql
SELECT REMARK FROM DRAWFLAW
WHERE FID = drawId[0..10]
  AND POSITION > (SpStLen - 1)      -- 1 km before bobbin start
  AND POSITION < (SpEdLen + 1)      -- 1 km after bobbin end
```

If a `BFD`, `B`, or `PITCHCHANGE` remark is found in this ±1 km window:
```
BFDFlag = True
```

**Effect of BFDFlag = True:**
- Star Bobbin SamplingID is **not generated** for this bobbin
- The bobbin is not selected for the OTDR range-based testing programme
- No flag is written to the PT table — BFDFlag only lives in memory

**Limitation:** `BFDFlag` is a transient in-memory flag. It is not stored in any database column and is not visible in any report. The only persisted adjacency information is the indirect markers `DRAW_INFO='T'`, `DRAW_CLAD='Q'`, and `DRAW_AIR='A'` in the PT table, but these only fire when the flaw zone **overlaps** the bobbin's own [SPOS, EPOS] range — not the bobbins immediately before or after.

---

### [SUGGESTION] Flagging Adjacent Bobbins to Flaw Positions

**Problem:** A flaw like BFD or Lump causes a draw rejection (drrej). The bobbins immediately **before** and **after** that rejection zone are the ones physically closest to the defect in the preform. Currently, these neighbours are not marked in any way. QA teams have no automatic way to know that, for example, bobbin `IB0123410A` was cut right next to a BFD rejection without manually cross-referencing the flaw map.

**Suggestion 1 – New column: PT.FLAW_ADJACENT**

Add a column `FLAW_ADJACENT VARCHAR2(1)` to the PT table. Set it during Storedata by checking whether the current bobbin's extended window overlaps any flaw:

```sql
-- Check drawflaw within 1 km before SPOS or 1 km after EPOS
SELECT COUNT(*) FROM DRAWFLAW
WHERE FID = :drawId
  AND POSITION > (:spos - 1)
  AND POSITION < (:epos + 1)
  AND REMARK IN ('BFD','LUMPS','SCD','AIRLINE')
```
- If count > 0 → `FLAW_ADJACENT = 'Y'`
- This is stored permanently in PT and is queryable

**Suggestion 2 – Backfill the previous bobbin**

When a draw rejection is saved (drRejM > 0), the **previous** PT record (the last bobbin saved before this rejection) is also adjacent to the flaw. A post-commit UPDATE can flag it:

```sql
-- After committing a draw rejection entry, backfill the previous bobbin
UPDATE PT
SET FLAW_ADJACENT = 'Y'
WHERE PTID = (
  SELECT PTID FROM PT
  WHERE FID = :drawId AND OKLEN > 0
  ORDER BY PRODDATE DESC
  FETCH FIRST 1 ROW ONLY
)
```

This way both the bobbin cut **before** the flaw (previous OK piece) and the bobbin cut **after** (next OK piece, whose SPOS starts within 1 km of the flaw) are marked.

**Suggestion 3 – Severity level instead of a binary flag**

Instead of Y/N, use a coded value in `FLAW_ADJACENT`:

| Value | Meaning |
|-------|---------|
| `B` | Adjacent to BFD zone |
| `L` | Adjacent to Lumps zone |
| `C` | Adjacent to SCD zone |
| `A` | Adjacent to Airline zone |
| `P` | Adjacent to Pitch Change zone |
| `X` | Multiple flaw types adjacent |

This makes it trivial to filter in QA reports: "show all bobbins adjacent to BFD" is a simple `WHERE FLAW_ADJACENT = 'B'`.

**Suggestion 4 – Extend PTBARCODE with the same flag**

Since PTBARCODE is the table used by downstream QA and dispatch systems, adding `FLAW_ADJACENT` there as well (written at the same time as the PT insert) ensures the flag travels with the physical bobbin through the entire production chain.

**Suggested implementation in Storedata (after the PT INSERT, before commit):**

```sql
-- 1. Flag current bobbin if its window touches any flaw
UPDATE PT SET FLAW_ADJACENT = :flawCode
WHERE PTID = :ptid
  AND EXISTS (
    SELECT 1 FROM DRAWFLAW
    WHERE FID = :drawId
      AND POSITION > (:spos - 1)
      AND POSITION < (:epos + 1)
  )

-- 2. If current entry is a draw rejection, backfill the previous OK bobbin
-- (run only when drRejM > 0)
UPDATE PT SET FLAW_ADJACENT = NVL(FLAW_ADJACENT, :flawCode)
WHERE PTID = (
  SELECT PTID FROM (
    SELECT PTID FROM PT
    WHERE FID = :drawId AND OKLEN > 0
    ORDER BY PRODDATE DESC
  ) WHERE ROWNUM = 1
)
```

**What this enables:**
- QA can immediately query `SELECT * FROM PTBARCODE WHERE FLAW_ADJACENT IS NOT NULL`
- Reports can show "bobbins within 1 km of a BFD" across all spools
- The flag travels with the bobbin through testing and dispatch — no manual cross-referencing needed
- No change to the existing Storedata flow other than two additional UPDATE statements after the main INSERT

---
