"""
MainWindow — PyQt6 UI for OTDR Automation (converted from WinForms frmotdr)
"""
from __future__ import annotations
import os
import sys
from datetime import datetime, date
from pathlib import Path
from typing import List, Optional

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QDateEdit,
    QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox, QHeaderView,
)
from PyQt6.QtCore import Qt, QTimer, QDate
from PyQt6.QtGui import QColor, QFont

from src.domain.models import FiberRecordDataView, OperatorData, Instrument, FiberRecord
from src.domain.master_thresholds import MasterThresholds
from src.domain.mapper import to_fiber_record_list
from src.infrastructure.db_connection import load_connection_string
from src.infrastructure.fiber_record_repository import (
    insert_fiber_records,
    get_fiber_records_by_date,
    get_fiber_records_by_date_operator,
    get_all_active_operators,
    get_all_active_instruments,
)
from src.infrastructure.otdr_parser import (
    parse_file, is_file_ready, is_file_locked, contains_end_time,
)
from src.infrastructure.otdr_analysis import analyze, process


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OTDR Automation - Python")
        self.resize(1520, 950)

        # State
        self.master_thresholds = MasterThresholds()
        self.operators_list: List[str] = []
        self.timer = QTimer()
        self.timer.setInterval(5000)
        self.timer.timeout.connect(self._on_timer_tick)
        self.enable_timer = False

        self.fiber_records: List[FiberRecord] = []

        # Load config
        base = Path(__file__).parent.parent.parent
        config_path = base / "config" / "appsettings.json"
        self.config_txt_path = base / "config" / "config.txt"
        load_connection_string(str(config_path))

        self.master_thresholds, self.operators_list = MasterThresholds.load_from_file(
            str(self.config_txt_path)
        )

        # Build UI
        self._build_ui()
        self._load_operators()
        self._load_instruments()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # --- Header ---
        header = QLabel("OTDR Automation")
        header.setStyleSheet("font-size: 48px; font-weight: bold; color: teal;")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)

        # --- Main content area (left data + right controls) ---
        content = QHBoxLayout()
        layout.addLayout(content)

        # Left: tables
        left = QVBoxLayout()
        content.addLayout(left, stretch=4)

        # Summary grid (last 3 bobbins)
        summary_label = QLabel("Last Processed Bobbins")
        summary_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        left.addWidget(summary_label)

        self.grid_bobbin = QTableWidget(3, 5)
        self.grid_bobbin.setHorizontalHeaderLabels(
            ["Fiber ID", "Fiber Length", "Status", "Reason", "Remark"]
        )
        self.grid_bobbin.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.grid_bobbin.setFixedHeight(160)
        self.grid_bobbin.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        left.addWidget(self.grid_bobbin)

        # Main data grid (all fiber records)
        data_label = QLabel("Fiber Records")
        data_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        left.addWidget(data_label)

        self.grid_fiber_data = QTableWidget()
        self.grid_fiber_data.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.grid_fiber_data.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        left.addWidget(self.grid_fiber_data, stretch=1)

        # --- Right panel ---
        right = QVBoxLayout()
        right.setSpacing(6)
        content.addLayout(right, stretch=1)

        # Date range
        right.addWidget(QLabel("From Date:"))
        self.dtp_from = QDateEdit()
        self.dtp_from.setDate(QDate.currentDate())
        self.dtp_from.setCalendarPopup(True)
        right.addWidget(self.dtp_from)

        right.addWidget(QLabel("To Date:"))
        self.dtp_to = QDateEdit()
        self.dtp_to.setDate(QDate.currentDate())
        self.dtp_to.setCalendarPopup(True)
        right.addWidget(self.dtp_to)

        btn_report = QPushButton("Generate Fiber Report")
        btn_report.clicked.connect(self._on_generate_report)
        right.addWidget(btn_report)

        btn_op_analysis = QPushButton("Operator Analysis")
        btn_op_analysis.clicked.connect(self._on_operator_analysis)
        right.addWidget(btn_op_analysis)

        self.chk_hourly = QCheckBox("Hourly Wise")
        right.addWidget(self.chk_hourly)

        btn_export = QPushButton("Export to Excel")
        btn_export.clicked.connect(self._on_export_excel)
        right.addWidget(btn_export)

        # OTDR No
        right.addWidget(QLabel("OTDR No:"))
        self.cmb_otdr_no = QComboBox()
        right.addWidget(self.cmb_otdr_no)

        # Operator
        right.addWidget(QLabel("Operator:"))
        self.cmb_operator = QComboBox()
        right.addWidget(self.cmb_operator)

        # File path
        right.addWidget(QLabel("OTDR File Path:"))
        path_row = QHBoxLayout()
        self.txt_path = QLineEdit(r"\\OTDRNEW\TEST")
        path_row.addWidget(self.txt_path)
        btn_browse = QPushButton("📁")
        btn_browse.setFixedWidth(36)
        btn_browse.clicked.connect(self._on_browse)
        path_row.addWidget(btn_browse)
        right.addLayout(path_row)

        # Timer controls
        timer_row = QHBoxLayout()
        self.btn_start = QPushButton("Start")
        self.btn_start.setStyleSheet("background-color:#2e7d32;color:white;font-weight:bold;")
        self.btn_start.clicked.connect(self._on_start_timer)
        self.btn_end = QPushButton("End")
        self.btn_end.setStyleSheet("background-color:#c62828;color:white;font-weight:bold;")
        self.btn_end.setEnabled(False)
        self.btn_end.clicked.connect(self._on_end_timer)
        timer_row.addWidget(self.btn_start)
        timer_row.addWidget(self.btn_end)
        right.addLayout(timer_row)

        self.chk_msgbox = QCheckBox("Enable Messagebox")
        right.addWidget(self.chk_msgbox)

        self.chk_store_db = QCheckBox("Save Data In DB")
        self.chk_store_db.setChecked(True)
        right.addWidget(self.chk_store_db)

        btn_export_analysis = QPushButton("Export Fiber Analysis")
        btn_export_analysis.clicked.connect(self._on_export_analysis)
        right.addWidget(btn_export_analysis)

        right.addStretch()

        # Footer
        footer = QLabel("Designed and Developed by FioeT Private Limited © 2025")
        footer.setStyleSheet("color: lightseagreen; font-weight: bold;")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(footer)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _load_operators(self):
        try:
            ops = get_all_active_operators()
            self.cmb_operator.clear()
            self.cmb_operator.addItem("-- Select Operator --", 0)
            for op in ops:
                self.cmb_operator.addItem(op.name, op.id)
        except Exception:
            # Fallback to config.txt list if DB unavailable
            self.cmb_operator.clear()
            self.cmb_operator.addItem("-- Select Operator --", 0)
            for name in self.operators_list:
                self.cmb_operator.addItem(name, name)

    def _load_instruments(self):
        try:
            instruments = get_all_active_instruments()
            self.cmb_otdr_no.clear()
            for inst in instruments:
                self.cmb_otdr_no.addItem(inst.name, inst.id)
        except Exception:
            self.cmb_otdr_no.addItem("OTDR 1", 1)
            self.cmb_otdr_no.addItem("OTDR 2", 2)

    def _load_summary(self, records: List[FiberRecordDataView]):
        """Populate the top 3-row summary grid with color coding."""
        self.grid_bobbin.clearContents()
        last3 = records[:3] if records else []
        for row_idx, rec in enumerate(last3):
            items = [rec.fiber_id, rec.fiber_length, rec.status, rec.reason, rec.remark]
            status = rec.status.upper() if rec.status else ""
            color = QColor("green") if "PASS" in status else (
                QColor("orange") if "REW" in status else (
                QColor("red") if "FAIL" in status else QColor("black")))
            for col_idx, val in enumerate(items):
                item = QTableWidgetItem(str(val) if val else "")
                item.setForeground(color)
                self.grid_bobbin.setItem(row_idx, col_idx, item)

    def _populate_table(self, widget: QTableWidget, rows: List[dict]) -> None:
        """Generic: fill a QTableWidget from a list of dicts."""
        if not rows:
            widget.setRowCount(0)
            widget.setColumnCount(0)
            return
        cols = list(rows[0].keys())
        widget.setColumnCount(len(cols))
        widget.setHorizontalHeaderLabels(cols)
        widget.setRowCount(len(rows))
        for r_idx, row in enumerate(rows):
            for c_idx, key in enumerate(cols):
                val = row.get(key)
                widget.setItem(r_idx, c_idx, QTableWidgetItem(str(val) if val is not None else ""))

    def _populate_fiber_records(self, records: List[FiberRecord]) -> None:
        """Populate grid_fiber_data from FiberRecord list."""
        if not records:
            return
        cols = [f for f in records[0].__dataclass_fields__.keys()]
        self.grid_fiber_data.setColumnCount(len(cols))
        self.grid_fiber_data.setHorizontalHeaderLabels(cols)
        self.grid_fiber_data.setRowCount(len(records))
        for r_idx, rec in enumerate(records):
            for c_idx, col in enumerate(cols):
                val = getattr(rec, col, "")
                self.grid_fiber_data.setItem(r_idx, c_idx, QTableWidgetItem(str(val) if val is not None else ""))

    def _set_controls_enabled(self, enabled: bool):
        self.txt_path.setEnabled(enabled)
        self.cmb_operator.setEnabled(enabled)
        self.cmb_otdr_no.setEnabled(enabled)
        self.dtp_from.setEnabled(enabled)
        self.dtp_to.setEnabled(enabled)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _on_browse(self):
        folder = QFileDialog.getExistingDirectory(self, "Select OTDR Folder")
        if folder:
            self.txt_path.setText(folder)

    def _on_start_timer(self):
        if not self.cmb_operator.currentText() or self.cmb_operator.currentText() == "-- Select Operator --":
            QMessageBox.warning(self, "Warning", "Please select an operator.")
            return
        self.enable_timer = True
        self.timer.start()
        self.btn_start.setEnabled(False)
        self.btn_end.setEnabled(True)
        self._set_controls_enabled(False)

    def _on_end_timer(self):
        self.enable_timer = False
        self.timer.stop()
        self.btn_start.setEnabled(True)
        self.btn_end.setEnabled(False)
        self._set_controls_enabled(True)

    def _on_timer_tick(self):
        self.timer.stop()
        self._load_rpt_files()
        if self.enable_timer:
            self.timer.start()

    def _load_rpt_files(self):
        folder = self.txt_path.text().strip()
        if not os.path.isdir(folder):
            return
        files = [
            os.path.join(folder, f) for f in os.listdir(folder)
            if f.lower().endswith(".rpt")
            and is_file_ready(os.path.join(folder, f))
            and not is_file_locked(os.path.join(folder, f))
            and contains_end_time(os.path.join(folder, f))
        ]
        if not files:
            return

        converted_dir = os.path.join(folder, "converted")
        os.makedirs(converted_dir, exist_ok=True)

        parsed_list = []
        spike_list = []
        otdr_no = self.cmb_otdr_no.currentText()
        operator = self.cmb_operator.currentText()

        for file_path in files:
            try:
                if self.chk_msgbox.isChecked():
                    QMessageBox.information(self, "File", file_path)
                recs, cuts_raw, spikes = parse_file(
                    file_path, self.master_thresholds, otdr_no=otdr_no
                )
                if recs:
                    parsed_list.extend(recs)
                if spikes:
                    spike_list.extend(spikes)

                # Move to converted
                dest = os.path.join(converted_dir, os.path.basename(file_path))
                if os.path.exists(dest):
                    os.remove(dest)
                os.rename(file_path, dest)
            except Exception as ex:
                QMessageBox.critical(self, "Parse Error",
                                     f"Error parsing {os.path.basename(file_path)}: {ex}")

        if not parsed_list:
            return

        # Analyze + Process
        records, cuts_analyzed = analyze(parsed_list, spike_list, self.master_thresholds)
        cut_results = process(records, cuts_analyzed, self.master_thresholds, otdr_no, operator)
        cut_results = sorted(cut_results, key=lambda x: x.sr_no, reverse=True)

        fiber_recs = to_fiber_record_list(cut_results)
        for fr in fiber_recs:
            self.fiber_records.append(fr)

        final_records = list(reversed(self.fiber_records))

        # Update DB if enabled
        if self.chk_store_db.isChecked():
            msg = insert_fiber_records(final_records, str(self.config_txt_path))
            if self.chk_msgbox.isChecked():
                QMessageBox.information(self, "DB", msg)
        # Update summary grid
        summary = [
            FiberRecordDataView(
                fiber_id=fr.fiber_id or "",
                fiber_length=str(fr.optical_length or 0),
                status=fr.status or "",
                reason=fr.reason or "",
                remark=fr.remarks or "",
            )
            for fr in final_records
        ]
        self._load_summary(summary)
        self._populate_fiber_records(final_records)

    def _on_generate_report(self):
        try:
            from_d = self.dtp_from.date().toPyDate()
            to_d = self.dtp_to.date().toPyDate()
            rows = get_fiber_records_by_date(from_d, to_d)
            self._populate_table(self.grid_fiber_data, rows)
        except Exception as ex:
            QMessageBox.critical(self, "Error", str(ex))

    def _on_operator_analysis(self):
        try:
            from_d = self.dtp_from.date().toPyDate()
            to_d = self.dtp_to.date().toPyDate()
            operator = self.cmb_operator.currentText()
            rows = get_fiber_records_by_date_operator(from_d, to_d, operator, self.chk_hourly.isChecked())
            self._populate_table(self.grid_fiber_data, rows)
        except Exception as ex:
            QMessageBox.critical(self, "Error", str(ex))

    def _on_export_excel(self):
        self._export_grid_to_excel(self.grid_fiber_data, "FiberReport")

    def _on_export_analysis(self):
        self._export_grid_to_excel(self.grid_fiber_data, "Fiber_Analysis_Export")

    def _export_grid_to_excel(self, grid: QTableWidget, prefix: str):
        try:
            from openpyxl import Workbook
        except ImportError:
            QMessageBox.critical(self, "Missing", "openpyxl not installed. Run: pip install openpyxl")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Excel File",
            f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
            "Excel Files (*.xlsx)",
        )
        if not file_path:
            return

        wb = Workbook()
        ws = wb.active
        ws.title = "Data"

        # Headers
        for col in range(grid.columnCount()):
            header = grid.horizontalHeaderItem(col)
            ws.cell(row=1, column=col + 1, value=header.text() if header else f"Col{col}")

        # Data
        for row in range(grid.rowCount()):
            for col in range(grid.columnCount()):
                item = grid.item(row, col)
                ws.cell(row=row + 2, column=col + 1, value=item.text() if item else "")

        wb.save(file_path)
        QMessageBox.information(self, "Exported", f"Saved to:\n{file_path}")
