# TL/22056 — Cost & Revenue Dashboard (Financial · SCM · Project Wise)

A full-stack replacement for the Excel-based Cost & Revenue Dashboard your FICO
consultant built for project TL/22056. Same underlying logic (SAP CO dump →
Revenue/Cost classification → SUMIFS-style aggregation), rebuilt as a
proper web app with login, role-based upload, and an AI chatbot over the data.

## What's included

- **Login** — 3 seeded users, role-based (see `server/src/store.js`)
  - `divyesh@fioet.com` — **Admin** (can upload raw data + Sign Off)
  - `lalit@fioet.com` — Viewer
  - `rajneesh@fioet.com` — Viewer
  - Default password for all three (POC only): `Fioet@123`
    (change in `server/src/store.js` before sharing this further)
- **Left menu**: Dashboard → 1. Financial (fully built) · 2. SCM (placeholder)
  · 3. Project Wise (placeholder)
- **Financial dashboard**: 3 filters (Fiscal Year / WBS Element / Object
  Type) exactly like the Excel dropdowns, KPI cards (Revenue, Cost, Net
  Profit, Margin %, in ₹ Cr), a monthly Revenue-vs-Cost trend, cost
  breakdowns by MIS Category / WBS Element / Cost Element / Fiscal Year /
  Object Type, and a searchable drill-down transaction table.
- **Admin-only**: drag-and-drop upload of the raw SAP dump (`.xlsx`), a
  "Sign Off" action that stamps who published the data and when — everyone
  else just logs in and sees it, no upload needed.
- **Data storage**: **in-memory on the server**, as you asked for a POC —
  it resets if the server restarts. Swapping in a real database later just
  means replacing `server/src/store.js`.
- **Claude chatbot**: a floating chat widget, bottom-right, wired to the
  real Anthropic API. It answers questions about *your currently loaded,
  currently filtered* data (e.g. "which WBS element cost the most in
  2023?", "what's driving the margin drop in FY24?").

## How the numbers are calculated (ported 1:1 from your Excel)

See `server/src/dataProcessor.js` — this is the important file if you ever
want to check or adjust the logic. Summary:

1. From the raw dump, only these columns are used: Document Number,
   Posting Date, Fiscal Year, Period, WBS Element, Object Type, Order,
   Cost Element, Cost Element Name, Material Description, **MIS Category**,
   User Name, and the amount column (`Val/COArea Crcy`, i.e. CO-area
   currency value — this is what your Excel's `Data!M` pulled from).
2. `Month` = posting date formatted `YYYY-MM`.
3. `Rev/Cost Flag` = **Revenue** if MIS Category = `P&L - Sale of services`,
   otherwise **Cost**. Rows with a blank/`#N/A` MIS Category are bucketed as
   **Uncategorized** (matches the "Uncategorized" row your consultant's
   `Calc` tab already had).
4. `Cost Amount` = amount, when flagged Cost, else 0.
   `Revenue Amount` = **−amount**, when flagged Revenue, else 0 (SAP CO
   posts revenue as a credit/negative value; this flips it positive —
   same as `Data!Q` in your file).
5. Everything downstream (KPIs, monthly trend, breakdowns) is just
   filtered sums of Cost Amount / Revenue Amount, grouped by whatever
   dimension — a direct equivalent of the `SUMIFS(...,Include,1)` pattern
   in your `Calc` tab, just computed in JS instead of Excel.
6. KPI cards divide by 1,00,00,000 (₹ Cr), same as your `/10000000` in
   `Dashboard!A9`.

## Running it locally

Requires Node.js 18+.

### 1. Backend

```bash
cd server
npm install
cp .env.example .env
# edit .env and put in your real Anthropic API key for the chatbot
npm run dev
```

Backend runs on `http://localhost:4000`.

### 2. Frontend

```bash
cd client
npm install
npm run dev
```

Frontend runs on `http://localhost:5173` (Vite will print the exact URL).
It proxies API calls to the backend automatically (see `vite.config.js`).

### 3. Use it

1. Open the frontend URL, log in as `divyesh@fioet.com` / `Fioet@123`.
2. Go to **Dashboard → Financial**, click **Upload Raw Data**, select your
   `22056_Dump.XLSX` (or any file with the same column headers).
3. Click **Sign Off** once you're happy with it.
4. Log out, log in as `lalit@fioet.com` or `rajneesh@fioet.com` (same
   password) — the dashboard is already there, no upload option shown.
5. Try the chat bubble bottom-right: "what's our current margin?", "which
   cost element is the biggest?", "compare FY2023 vs FY2024 revenue".

## Notes / next steps for a production version

- Passwords are stored as bcrypt hashes but seeded from a plaintext
  constant — fine for a POC among 3 known users, not for anything wider.
  Swap to a real user table + SSO before broader rollout.
- The whole dataset is held in a single in-memory JS array server-side.
  For a real deployment, move this to Postgres/SQL Server and turn the
  aggregation functions in `dataProcessor.js` into SQL, or a proper OLAP
  layer if the row count grows a lot past this project's ~16k rows.
- Uploads are capped at 25MB (see `server/src/routes/data.js`) — raise if
  needed.
- SCM and Project Wise menu items are wired up in the UI and routing but
  intentionally left as "coming soon" — same data-processing pattern can
  be extended to them once you share what those dumps/calcs look like.
