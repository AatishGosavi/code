// Ports the logic your FICO consultant built into the hidden `Data` and
// `Calc` tabs of TL22056_Cost_Revenue_Dashboard.xlsx into plain JS.
//
// Excel reference (for anyone auditing this later):
//   Data!N  =TEXT(PostingDate,"yyyy-mm")                        -> month
//   Data!O  =IF(MIS="P&L - Sale of services","Revenue","Cost")  -> flag
//   Data!P  =IF(O="Cost", Amount, 0)                            -> costAmount
//   Data!Q  =IF(O="Revenue", -Amount, 0)                        -> revenueAmount
//   Dashboard!A9 =SUMPRODUCT(Q,Include)/10000000  -> Total Revenue (Cr)
//   Dashboard!E9 =SUMPRODUCT(P,Include)/10000000  -> Total Cost (Cr)
//   Calc tab     =SUMIFS(P or Q, <dimension>, <value>, Include, 1)

const XLSX = require('xlsx');

const REVENUE_MIS = 'P&L - Sale of services';

// Header names we look for in the raw SAP dump, in priority order per field.
// This makes the parser tolerant of either the full 77-column raw dump or a
// pre-trimmed export, as long as the header text matches.
const FIELD_HEADER_CANDIDATES = {
  documentNumber: ['Document Number'],
  postingDate: ['Posting Date'],
  fiscalYear: ['Fiscal Year'],
  period: ['Period'],
  wbsElement: ['WBS element', 'WBS Element'],
  objectType: ['Object Type'],
  order: ['Order', 'Object'],
  costElement: ['Cost Element'],
  costElementName: ['Cost element name', 'Cost element descr.'],
  materialDescription: ['Material Description'],
  mis: ['MIS', 'MIS Category'],
  userName: ['User Name'],
  amount: ['Val/COArea Crcy', 'Amount (INR)', 'Val.in rep.cur.'],
};

function normalizeHeader(h) {
  return String(h || '').trim();
}

function buildHeaderIndex(headerRow) {
  const index = {};
  headerRow.forEach((raw, i) => {
    const h = normalizeHeader(raw);
    if (h && !(h in index)) index[h] = i;
  });
  return index;
}

function resolveColumn(headerIndex, candidates) {
  for (const name of candidates) {
    if (name in headerIndex) return headerIndex[name];
  }
  // Fallback: case-insensitive contains match
  const lowerEntries = Object.entries(headerIndex);
  for (const name of candidates) {
    const hit = lowerEntries.find(
      ([h]) => h.toLowerCase() === name.toLowerCase()
    );
    if (hit) return hit[1];
  }
  return -1;
}

function excelSerialToDate(value) {
  // XLSX with cellDates:true already gives JS Dates for real date cells.
  // This handles the rare case a date arrives as a raw serial number.
  if (value instanceof Date) return value;
  if (typeof value === 'number') {
    const utcDays = Math.floor(value - 25569);
    const utcMs = utcDays * 86400 * 1000;
    return new Date(utcMs);
  }
  if (typeof value === 'string' && value.trim()) {
    const d = new Date(value);
    if (!Number.isNaN(d.getTime())) return d;
  }
  return null;
}

function toMonthKey(date) {
  if (!date) return 'Unknown';
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

function toNumber(v) {
  if (v === null || v === undefined || v === '') return 0;
  const n = typeof v === 'number' ? v : parseFloat(String(v).replace(/,/g, ''));
  return Number.isFinite(n) ? n : 0;
}

function cleanText(v, fallback) {
  const s = v === null || v === undefined ? '' : String(v).trim();
  if (!s || s === '#N/A' || s.toLowerCase() === 'nan') return fallback;
  return s;
}

/**
 * Parses an uploaded workbook buffer into normalized rows + distinct filter
 * lists, exactly mirroring the Data-tab derived columns from the Excel file.
 */
function parseWorkbook(buffer, originalName) {
  const workbook = XLSX.read(buffer, { type: 'buffer', cellDates: true });

  // Prefer a sheet that looks like the raw dump or trimmed data export.
  const preferredNames = ['cost & revenue dump', 'data', 'dump'];
  let sheetName =
    workbook.SheetNames.find((n) =>
      preferredNames.some((p) => n.toLowerCase().includes(p))
    ) || workbook.SheetNames[0];

  const sheet = workbook.Sheets[sheetName];
  const grid = XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    raw: true,
    defval: null,
    blankrows: false,
  });

  if (!grid.length) {
    throw new Error(`Sheet "${sheetName}" is empty.`);
  }

  const headerRow = grid[0];
  const headerIndex = buildHeaderIndex(headerRow);

  const cols = {};
  for (const [field, candidates] of Object.entries(FIELD_HEADER_CANDIDATES)) {
    cols[field] = resolveColumn(headerIndex, candidates);
  }

  const missing = Object.entries(cols)
    .filter(([, idx]) => idx === -1)
    .map(([field]) => field);
  if (missing.length) {
    throw new Error(
      `Could not find required column(s) in sheet "${sheetName}": ${missing.join(
        ', '
      )}. Expected headers like: Document Number, Posting Date, Fiscal Year, ` +
        `Period, WBS element, Object Type, Cost Element, MIS, User Name, Val/COArea Crcy.`
    );
  }

  const rows = [];
  const fiscalYears = new Set();
  const wbsElements = new Set();
  const objectTypes = new Set();

  for (let r = 1; r < grid.length; r++) {
    const raw = grid[r];
    if (!raw || raw[cols.documentNumber] == null) continue;

    const postingDate = excelSerialToDate(raw[cols.postingDate]);
    const misRaw = cleanText(raw[cols.mis], null);
    const mis = misRaw || 'Uncategorized';
    const flag = mis === REVENUE_MIS ? 'Revenue' : 'Cost';
    const amount = toNumber(raw[cols.amount]);
    const costAmount = flag === 'Cost' ? amount : 0;
    const revenueAmount = flag === 'Revenue' ? -amount : 0;

    const fiscalYear = toNumber(raw[cols.fiscalYear]) || null;
    const wbsElement = cleanText(raw[cols.wbsElement], 'Unassigned');
    const objectType = cleanText(raw[cols.objectType], 'Unassigned');

    if (fiscalYear) fiscalYears.add(fiscalYear);
    wbsElements.add(wbsElement);
    objectTypes.add(objectType);

    rows.push({
      documentNumber: String(raw[cols.documentNumber]),
      postingDate: postingDate ? postingDate.toISOString() : null,
      month: toMonthKey(postingDate),
      fiscalYear,
      period: toNumber(raw[cols.period]) || null,
      wbsElement,
      objectType,
      order: cleanText(raw[cols.order], ''),
      costElement: cleanText(raw[cols.costElement], ''),
      costElementName: cleanText(raw[cols.costElementName], 'Unspecified'),
      materialDescription: cleanText(raw[cols.materialDescription], ''),
      mis,
      userName: cleanText(raw[cols.userName], ''),
      amount,
      flag,
      costAmount,
      revenueAmount,
    });
  }

  if (!rows.length) {
    throw new Error(
      `No usable data rows found in "${originalName}" (sheet "${sheetName}").`
    );
  }

  return {
    rows,
    sheetName,
    filters: {
      fiscalYears: [...fiscalYears].sort((a, b) => a - b),
      wbsElements: [...wbsElements].sort(),
      objectTypes: [...objectTypes].sort(),
    },
  };
}

function matchesFilters(row, filters) {
  const { fiscalYear, wbsElement, objectType } = filters || {};
  if (fiscalYear && fiscalYear !== 'All' && String(row.fiscalYear) !== String(fiscalYear))
    return false;
  if (wbsElement && wbsElement !== 'All' && row.wbsElement !== wbsElement)
    return false;
  if (objectType && objectType !== 'All' && row.objectType !== objectType)
    return false;
  return true;
}

function filterRows(rows, filters) {
  return rows.filter((r) => matchesFilters(r, filters));
}

function sumBy(rows, keyFn, valueFn) {
  const map = new Map();
  for (const r of rows) {
    const key = keyFn(r);
    map.set(key, (map.get(key) || 0) + valueFn(r));
  }
  return map;
}

const CR = 10000000; // ₹1,00,00,000 — matches Excel's /10000000

/**
 * Computes the full aggregation bundle a filtered dashboard view needs,
 * equivalent to Dashboard!A9:M10 plus every Calc-tab pivot.
 */
function computeSummary(allRows, filters) {
  const rows = filterRows(allRows, filters);

  const totalRevenue = rows.reduce((s, r) => s + r.revenueAmount, 0);
  const totalCost = rows.reduce((s, r) => s + r.costAmount, 0);
  const netProfit = totalRevenue - totalCost;
  const marginPct = totalRevenue ? netProfit / totalRevenue : 0;
  const transactions = rows.length;
  const avgCostPerTxn = transactions ? totalCost / transactions : 0;
  const years = rows.map((r) => r.fiscalYear).filter(Boolean);
  const minFY = years.length ? Math.min(...years) : null;
  const maxFY = years.length ? Math.max(...years) : null;

  const byMonthCost = sumBy(rows, (r) => r.month, (r) => r.costAmount);
  const byMonthRev = sumBy(rows, (r) => r.month, (r) => r.revenueAmount);
  const months = [...new Set([...byMonthCost.keys(), ...byMonthRev.keys()])]
    .filter((m) => m !== 'Unknown')
    .sort();
  const monthlyTrend = months.map((m) => ({
    month: m,
    revenue: byMonthRev.get(m) || 0,
    cost: byMonthCost.get(m) || 0,
  }));

  const byMis = sumBy(rows, (r) => r.mis, (r) => r.costAmount);
  const misBreakdown = [...byMis.entries()]
    .filter(([mis]) => mis !== REVENUE_MIS) // cost breakdown only, matches Calc tab
    .map(([mis, cost]) => ({ name: mis, cost }))
    .sort((a, b) => b.cost - a.cost);

  const byWbs = sumBy(rows, (r) => r.wbsElement, (r) => r.costAmount);
  const wbsBreakdown = [...byWbs.entries()]
    .map(([wbs, cost]) => ({ name: wbs, cost }))
    .sort((a, b) => b.cost - a.cost);

  const byCostElement = sumBy(
    rows,
    (r) => r.costElementName,
    (r) => r.costAmount
  );
  const costElementBreakdown = [...byCostElement.entries()]
    .map(([name, cost]) => ({ name, cost }))
    .sort((a, b) => b.cost - a.cost);

  const byFy = sumBy(rows, (r) => r.fiscalYear, (r) => r.costAmount);
  const byFyRev = sumBy(rows, (r) => r.fiscalYear, (r) => r.revenueAmount);
  const fiscalYearBreakdown = [...new Set([...byFy.keys(), ...byFyRev.keys()])]
    .filter(Boolean)
    .sort((a, b) => a - b)
    .map((fy) => ({
      fiscalYear: fy,
      revenue: byFyRev.get(fy) || 0,
      cost: byFy.get(fy) || 0,
    }));

  const byObjectType = sumBy(rows, (r) => r.objectType, (r) => r.costAmount);
  const objectTypeBreakdown = [...byObjectType.entries()]
    .map(([name, cost]) => ({ name, cost }))
    .sort((a, b) => b.cost - a.cost);

  return {
    kpis: {
      totalRevenueCr: totalRevenue / CR,
      totalCostCr: totalCost / CR,
      netProfitCr: netProfit / CR,
      marginPct,
      transactions,
      avgCostPerTxn,
      spanFrom: minFY,
      spanTo: maxFY,
    },
    monthlyTrend,
    misBreakdown,
    wbsBreakdown,
    costElementBreakdown,
    fiscalYearBreakdown,
    objectTypeBreakdown,
    rowCountAfterFilter: rows.length,
  };
}

module.exports = {
  parseWorkbook,
  computeSummary,
  filterRows,
  REVENUE_MIS,
  CR,
};
