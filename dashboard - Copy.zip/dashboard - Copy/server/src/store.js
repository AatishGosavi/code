// In-memory data store — intentional for this POC.
// Everything here lives only in server RAM and resets on restart.
// Swap this module out for a real DB later without touching route logic much.

const bcrypt = require('bcryptjs');

const DEFAULT_PASSWORD = 'Fioet@123';
const passwordHash = bcrypt.hashSync(DEFAULT_PASSWORD, 8);

// Seed users. Emails are normalized to lowercase for lookup.
const users = [
  {
    email: 'divyesh@fioet.com',
    name: 'Divyesh',
    role: 'admin',
    passwordHash,
  },
  {
    email: 'lalit@fioet.com',
    name: 'Lalit',
    role: 'viewer',
    passwordHash,
  },
  {
    email: 'rajneesh@fioet.com',
    name: 'Rajneesh',
    role: 'viewer',
    passwordHash,
  },
];

function findUserByEmail(email) {
  if (!email) return null;
  const norm = email.trim().toLowerCase();
  return users.find((u) => u.email.toLowerCase() === norm) || null;
}

// Dataset state — shared across all logged-in users.
// projects: { financial: { rows, meta, filters }, scm: null, projectWise: null }
const state = {
  financial: {
    rows: [],           // normalized rows, see dataProcessor.js
    filters: {          // distinct dropdown values
      fiscalYears: [],
      wbsElements: [],
      objectTypes: [],
    },
    meta: {
      fileName: null,
      uploadedBy: null,
      uploadedAt: null,
      rowCount: 0,
      signOff: null,     // { by, at, note }
    },
  },
};

module.exports = {
  DEFAULT_PASSWORD,
  users,
  findUserByEmail,
  state,
};
