const express = require('express');
const multer = require('multer');
const { requireAuth, requireAdmin } = require('../auth');
const { state } = require('../store');
const { parseWorkbook, computeSummary } = require('../dataProcessor');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB
});

// All routes below require login (viewers included) unless noted.
router.use(requireAuth);

// --- Upload raw data (admin only) ---
router.post('/financial/upload', requireAdmin, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });

  let parsed;
  try {
    parsed = parseWorkbook(req.file.buffer, req.file.originalname);
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }

  state.financial.rows = parsed.rows;
  state.financial.filters = parsed.filters;
  state.financial.meta = {
    fileName: req.file.originalname,
    uploadedBy: req.user.email,
    uploadedAt: new Date().toISOString(),
    rowCount: parsed.rows.length,
    signOff: null, // uploading new data clears any prior sign-off
  };

  res.json({ meta: state.financial.meta, filters: state.financial.filters });
});

// --- Sign off currently loaded data (admin only) ---
router.post('/financial/signoff', requireAdmin, (req, res) => {
  if (!state.financial.rows.length) {
    return res.status(400).json({ error: 'No data loaded yet — upload first.' });
  }
  state.financial.meta.signOff = {
    by: req.user.email,
    at: new Date().toISOString(),
    note: (req.body && req.body.note) || '',
  };
  res.json({ meta: state.financial.meta });
});

// --- Meta / status (everyone) ---
router.get('/financial/meta', (req, res) => {
  res.json({
    meta: state.financial.meta,
    filters: state.financial.filters,
    hasData: state.financial.rows.length > 0,
  });
});

// --- Summary (KPIs + breakdowns), filtered ---
router.get('/financial/summary', (req, res) => {
  if (!state.financial.rows.length) {
    return res.status(404).json({ error: 'No data loaded yet.' });
  }
  const { fiscalYear, wbsElement, objectType } = req.query;
  const summary = computeSummary(state.financial.rows, {
    fiscalYear,
    wbsElement,
    objectType,
  });
  res.json(summary);
});

// --- Paginated transaction table, filtered + searchable ---
router.get('/financial/rows', (req, res) => {
  if (!state.financial.rows.length) {
    return res.status(404).json({ error: 'No data loaded yet.' });
  }
  const { fiscalYear, wbsElement, objectType, search = '', page = '1', pageSize = '25' } =
    req.query;

  const { filterRows } = require('../dataProcessor');
  let rows = filterRows(state.financial.rows, { fiscalYear, wbsElement, objectType });

  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (r) =>
        r.documentNumber.toLowerCase().includes(q) ||
        r.costElementName.toLowerCase().includes(q) ||
        r.materialDescription.toLowerCase().includes(q) ||
        r.mis.toLowerCase().includes(q) ||
        r.wbsElement.toLowerCase().includes(q) ||
        r.userName.toLowerCase().includes(q)
    );
  }

  const p = Math.max(1, parseInt(page, 10) || 1);
  const ps = Math.min(200, Math.max(1, parseInt(pageSize, 10) || 25));
  const start = (p - 1) * ps;
  const pageRows = rows.slice(start, start + ps);

  res.json({
    total: rows.length,
    page: p,
    pageSize: ps,
    rows: pageRows,
  });
});

module.exports = router;
