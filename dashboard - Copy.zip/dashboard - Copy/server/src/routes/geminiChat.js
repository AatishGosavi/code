const express = require('express');
const { requireAuth } = require('../auth');
const { state } = require('../store');
const { computeSummary } = require('../dataProcessor');

const router = express.Router();
router.use(requireAuth);

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-1.5-pro';

function crFmt(n) {
  return `₹${(n || 0).toFixed(2)} Cr`;
}

function buildContext(filters) {
  const summary = computeSummary(state.financial.rows, filters);
  const { meta } = state.financial;

  const top = (arr, n = 8) =>
    arr.slice(0, n).map((x) => ({ ...x, costCr: (x.cost / 1e7).toFixed(3) }));

  return {
    project: 'TL/22056 — Transmission Line Project (Segment: PT-POWER, Currency: INR)',
    dataStatus: {
      fileName: meta.fileName,
      uploadedBy: meta.uploadedBy,
      uploadedAt: meta.uploadedAt,
      rowCount: meta.rowCount,
      signedOff: meta.signOff
        ? `Yes, by ${meta.signOff.by} at ${meta.signOff.at}`
        : 'Not yet signed off',
    },
    filtersApplied: filters,
    kpis: {
      totalRevenue: crFmt(summary.kpis.totalRevenueCr),
      totalCost: crFmt(summary.kpis.totalCostCr),
      netProfit: crFmt(summary.kpis.netProfitCr),
      marginPct: `${(summary.kpis.marginPct * 100).toFixed(2)}%`,
      transactions: summary.kpis.transactions,
      avgCostPerTxnINR: Math.round(summary.kpis.avgCostPerTxn),
      fiscalYearSpan: `${summary.kpis.spanFrom || '-'} to ${summary.kpis.spanTo || '-'}`,
    },
    monthlyTrend: summary.monthlyTrend,
    topCostByMisCategory: top(summary.misBreakdown),
    topCostByWbsElement: top(summary.wbsBreakdown),
    topCostByCostElement: top(summary.costElementBreakdown),
    costAndRevenueByFiscalYear: summary.fiscalYearBreakdown.map((f) => ({
      fiscalYear: f.fiscalYear,
      revenueCr: (f.revenue / 1e7).toFixed(3),
      costCr: (f.cost / 1e7).toFixed(3),
    })),
    costByObjectType: top(summary.objectTypeBreakdown),
  };
}

router.post('/', async (req, res) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({
      error:
        'GEMINI_API_KEY is not set on the server. Add it to server/.env to enable the Gemini chatbot.',
    });
  }
  if (!state.financial.rows.length) {
    return res.status(400).json({ error: 'No data loaded yet — ask an admin to upload it first.' });
  }

  const { message, filters = {}, history = [] } = req.body || {};
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'message is required.' });
  }

  const context = buildContext(filters);

  const systemInstruction = `You are a financial analyst assistant embedded inside the TL/22056 Cost & Revenue Dashboard used by an EPC/transmission-line project team. Answer the user's question using ONLY the JSON data provided below, which reflects the currently loaded and currently filtered dashboard data. Be concise, use ₹ Cr for large figures, and call out specific numbers rather than vague statements. If the data provided doesn't answer the question, say so plainly rather than guessing. Do not invent figures.

CURRENT DASHBOARD DATA (JSON):
${JSON.stringify(context)}`;

  const contents = [
    ...history
      .filter((h) => h && h.role && h.content)
      .slice(-10)
      .map((h) => ({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: h.content }],
      })),
    { role: 'user', parts: [{ text: message }] },
  ];

  try {
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${process.env.GEMINI_API_KEY}`;

    const response = await fetch(geminiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        system_instruction: {
          parts: [{ text: systemInstruction }],
        },
        contents,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(502).json({
        error: data?.error?.message || 'Gemini API request failed.',
      });
    }

    const text =
      data?.candidates?.[0]?.content?.parts?.[0]?.text || '(no response)';

    res.json({ reply: text });
  } catch (e) {
    res.status(502).json({ error: `Could not reach Gemini API: ${e.message}` });
  }
});

module.exports = router;