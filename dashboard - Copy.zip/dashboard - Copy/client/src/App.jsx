import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Login from './pages/Login.jsx';
import DashboardLayout from './pages/DashboardLayout.jsx';
import FinancialDashboard from './pages/FinancialDashboard.jsx';
import ComingSoon from './pages/ComingSoon.jsx';

function Protected({ children }) {
  const { user, ready } = useAuth();
  if (!ready) return <FullScreenLoader />;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function FullScreenLoader() {
  return (
    <div className="h-screen w-screen flex items-center justify-center bg-navy-950 text-slate-300">
      Loading…
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <Protected>
            <DashboardLayout />
          </Protected>
        }
      >
        <Route index element={<Navigate to="financial" replace />} />
        <Route path="financial" element={<FinancialDashboard />} />
        <Route
          path="scm"
          element={<ComingSoon title="SCM Dashboard" module="SCM" />}
        />
        <Route
          path="project-wise"
          element={<ComingSoon title="Project Wise Dashboard" module="Project Wise" />}
        />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
