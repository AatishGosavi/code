import React from 'react';

function Select({ label, value, options, onChange }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[11px] font-medium text-slate-500">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-lg border border-slate-300 bg-white text-sm px-3 py-2 min-w-[180px] focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500"
      >
        <option value="All">All</option>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  );
}

export default function FilterBar({ filters, value, onChange }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-wrap items-end gap-4">
      <div className="text-xs font-semibold text-slate-400 uppercase tracking-wide pb-2 pr-2 border-r border-slate-200">
        Filters
      </div>
      <Select
        label="Fiscal Year"
        value={value.fiscalYear}
        options={filters.fiscalYears.map(String)}
        onChange={(v) => onChange({ ...value, fiscalYear: v })}
      />
      <Select
        label="WBS Element"
        value={value.wbsElement}
        options={filters.wbsElements}
        onChange={(v) => onChange({ ...value, wbsElement: v })}
      />
      <Select
        label="Object Type"
        value={value.objectType}
        options={filters.objectTypes}
        onChange={(v) => onChange({ ...value, objectType: v })}
      />
      {(value.fiscalYear !== 'All' ||
        value.wbsElement !== 'All' ||
        value.objectType !== 'All') && (
        <button
          onClick={() =>
            onChange({ fiscalYear: 'All', wbsElement: 'All', objectType: 'All' })
          }
          className="text-xs font-medium text-slate-500 hover:text-red-500 underline underline-offset-2 pb-2"
        >
          Reset filters
        </button>
      )}
    </div>
  );
}
