import React, { useRef, useState } from 'react';
import api from '../api.js';

export default function UploadPanel({ meta, onChanged }) {
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [signingOff, setSigningOff] = useState(false);

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    setUploading(true);
    const form = new FormData();
    form.append('file', file);
    try {
      await api.post('/data/financial/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      await onChanged();
    } catch (err) {
      setError(err?.response?.data?.error || 'Upload failed.');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  async function handleSignOff() {
    setSigningOff(true);
    setError('');
    try {
      await api.post('/data/financial/signoff', { note });
      setNote('');
      await onChanged();
    } catch (err) {
      setError(err?.response?.data?.error || 'Sign off failed.');
    } finally {
      setSigningOff(false);
    }
  }

  const isSignedOff = !!meta?.signOff;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="text-sm font-semibold text-slate-700">
          Admin — Data Management
        </div>
        {meta?.hasData ? (
          <span
            className={`text-[11px] font-medium px-2 py-0.5 rounded-full border ${
              isSignedOff
                ? 'text-emerald-600 bg-emerald-50 border-emerald-100'
                : 'text-amber-600 bg-amber-50 border-amber-100'
            }`}
          >
            {isSignedOff ? 'Signed off' : 'Loaded, not signed off'}
          </span>
        ) : (
          <span className="text-[11px] font-medium px-2 py-0.5 rounded-full border text-slate-500 bg-slate-50 border-slate-200">
            No data loaded
          </span>
        )}
      </div>

      {meta?.fileName && (
        <div className="text-xs text-slate-500 mb-3 space-y-0.5">
          <div>
            <span className="text-slate-400">File:</span> {meta.fileName} ·{' '}
            {meta.rowCount?.toLocaleString()} rows
          </div>
          <div>
            <span className="text-slate-400">Uploaded by:</span>{' '}
            {meta.uploadedBy} on {new Date(meta.uploadedAt).toLocaleString()}
          </div>
          {isSignedOff && (
            <div>
              <span className="text-slate-400">Signed off by:</span>{' '}
              {meta.signOff.by} on {new Date(meta.signOff.at).toLocaleString()}
              {meta.signOff.note ? ` — "${meta.signOff.note}"` : ''}
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <label className="inline-flex items-center gap-2 text-sm font-medium bg-navy-900 text-white px-3.5 py-2 rounded-lg cursor-pointer hover:bg-navy-800 transition">
          {uploading ? 'Uploading…' : 'Upload Raw Data (.xlsx)'}
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            disabled={uploading}
            onChange={handleFile}
          />
        </label>

        {meta?.hasData && (
          <>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Sign-off note (optional)"
              className="text-sm rounded-lg border border-slate-300 px-3 py-2 flex-1 min-w-[180px]"
            />
            <button
              onClick={handleSignOff}
              disabled={signingOff}
              className="text-sm font-medium bg-teal-500 hover:bg-teal-400 disabled:opacity-60 text-navy-950 px-3.5 py-2 rounded-lg transition"
            >
              {signingOff ? 'Signing off…' : 'Sign Off'}
            </button>
          </>
        )}
      </div>

      {error && (
        <div className="mt-3 text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
          {error}
        </div>
      )}
    </div>
  );
}
