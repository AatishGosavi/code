import React from 'react';

export default function KpiCard({ label, value, sublabel, accent = 'teal' }) {
  const accents = {
    teal: 'text-teal-600 bg-teal-50 border-teal-100',
    blue: 'text-blue-600 bg-blue-50 border-blue-100',
    rose: 'text-rose-600 bg-rose-50 border-rose-100',
    amber: 'text-amber-600 bg-amber-50 border-amber-100',
  };
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div className="text-xs font-medium text-slate-500 mb-2">{label}</div>
      <div className={`text-2xl font-bold tracking-tight text-slate-800`}>
        {value}
      </div>
      {sublabel && (
        <div
          className={`inline-block mt-2 text-[11px] font-medium border rounded-full px-2 py-0.5 ${accents[accent]}`}
        >
          {sublabel}
        </div>
      )}
    </div>
  );
}
