import React, { useEffect, useRef, useState } from 'react';
import api from '../api.js';

export default function ChatWidget() {
  const [activeProvider, setActiveProvider] = useState(null); // 'claude' | 'gemini' | null
  
  const [claudeMessages, setClaudeMessages] = useState([
    {
      role: 'assistant',
      content: "Hi! I can answer questions about the currently loaded TL/22056 dashboard data — try asking things like \"what's our current margin?\" or \"which WBS element cost the most?\"",
    },
  ]);
  const [geminiMessages, setGeminiMessages] = useState([
    {
      role: 'assistant',
      content: "Hi! I'm Gemini. I can answer questions about the currently loaded TL/22056 dashboard data — ask away!",
    },
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  const messages = activeProvider === 'gemini' ? geminiMessages : claudeMessages;
  const setMessages = activeProvider === 'gemini' ? setGeminiMessages : setClaudeMessages;

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, activeProvider]);

  async function send() {
    const text = input.trim();
    if (!text || loading || !activeProvider) return;
    setInput('');
    const next = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setLoading(true);

    const endpoint = activeProvider === 'gemini' ? '/gemini-chat' : '/chat';

    try {
      const res = await api.post(endpoint, {
        message: text,
        history: next.slice(-10),
        filters: { fiscalYear: 'All', wbsElement: 'All', objectType: 'All' },
      });
      setMessages((m) => [...m, { role: 'assistant', content: res.data.reply }]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        {
          role: 'assistant',
          content:
            err?.response?.data?.error ||
            `Something went wrong reaching the ${activeProvider} assistant. Please try again.`,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <>
      {activeProvider && (
        <div className="fixed bottom-24 right-6 w-96 max-w-[92vw] h-[520px] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col z-50 overflow-hidden">
          <div className="bg-navy-950 text-white px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${
                activeProvider === 'gemini' ? 'bg-blue-500/20 text-blue-400' : 'bg-teal-500/20 text-teal-400'
              }`}>
                {activeProvider === 'gemini' ? 'G' : 'C'}
              </div>
              <div>
                <div className="text-sm font-semibold leading-none">
                  {activeProvider === 'gemini' ? 'Ask Gemini' : 'Ask Claude'}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  About this dashboard's data
                </div>
              </div>
            </div>
            <button
              onClick={() => setActiveProvider(null)}
              className="text-slate-400 hover:text-white text-lg leading-none"
            >
              ×
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm whitespace-pre-wrap ${
                    m.role === 'user'
                      ? activeProvider === 'gemini'
                        ? 'bg-blue-600 text-white font-medium'
                        : 'bg-teal-500 text-navy-950 font-medium'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-100 text-slate-400 rounded-2xl px-3.5 py-2 text-sm">
                  Thinking…
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t border-slate-100 flex gap-2">
            <textarea
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question about the data…"
              className={`flex-1 resize-none text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 ${
                activeProvider === 'gemini' ? 'focus:ring-blue-500/50 focus:border-blue-500' : 'focus:ring-teal-500/50 focus:border-teal-500'
              }`}
            />
            <button
              onClick={send}
              disabled={loading}
              className={`disabled:opacity-50 text-white text-sm font-medium px-3.5 rounded-lg ${
                activeProvider === 'gemini' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-navy-900 hover:bg-navy-800'
              }`}
            >
              Send
            </button>
          </div>
        </div>
      )}

      {/* Floating Action Buttons Layout: Gemini Icon next to Claude Icon */}
      <div className="fixed bottom-6 right-6 flex items-center gap-3 z-50">
        {/* Gemini Trigger Button */}
        <button
          onClick={() => setActiveProvider(activeProvider === 'gemini' ? null : 'gemini')}
          className={`h-14 w-14 rounded-full shadow-xl flex items-center justify-center text-xl transition transform hover:scale-105 ${
            activeProvider === 'gemini'
              ? 'bg-slate-900 text-blue-400 border-2 border-blue-500'
              : 'bg-blue-600 hover:bg-blue-500 text-white'
          }`}
          aria-label="Open Gemini chat"
          title="Chat with Gemini"
        >
          {activeProvider === 'gemini' ? '×' : '✨'}
        </button>

        {/* Claude Trigger Button */}
        <button
          onClick={() => setActiveProvider(activeProvider === 'claude' ? null : 'claude')}
          className={`h-14 w-14 rounded-full shadow-xl flex items-center justify-center text-2xl transition transform hover:scale-105 ${
            activeProvider === 'claude'
              ? 'bg-slate-900 text-teal-400 border-2 border-teal-500'
              : 'bg-teal-500 hover:bg-teal-400 text-navy-950'
          }`}
          aria-label="Open Claude chat"
          title="Chat with Claude"
        >
          {activeProvider === 'claude' ? '×' : '💬'}
        </button>
      </div>
    </>
  );
}