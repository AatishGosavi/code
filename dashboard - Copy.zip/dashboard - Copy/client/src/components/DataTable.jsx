import React, { useEffect, useState } from 'react';
import api from '../api.js';

const inr = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });

export default function DataTable({ filters }) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ rows: [], total: 0, pageSize: 25 });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setPage(1);
  }, [filters, search]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .get('/data/financial/rows', {
        params: { ...filters, search, page, pageSize: 25 },
      })
      .then((res) => {
        if (!cancelled) setData(res.data);
      })
      .catch(() => {
        if (!cancelled) setData({ rows: [], total: 0, pageSize: 25 });
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [filters, search, page]);

  const totalPages = Math.max(1, Math.ceil(data.total / data.pageSize));

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm">
      <div className="p-5 pb-3 flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="text-sm font-semibold text-slate-700">
            Transaction Drill-down
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {data.total.toLocaleString()} matching transactions
          </div>
        </div>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search doc #, cost element, material, MIS category…"
          className="text-sm rounded-lg border border-slate-300 px-3 py-2 w-72 focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wide text-slate-400 border-y border-slate-100">
              <th className="px-5 py-2 font-medium">Doc #</th>
              <th className="px-3 py-2 font-medium">Date</th>
              <th className="px-3 py-2 font-medium">FY</th>
              <th className="px-3 py-2 font-medium">WBS Element</th>
              <th className="px-3 py-2 font-medium">Object Type</th>
              <th className="px-3 py-2 font-medium">Cost Element</th>
              <th className="px-3 py-2 font-medium">MIS Category</th>
              <th className="px-3 py-2 font-medium">Flag</th>
              <th className="px-5 py-2 font-medium text-right">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={9} className="text-center py-8 text-slate-400 text-sm">
                  Loading…
                </td>
              </tr>
            ) : data.rows.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center py-8 text-slate-400 text-sm">
                  No transactions match the current filters.
                </td>
              </tr>
            ) : (
              data.rows.map((r) => (
                <tr
                  key={r.documentNumber + r.postingDate}
                  className="border-b border-slate-50 hover:bg-slate-50"
                >
                  <td className="px-5 py-2 font-mono text-xs text-slate-600">
                    {r.documentNumber}
                  </td>
                  <td className="px-3 py-2 text-slate-500 whitespace-nowrap">
                    {r.postingDate ? new Date(r.postingDate).toLocaleDateString('en-IN') : '-'}
                  </td>
                  <td className="px-3 py-2 text-slate-500">{r.fiscalYear || '-'}</td>
                  <td className="px-3 py-2 text-slate-600">{r.wbsElement}</td>
                  <td className="px-3 py-2 text-slate-500">{r.objectType}</td>
                  <td className="px-3 py-2 text-slate-600">{r.costElementName}</td>
                  <td className="px-3 py-2 text-slate-500">{r.mis}</td>
                  <td className="px-3 py-2">
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        r.flag === 'Revenue'
                          ? 'bg-emerald-50 text-emerald-600'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {r.flag}
                    </span>
                  </td>
                  <td className="px-5 py-2 text-right font-medium text-slate-700">
                    {inr.format(r.amount)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100 text-xs text-slate-500">
        <span>
          Page {page} of {totalPages}
        </span>
        <div className="flex gap-2">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="px-2.5 py-1 rounded border border-slate-200 disabled:opacity-40 hover:bg-slate-50"
          >
            Prev
          </button>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="px-2.5 py-1 rounded border border-slate-200 disabled:opacity-40 hover:bg-slate-50"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
