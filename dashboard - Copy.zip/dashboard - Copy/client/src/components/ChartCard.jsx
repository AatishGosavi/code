import React from 'react';

export default function ChartCard({ title, subtitle, children, className = '' }) {
  return (
    <div
      className={`bg-white rounded-2xl border border-slate-200 p-5 shadow-sm ${className}`}
    >
      <div className="mb-4">
        <div className="text-sm font-semibold text-slate-700">{title}</div>
        {subtitle && (
          <div className="text-[11px] text-slate-400 mt-0.5">{subtitle}</div>
        )}
      </div>
      {children}
    </div>
  );
}
