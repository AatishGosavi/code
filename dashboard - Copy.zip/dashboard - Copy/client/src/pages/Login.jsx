import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Login() {
  const { user, ready, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (ready && user) return <Navigate to="/" replace />;

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setError(err?.response?.data?.error || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen w-full bg-navy-950 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-xl bg-teal-500/10 border border-teal-500/30 mb-4">
            <span className="text-teal-400 font-bold text-lg">TL</span>
          </div>
          <h1 className="text-slate-100 text-xl font-semibold tracking-tight">
            TL/22056 — Transmission Line Project
          </h1>
          <p className="text-slate-400 text-sm mt-1">Cost &amp; Revenue Dashboard</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-navy-900 border border-navy-700 rounded-2xl shadow-2xl p-8"
        >
          <div className="mb-4">
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Email
            </label>
            <input
              type="email"
              required
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@fioet.com"
              className="w-full rounded-lg bg-navy-800 border border-navy-600 text-slate-100 px-3.5 py-2.5 text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/60 focus:border-teal-500"
            />
          </div>
          <div className="mb-5">
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-lg bg-navy-800 border border-navy-600 text-slate-100 px-3.5 py-2.5 text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/60 focus:border-teal-500"
            />
          </div>

          {error && (
            <div className="mb-4 text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-teal-500 hover:bg-teal-400 disabled:opacity-60 text-navy-950 font-semibold text-sm py-2.5 transition"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>

          <p className="mt-5 text-[11px] text-slate-500 leading-relaxed">
            Admin: divyesh@fioet.com &middot; Viewers: lalit@fioet.com,
            rajneesh@fioet.com. Contact your administrator for the password.
          </p>
        </form>
      </div>
    </div>
  );
}
