import React, { useCallback, useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import api from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import KpiCard from '../components/KpiCard.jsx';
import FilterBar from '../components/FilterBar.jsx';
import ChartCard from '../components/ChartCard.jsx';
import UploadPanel from '../components/UploadPanel.jsx';
import DataTable from '../components/DataTable.jsx';

const COLORS = [
  '#0d9488', '#2563eb', '#f59e0b', '#e11d48', '#7c3aed',
  '#0891b2', '#65a30d', '#db2777', '#ea580c', '#4f46e5',
];

const crFmt = (n) => `₹${(n || 0).toFixed(2)} Cr`;
const pctFmt = (n) => `${((n || 0) * 100).toFixed(2)}%`;
const inrShort = (n) => {
  const cr = n / 1e7;
  return `₹${cr.toFixed(2)}Cr`;
};

export default function FinancialDashboard() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [meta, setMeta] = useState({ hasData: false });
  const [filterOptions, setFilterOptions] = useState({
    fiscalYears: [],
    wbsElements: [],
    objectTypes: [],
  });
  const [filters, setFilters] = useState({
    fiscalYear: 'All',
    wbsElement: 'All',
    objectType: 'All',
  });
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const loadMeta = useCallback(async () => {
    try {
      const res = await api.get('/data/financial/meta');
      setMeta(res.data);
      setFilterOptions(res.data.filters || { fiscalYears: [], wbsElements: [], objectTypes: [] });
    } catch (e) {
      setMeta({ hasData: false });
    }
  }, []);

  const loadSummary = useCallback(async (f) => {
    setError('');
    try {
      const res = await api.get('/data/financial/summary', { params: f });
      setSummary(res.data);
    } catch (e) {
      if (e?.response?.status === 404) {
        setSummary(null);
      } else {
        setError(e?.response?.data?.error || 'Failed to load dashboard data.');
      }
    }
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await loadMeta();
      setLoading(false);
    })();
  }, [loadMeta]);

  useEffect(() => {
    if (meta.hasData) loadSummary(filters);
  }, [filters, meta.hasData, loadSummary]);

  async function handleDataChanged() {
    await loadMeta();
  }

  if (loading) {
    return <div className="text-slate-400 text-sm">Loading dashboard…</div>;
  }

  return (
    <div className="space-y-6 pb-16">
      {isAdmin && <UploadPanel meta={meta} onChanged={handleDataChanged} />}

      {!meta.hasData ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center">
          <div className="text-slate-400 text-sm">
            {isAdmin
              ? 'No data loaded yet — upload the raw SAP dump above to get started.'
              : 'No data has been loaded by the admin yet. Please check back once Divyesh uploads and signs off the data.'}
          </div>
        </div>
      ) : (
        <>
          {!isAdmin && meta.meta?.signOff && (
            <div className="text-xs text-slate-500 bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-2.5 inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Data signed off by {meta.meta.signOff.by} on{' '}
              {new Date(meta.meta.signOff.at).toLocaleString()}
            </div>
          )}

          <FilterBar filters={filterOptions} value={filters} onChange={setFilters} />

          {error && (
            <div className="text-sm text-red-500 bg-red-50 border border-red-100 rounded-lg px-4 py-2.5">
              {error}
            </div>
          )}

          {summary && (
            <>
              {/* KPI row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <KpiCard
                  label="Total Revenue (₹ Cr)"
                  value={crFmt(summary.kpis.totalRevenueCr)}
                  sublabel={`${summary.kpis.transactions.toLocaleString()} transactions`}
                  accent="teal"
                />
                <KpiCard
                  label="Total Cost (₹ Cr)"
                  value={crFmt(summary.kpis.totalCostCr)}
                  sublabel={`Avg ₹${Math.round(
                    summary.kpis.avgCostPerTxn
                  ).toLocaleString('en-IN')} / txn`}
                  accent="blue"
                />
                <KpiCard
                  label="Net Profit (₹ Cr)"
                  value={crFmt(summary.kpis.netProfitCr)}
                  sublabel={
                    summary.kpis.netProfitCr >= 0 ? 'Profit' : 'Loss'
                  }
                  accent={summary.kpis.netProfitCr >= 0 ? 'teal' : 'rose'}
                />
                <KpiCard
                  label="Margin %"
                  value={pctFmt(summary.kpis.marginPct)}
                  sublabel={`FY${summary.kpis.spanFrom || '-'} to FY${
                    summary.kpis.spanTo || '-'
                  }`}
                  accent="amber"
                />
              </div>

              {/* Monthly trend */}
              <ChartCard
                title="Monthly Revenue vs Cost Trend"
                subtitle="Sum of Revenue Amount / Cost Amount by posting month, for the current filter selection"
              >
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={summary.monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eef2f7" />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                    <YAxis
                      tickFormatter={inrShort}
                      tick={{ fontSize: 11 }}
                      width={70}
                    />
                    <Tooltip
                      formatter={(v) => inrShort(v)}
                      labelStyle={{ fontSize: 12 }}
                      contentStyle={{ fontSize: 12, borderRadius: 8 }}
                    />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Line
                      type="monotone"
                      dataKey="revenue"
                      name="Revenue"
                      stroke="#0d9488"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="cost"
                      name="Cost"
                      stroke="#e11d48"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartCard>

              {/* Two-column charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ChartCard
                  title="Cost by MIS Category"
                  subtitle="Where the cost is landing, by P&L classification"
                >
                  <ResponsiveContainer width="100%" height={320}>
                    <BarChart
                      layout="vertical"
                      data={summary.misBreakdown.slice(0, 10)}
                      margin={{ left: 24 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#eef2f7" />
                      <XAxis type="number" tickFormatter={inrShort} tick={{ fontSize: 11 }} />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={170}
                        tick={{ fontSize: 10 }}
                      />
                      <Tooltip formatter={(v) => inrShort(v)} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                      <Bar dataKey="cost" fill="#0d9488" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>

                <ChartCard
                  title="Cost by WBS Element"
                  subtitle="Top 10 WBS elements by cost incurred"
                >
                  <ResponsiveContainer width="100%" height={320}>
                    <BarChart
                      layout="vertical"
                      data={summary.wbsBreakdown.slice(0, 10)}
                      margin={{ left: 24 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#eef2f7" />
                      <XAxis type="number" tickFormatter={inrShort} tick={{ fontSize: 11 }} />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={150}
                        tick={{ fontSize: 10 }}
                      />
                      <Tooltip formatter={(v) => inrShort(v)} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                      <Bar dataKey="cost" fill="#2563eb" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>

                <ChartCard
                  title="Cost by Cost Element"
                  subtitle="Top 10 cost elements (e.g. Steel, Sub-Contractor, Cement)"
                >
                  <ResponsiveContainer width="100%" height={320}>
                    <BarChart data={summary.costElementBreakdown.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#eef2f7" />
                      <XAxis
                        dataKey="name"
                        tick={{ fontSize: 9 }}
                        angle={-30}
                        textAnchor="end"
                        interval={0}
                        height={70}
                      />
                      <YAxis tickFormatter={inrShort} tick={{ fontSize: 11 }} width={70} />
                      <Tooltip formatter={(v) => inrShort(v)} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                      <Bar dataKey="cost" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>

                <ChartCard
                  title="Cost by Object Type"
                  subtitle="Order (ORD) vs WBS-direct postings"
                >
                  <ResponsiveContainer width="100%" height={320}>
                    <PieChart>
                      <Pie
                        data={summary.objectTypeBreakdown}
                        dataKey="cost"
                        nameKey="name"
                        outerRadius={110}
                        label={(d) => `${d.name}: ${inrShort(d.cost)}`}
                        labelLine={false}
                      >
                        {summary.objectTypeBreakdown.map((_, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v) => inrShort(v)} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartCard>
              </div>

              {/* Fiscal year comparison */}
              <ChartCard
                title="Revenue vs Cost by Fiscal Year"
                subtitle="Year-over-year comparison for the current filter selection"
              >
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={summary.fiscalYearBreakdown}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eef2f7" />
                    <XAxis dataKey="fiscalYear" tick={{ fontSize: 11 }} />
                    <YAxis tickFormatter={inrShort} tick={{ fontSize: 11 }} width={70} />
                    <Tooltip formatter={(v) => inrShort(v)} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="revenue" name="Revenue" fill="#0d9488" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="cost" name="Cost" fill="#e11d48" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartCard>

              <DataTable filters={filters} />
            </>
          )}
        </>
      )}
    </div>
  );
}
