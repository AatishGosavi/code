import React from 'react';

export default function ComingSoon({ title, module }) {
  return (
    <div className="h-full flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="mx-auto h-14 w-14 rounded-2xl bg-navy-900/5 border border-slate-200 flex items-center justify-center mb-4">
          <span className="text-slate-400 text-xl">⏳</span>
        </div>
        <h2 className="text-lg font-semibold text-slate-700">{title}</h2>
        <p className="text-sm text-slate-500 mt-2">
          The {module} dashboard will use the same upload → sign-off →
          view pipeline as Financial, once the {module} data structure is
          shared. It's already wired into the menu and routing, ready to
          plug in.
        </p>
      </div>
    </div>
  );
}
