import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import ChatWidget from '../components/ChatWidget.jsx';

const MENU = [
  {
    label: 'Dashboard',
    items: [
      { to: '/financial', label: '1. Financial', enabled: true },
      { to: '/scm', label: '2. SCM', enabled: false },
      { to: '/project-wise', label: '3. Project Wise', enabled: false },
    ],
  },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="h-screen w-screen flex bg-slate-100 overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`${
          collapsed ? 'w-[68px]' : 'w-64'
        } shrink-0 bg-navy-950 text-slate-300 flex flex-col transition-all duration-200`}
      >
        <div className="h-16 flex items-center px-4 border-b border-navy-800">
          <div className="h-9 w-9 rounded-lg bg-teal-500/10 border border-teal-500/30 flex items-center justify-center shrink-0">
            <span className="text-teal-400 font-bold text-sm">TL</span>
          </div>
          {!collapsed && (
            <div className="ml-3 leading-tight">
              <div className="text-slate-100 text-sm font-semibold">TL/22056</div>
              <div className="text-[11px] text-slate-500">Transmission Line</div>
            </div>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3">
          {MENU.map((section) => (
            <div key={section.label} className="mb-2">
              {!collapsed && (
                <div className="px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  {section.label}
                </div>
              )}
              <div className="space-y-1">
                {section.items.map((item) =>
                  item.enabled ? (
                    <NavLink
                      key={item.to}
                      to={item.to}
                      className={({ isActive }) =>
                        `flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${
                          isActive
                            ? 'bg-teal-500/15 text-teal-300'
                            : 'text-slate-400 hover:bg-navy-800 hover:text-slate-200'
                        }`
                      }
                    >
                      <span className="truncate">{collapsed ? item.label.split('.')[0] : item.label}</span>
                    </NavLink>
                  ) : (
                    <div
                      key={item.to}
                      title="Coming soon"
                      className="flex items-center justify-between gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 cursor-not-allowed"
                    >
                      <span className="truncate">{collapsed ? item.label.split('.')[0] : item.label}</span>
                      {!collapsed && (
                        <span className="text-[9px] uppercase tracking-wide bg-navy-800 text-slate-500 px-1.5 py-0.5 rounded">
                          Soon
                        </span>
                      )}
                    </div>
                  )
                )}
              </div>
            </div>
          ))}
        </nav>

        <button
          onClick={() => setCollapsed((c) => !c)}
          className="h-11 border-t border-navy-800 text-slate-500 hover:text-slate-300 text-xs"
        >
          {collapsed ? '»' : '« Collapse'}
        </button>
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 shrink-0 bg-white border-b border-slate-200 flex items-center justify-between px-6">
          <div>
            <div className="text-sm font-semibold text-slate-800">
              Cost &amp; Revenue Dashboard
            </div>
            <div className="text-[11px] text-slate-400">
              Segment: PT-POWER &middot; Currency: INR
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm font-medium text-slate-700">{user?.name}</div>
              <div className="text-[11px] text-slate-400 capitalize">{user?.role}</div>
            </div>
            <div className="h-9 w-9 rounded-full bg-navy-900 text-teal-400 flex items-center justify-center text-sm font-semibold">
              {user?.name?.[0] || '?'}
            </div>
            <button
              onClick={logout}
              className="text-xs font-medium text-slate-500 hover:text-red-500 border border-slate-200 hover:border-red-300 rounded-lg px-3 py-1.5 transition"
            >
              Log out
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>

      <ChatWidget />
    </div>
  );
}
