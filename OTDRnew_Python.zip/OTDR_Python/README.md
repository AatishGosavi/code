# OTDR Automation — Python Edition

Complete conversion of the C# .NET 8 WinForms OTDR application to Python with PyQt6 UI and PostgreSQL.

---

## Project Structure

```
OTDR_Python/
├── main.py                          ← Entry point
├── requirements.txt                 ← Python dependencies
├── config/
│   ├── appsettings.json             ← DB connection string
│   └── config.txt                   ← Thresholds + operators + flags
├── sql/
│   ├── create_tables.sql            ← PostgreSQL schema
│   └── seed_data.sql                ← Sample operators, instruments, NC causes
└── src/
    ├── domain/
    │   ├── models.py                ← All dataclasses (FiberRecord, OtdrRecord, etc.)
    │   ├── master_thresholds.py     ← Threshold config loader
    │   └── mapper.py                ← CutInstructionProcess → FiberRecord
    ├── infrastructure/
    │   ├── db_connection.py         ← PostgreSQL connection factory
    │   ├── fiber_record_repository.py ← All DB queries (upsert, fetch, analysis)
    │   ├── otdr_parser.py           ← .rpt file parser
    │   └── otdr_analysis.py         ← Analyze() + Process() business logic
    └── ui/
        └── main_window.py           ← PyQt6 main window
```

---

## Setup Instructions

### Step 1 — Python
Make sure you have Python 3.10 or newer:
```
python --version
```

### Step 2 — Install dependencies
```
cd OTDR_Python
pip install -r requirements.txt
```

### Step 3 — PostgreSQL
1. Install PostgreSQL 13+ from https://www.postgresql.org/download/
2. Create a database:
```sql
CREATE DATABASE db_otdr;
```
3. Run the schema:
```
psql -U postgres -d db_otdr -f sql/create_tables.sql
```
4. Run seed data (operators, instruments):
```
psql -U postgres -d db_otdr -f sql/seed_data.sql
```

### Step 4 — Configure connection
Edit `config/appsettings.json`:
```json
{
  "ConnectionStrings": {
    "PostgreSQL": "postgresql://YOUR_USER:YOUR_PASSWORD@localhost:5432/db_otdr"
  }
}
```

### Step 5 — Run
```
python main.py
```

---

## DB Write Flag (InsertToServerDBTables)

The app respects the `InsertToServerDBTables` flag in `config/config.txt`.

| config.txt line              | Behaviour              |
|------------------------------|------------------------|
| `#InsertToServerDBTables=1`  | **Disabled** (comment) |
| `#InsertToServerDBTables=0`  | **Disabled** (comment) |
| `InsertToServerDBTables=0`   | **Disabled**           |
| `InsertToServerDBTables=1`   | **Enabled** ✅          |

To enable DB writes, open `config/config.txt` and change:
```
#InsertToServerDBTables=0
```
to:
```
InsertToServerDBTables=1
```

---

## Feature Mapping (C# → Python)

| C# Component              | Python Equivalent                          |
|---------------------------|--------------------------------------------|
| `frmotdr.cs` (WinForms)   | `src/ui/main_window.py` (PyQt6)            |
| `Domain/Models.cs`        | `src/domain/models.py`                     |
| `Domain/MasterThresholds` | `src/domain/master_thresholds.py`          |
| `Domain/Mapper.cs`        | `src/domain/mapper.py`                     |
| `Infrastructure/FiberRecordRepository.cs` | `src/infrastructure/fiber_record_repository.py` |
| `frmotdr.ParseFileAsync`  | `src/infrastructure/otdr_parser.py`        |
| `frmotdr.Analyze()`       | `src/infrastructure/otdr_analysis.analyze()`|
| `frmotdr.Process()`       | `src/infrastructure/otdr_analysis.process()`|
| SQL Server `MERGE`        | PostgreSQL `INSERT … ON CONFLICT DO UPDATE`|
| `ClosedXML` Excel export  | `openpyxl`                                 |
| `System.Windows.Forms.Timer` | `PyQt6.QtCore.QTimer`                   |
| `appsettings.json`        | `config/appsettings.json`                  |
| `config.txt`              | `config/config.txt`                        |
