-- ============================================================
--  OTDR Automation - PostgreSQL Schema
--  Converted from SQL Server to PostgreSQL
-- ============================================================
--
--  NOTE: The active table for all OTDR results is `fiber_records`.
--        It holds all 40+ parameters across 1310/1383/1550/1625 nm.
--        `otdr_results` below is kept only for reference (legacy, not used).
-- ============================================================

-- Legacy table (not written to by the Python app — kept for reference only)
CREATE TABLE IF NOT EXISTS otdr_results (
    fiber_id        VARCHAR(64)      NOT NULL,
    timestamp       TIMESTAMP        NOT NULL,
    length_km       DOUBLE PRECISION,
    top_lsa_1310    DOUBLE PRECISION, top_max_1310 DOUBLE PRECISION, top_min_1310 DOUBLE PRECISION,
    bot_lsa_1310    DOUBLE PRECISION, bot_max_1310 DOUBLE PRECISION, bot_min_1310 DOUBLE PRECISION,
    avg_lsa_1310    DOUBLE PRECISION, avg_max_1310 DOUBLE PRECISION, avg_min_1310 DOUBLE PRECISION,
    top_lsa_1550    DOUBLE PRECISION, top_max_1550 DOUBLE PRECISION, top_min_1550 DOUBLE PRECISION,
    bot_lsa_1550    DOUBLE PRECISION, bot_max_1550 DOUBLE PRECISION, bot_min_1550 DOUBLE PRECISION,
    avg_lsa_1550    DOUBLE PRECISION, avg_max_1550 DOUBLE PRECISION, avg_min_1550 DOUBLE PRECISION,
    pass            BOOLEAN          NOT NULL DEFAULT FALSE,
    analysis_note   VARCHAR(200),
    CONSTRAINT pk_otdr PRIMARY KEY (fiber_id, timestamp)
);

CREATE TABLE IF NOT EXISTS operators (
    op_id   VARCHAR(20)  NOT NULL PRIMARY KEY,
    name    VARCHAR(100) NOT NULL,
    active  BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS error_logs (
    id              BIGSERIAL       PRIMARY KEY,
    logged_at       TIMESTAMP       NOT NULL DEFAULT NOW(),
    err_number      VARCHAR(50)     NOT NULL,
    err_description VARCHAR(4000)   NOT NULL,
    module_name     VARCHAR(100),
    proc_name       VARCHAR(100),
    err_line_no     INTEGER,
    username        VARCHAR(128),
    computer_name   VARCHAR(128),
    network_name    VARCHAR(128)
);

CREATE TABLE IF NOT EXISTS fiber_records (
    fiber_id            VARCHAR(80)      NOT NULL PRIMARY KEY,
    test_date_and_time  VARCHAR(50),
    optical_length      DOUBLE PRECISION,
    status              VARCHAR(20),
    reason              VARCHAR(500),
    remarks             VARCHAR(1000),
    avg_lsa_1310        DOUBLE PRECISION, avg_lsa_1550 DOUBLE PRECISION,
    avg_lsa_1625        DOUBLE PRECISION, avg_lsa_1383 DOUBLE PRECISION,
    avg_max_1310        DOUBLE PRECISION, avg_max_1550 DOUBLE PRECISION,
    avg_max_1625        DOUBLE PRECISION, avg_max_1383 DOUBLE PRECISION,
    uni_max_1310        DOUBLE PRECISION, uni_max_1550 DOUBLE PRECISION,
    uni_max_1625        DOUBLE PRECISION, uni_max_1383 DOUBLE PRECISION,
    uni_min_1310        DOUBLE PRECISION, uni_min_1550 DOUBLE PRECISION,
    uni_min_1625        DOUBLE PRECISION, uni_min_1383 DOUBLE PRECISION,
    top_lsa_1310        DOUBLE PRECISION, top_lsa_1550 DOUBLE PRECISION,
    top_lsa_1625        DOUBLE PRECISION, top_lsa_1383 DOUBLE PRECISION,
    bot_lsa_1310        DOUBLE PRECISION, bot_lsa_1550 DOUBLE PRECISION,
    bot_lsa_1625        DOUBLE PRECISION, bot_lsa_1383 DOUBLE PRECISION,
    atnuni_1310         DOUBLE PRECISION, atnuni_1550 DOUBLE PRECISION,
    atnuni_1625         DOUBLE PRECISION, atnuni_1383 DOUBLE PRECISION,
    mfduni_1310         DOUBLE PRECISION, mfduni_1550 DOUBLE PRECISION,
    mfduni_1625         DOUBLE PRECISION, mfduni_1383 DOUBLE PRECISION,
    st13size            DOUBLE PRECISION, st15size DOUBLE PRECISION,
    spike               DOUBLE PRECISION,
    operator            VARCHAR(100),
    machine_id          VARCHAR(100),
    nc_cause            VARCHAR(200),
    created_date        TIMESTAMP        DEFAULT NOW(),
    updated_date        TIMESTAMP        DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS operator_master (
    id          SERIAL       PRIMARY KEY,
    operator    VARCHAR(100) NOT NULL,
    active      BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS instrument_master (
    id          SERIAL       PRIMARY KEY,
    instrument  VARCHAR(100) NOT NULL,
    active      BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS nc_cause_master (
    id       SERIAL       PRIMARY KEY,
    nc_cause VARCHAR(200) NOT NULL
);
