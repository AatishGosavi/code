-- ============================================================
--  Seed Data for OTDR Automation PostgreSQL Database
--  Run AFTER create_tables.sql
-- ============================================================

-- Operators (from config.txt)
INSERT INTO operator_master (operator, active) VALUES
    ('Ramesh',  TRUE),
    ('Suresh',  TRUE),
    ('Priya',   TRUE),
    ('Dinesh',  TRUE),
    ('Admin',   TRUE)
ON CONFLICT DO NOTHING;

-- Instruments
INSERT INTO instrument_master (instrument, active) VALUES
    ('OTDR 1', TRUE),
    ('OTDR 2', TRUE)
ON CONFLICT DO NOTHING;

-- NC Cause Master
INSERT INTO nc_cause_master (nc_cause) VALUES
    ('Bend Trace At 1310 nm'),
    ('Bend Trace At 1383 nm'),
    ('Bend Trace At 1550 nm'),
    ('Bend Trace At 1625 nm'),
    ('Sectional Fail'),
    ('Step At 1310 nm'),
    ('Step At 1550 nm'),
    ('Step At 1625 nm'),
    ('Step At 1383 nm')
ON CONFLICT DO NOTHING;
