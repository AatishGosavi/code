"""
OTDR Automation - Python Edition
Entry point. Converted from C# Program.cs.
"""
import sys
import os

# Add project root to path so `src.*` imports work
sys.path.insert(0, os.path.dirname(__file__))

from PyQt6.QtWidgets import QApplication
from src.ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("OTDR Automation")
    app.setStyle("Fusion")

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
