"""
Mapper — converted from C# Domain/Mapper.cs
Maps CutInstructionProcess → FiberRecord
"""
from __future__ import annotations
from typing import List, Optional
from .models import FiberRecord, CutInstructionProcess


def _r3nz(value: Optional[float]) -> float:
    """Round to 3 decimal places, return 0.0 if None."""
    if value is None:
        return 0.0
    return round(value, 3)


def to_fiber_record(cut: CutInstructionProcess) -> FiberRecord:
    return FiberRecord(
        fiber_id=cut.fibre_id,
        test_date_and_time=cut.test_time,
        optical_length=cut.fiber_length,
        status=cut.status,
        remarks=cut.cutting_instruction,
        reason=cut.reason,
        nc_cause=cut.nc_clause,

        avg_lsa_1310=_r3nz(cut.avg_lsa_1310),
        avg_max_1310=_r3nz(cut.top_max_1310),

        uni_max_1310=_r3nz(cut.unimax_1310),
        uni_max_1550=_r3nz(cut.unimax_1550),
        uni_max_1625=_r3nz(cut.unimax_1625),
        uni_max_1383=_r3nz(cut.unimax_1383),

        uni_min_1310=_r3nz(cut.unimin_1310),
        uni_min_1550=_r3nz(cut.unimin_1550),
        uni_min_1625=_r3nz(cut.unimin_1625),
        uni_min_1383=_r3nz(cut.unimin_1383),

        avg_lsa_1550=_r3nz(cut.avg_lsa_1550),
        avg_max_1550=_r3nz(cut.avg_max_1550),
        avg_lsa_1625=_r3nz(cut.avg_lsa_1625),
        avg_max_1625=_r3nz(cut.avg_max_1625),
        avg_lsa_1383=_r3nz(cut.avg_lsa_1383),
        avg_max_1383=_r3nz(cut.avg_max_1383),

        top_lsa_1310=_r3nz(cut.top_lsa_1310),
        top_lsa_1550=_r3nz(cut.top_lsa_1550),
        top_lsa_1625=_r3nz(cut.top_lsa_1625),
        top_lsa_1383=_r3nz(cut.top_lsa_1383),
        bot_lsa_1310=_r3nz(cut.bot_lsa_1310),
        bot_lsa_1550=_r3nz(cut.bot_lsa_1550),
        bot_lsa_1625=_r3nz(cut.bot_lsa_1625),
        bot_lsa_1383=_r3nz(cut.bot_lsa_1383),

        atnuni_1310=_r3nz(cut.atnuni_1310),
        atnuni_1550=_r3nz(cut.atnuni_1550),
        atnuni_1625=_r3nz(cut.atnuni_1625),
        atnuni_1383=_r3nz(cut.atnuni_1383),

        mfduni_1310=_r3nz(cut.mfduni_1310),
        mfduni_1550=_r3nz(cut.mfduni_1550),
        mfduni_1625=_r3nz(cut.mfduni_1625),
        mfduni_1383=_r3nz(cut.mfduni_1383),

        st13size=_r3nz(cut.st13size),
        st15size=_r3nz(cut.st15size),
        spike=_r3nz(cut.spike),

        operator=cut.operator,
        machine_id=cut.otdr_no,
    )


def to_fiber_record_list(cuts: List[CutInstructionProcess]) -> List[FiberRecord]:
    return [to_fiber_record(c) for c in cuts]
