"""
Domain models — converted from C# Domain/Models.cs and Domain/OtdrMeasurement.cs
"""
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime


@dataclass
class OtdrMeasurement:
    fiber_id: str = ""
    timestamp: datetime = field(default_factory=datetime.utcnow)
    length_km: float = 0.0

    # 1310 nm
    top_lsa_1310: float = 0.0
    top_max_1310: float = 0.0
    top_min_1310: float = 0.0
    bot_lsa_1310: float = 0.0
    bot_max_1310: float = 0.0
    bot_min_1310: float = 0.0
    avg_lsa_1310: float = 0.0
    avg_max_1310: float = 0.0
    avg_min_1310: float = 0.0

    # 1550 nm
    top_lsa_1550: float = 0.0
    top_max_1550: float = 0.0
    top_min_1550: float = 0.0
    bot_lsa_1550: float = 0.0
    bot_max_1550: float = 0.0
    bot_min_1550: float = 0.0
    avg_lsa_1550: float = 0.0
    avg_max_1550: float = 0.0
    avg_min_1550: float = 0.0

    # Derived
    pass_: bool = False
    analysis_note: Optional[str] = None


@dataclass
class FiberRecord:
    fiber_id: str = ""
    test_date_and_time: Optional[str] = None
    optical_length: Optional[float] = None
    status: Optional[str] = None
    reason: Optional[str] = None
    remarks: Optional[str] = None

    avg_lsa_1310: Optional[float] = None
    avg_lsa_1550: Optional[float] = None
    avg_lsa_1625: Optional[float] = None
    avg_lsa_1383: Optional[float] = None

    avg_max_1310: Optional[float] = None
    avg_max_1550: Optional[float] = None
    avg_max_1625: Optional[float] = None
    avg_max_1383: Optional[float] = None

    uni_max_1310: Optional[float] = None
    uni_max_1550: Optional[float] = None
    uni_max_1625: Optional[float] = None
    uni_max_1383: Optional[float] = None

    uni_min_1310: Optional[float] = None
    uni_min_1550: Optional[float] = None
    uni_min_1625: Optional[float] = None
    uni_min_1383: Optional[float] = None

    top_lsa_1310: Optional[float] = None
    top_lsa_1550: Optional[float] = None
    top_lsa_1625: Optional[float] = None
    top_lsa_1383: Optional[float] = None

    bot_lsa_1310: Optional[float] = None
    bot_lsa_1550: Optional[float] = None
    bot_lsa_1625: Optional[float] = None
    bot_lsa_1383: Optional[float] = None

    atnuni_1310: Optional[float] = None
    atnuni_1550: Optional[float] = None
    atnuni_1625: Optional[float] = None
    atnuni_1383: Optional[float] = None

    mfduni_1310: Optional[float] = None
    mfduni_1550: Optional[float] = None
    mfduni_1625: Optional[float] = None
    mfduni_1383: Optional[float] = None

    st13size: Optional[float] = None
    st15size: Optional[float] = None
    spike: Optional[float] = None

    operator: Optional[str] = None
    machine_id: Optional[str] = None
    nc_cause: Optional[str] = None


@dataclass
class AttenuationRecord:
    test_time: str = ""
    top_lsa_1310: float = 0.0; top_max_1310: float = 0.0; top_min_1310: float = 0.0
    bot_lsa_1310: float = 0.0; bot_max_1310: float = 0.0; bot_min_1310: float = 0.0
    avg_lsa_1310: float = 0.0; avg_max_1310: float = 0.0; avg_min_1310: float = 0.0

    top_lsa_1550: float = 0.0; top_max_1550: float = 0.0; top_min_1550: float = 0.0
    bot_lsa_1550: float = 0.0; bot_max_1550: float = 0.0; bot_min_1550: float = 0.0
    avg_lsa_1550: float = 0.0; avg_max_1550: float = 0.0; avg_min_1550: float = 0.0

    top_lsa_1383: float = 0.0; top_max_1383: float = 0.0; top_min_1383: float = 0.0
    bot_lsa_1383: float = 0.0; bot_max_1383: float = 0.0; bot_min_1383: float = 0.0
    avg_lsa_1383: float = 0.0; avg_max_1383: float = 0.0; avg_min_1383: float = 0.0

    top_lsa_1625: float = 0.0; top_max_1625: float = 0.0; top_min_1625: float = 0.0
    bot_lsa_1625: float = 0.0; bot_max_1625: float = 0.0; bot_min_1625: float = 0.0
    avg_lsa_1625: float = 0.0; avg_max_1625: float = 0.0; avg_min_1625: float = 0.0


@dataclass
class OtdrRecord:
    fibre_id: str = ""
    dist_position: float = 0.0
    fiber_length: float = 0.0
    fiber_length_be: float = 0.0
    length_mm: float = 0.0

    top_sec_loss_1310: float = 0.0; bot_sec_loss_1310: float = 0.0; avg_sec_loss_1310: float = 0.0
    top_sec_loss_1383: float = 0.0; bot_sec_loss_1383: float = 0.0; avg_sec_loss_1383: float = 0.0
    top_sec_loss_1550: float = 0.0; bot_sec_loss_1550: float = 0.0; avg_sec_loss_1550: float = 0.0
    top_sec_loss_1625: float = 0.0; bot_sec_loss_1625: float = 0.0; avg_sec_loss_1625: float = 0.0

    avg_lsa_1310: float = 0.0; avg_lsa_1383: float = 0.0
    avg_lsa_1550: float = 0.0; avg_lsa_1625: float = 0.0

    ha_1310: bool = False; ha_1383: bool = False; ha_1550: bool = False

    attnu_1310: float = 0.0; attnu_1383: float = 0.0
    attnu_1550: float = 0.0; attnu_1625: float = 0.0

    mfd_1310: float = 0.0; mfd_1383: float = 0.0
    mfd_1550: float = 0.0; mfd_1625: float = 0.0

    attenuation_record: Optional[AttenuationRecord] = None


@dataclass
class SpikeRecord:
    fibre_id: str = ""
    barcode_id: str = ""
    type: str = ""        # "Step" or "Reflectance"
    spike_type: int = 0   # 1310, 1550, etc.
    spike_value: float = 0.0
    spike_position: float = 0.0
    plant: str = ""
    otdr_no: str = ""
    test_date: datetime = field(default_factory=datetime.utcnow)


@dataclass
class CutInstruction:
    fibre_id: str = ""
    fibre_length: float = 0.0
    status: str = ""
    position: float = 0.0
    is_step: bool = False
    step_type: str = ""
    reason: str = ""
    nc_clause: str = ""
    cutting_instruction: str = ""
    parameter: str = ""
    value: str = ""
    master_value: str = ""
    attenuation_record: Optional[AttenuationRecord] = None


@dataclass
class CutInstructionProcess:
    sr_no: int = 0
    fibre_id: str = ""
    test_time: str = ""
    fiber_length: float = 0.0
    status: str = ""
    otdr_no: str = ""
    operator: str = ""
    position: float = 0.0
    is_step: bool = False
    is_fail: bool = False
    reason: str = ""
    nc_clause: str = ""
    cutting_instruction: str = ""

    avg_lsa_1310: float = 0.0; avg_lsa_1550: float = 0.0
    avg_lsa_1625: float = 0.0; avg_lsa_1383: float = 0.0
    avg_max_1310: float = 0.0; avg_max_1550: float = 0.0
    avg_max_1625: float = 0.0; avg_max_1383: float = 0.0

    top_lsa_1310: float = 0.0; top_lsa_1550: float = 0.0
    bot_lsa_1310: float = 0.0; bot_lsa_1550: float = 0.0

    top_max_1310: float = 0.0; top_min_1310: float = 0.0
    bot_max_1310: float = 0.0; bot_min_1310: float = 0.0
    top_max_1550: float = 0.0; top_min_1550: float = 0.0
    bot_max_1550: float = 0.0; bot_min_1550: float = 0.0

    top_lsa_1625: float = 0.0; top_max_1625: float = 0.0; top_min_1625: float = 0.0
    bot_lsa_1625: float = 0.0; bot_max_1625: float = 0.0; bot_min_1625: float = 0.0
    avg_min_1625: float = 0.0

    top_lsa_1383: float = 0.0; top_max_1383: float = 0.0; top_min_1383: float = 0.0
    bot_lsa_1383: float = 0.0; bot_max_1383: float = 0.0; bot_min_1383: float = 0.0
    avg_min_1383: float = 0.0

    unimax_1310: float = 0.0; unimax_1383: float = 0.0
    unimax_1550: float = 0.0; unimax_1625: float = 0.0
    unimin_1310: float = 0.0; unimin_1383: float = 0.0
    unimin_1550: float = 0.0; unimin_1625: float = 0.0

    atnuni_1310: Optional[float] = None; atnuni_1383: Optional[float] = None
    atnuni_1550: Optional[float] = None; atnuni_1625: Optional[float] = None

    mfduni_1310: Optional[float] = None; mfduni_1383: Optional[float] = None
    mfduni_1550: Optional[float] = None; mfduni_1625: Optional[float] = None

    st13size: Optional[float] = None
    st15size: Optional[float] = None
    spike: Optional[float] = None


@dataclass
class FiberRecordDataView:
    fiber_id: str = ""
    fiber_length: str = ""
    status: str = ""
    reason: str = ""
    remark: str = ""


@dataclass
class OperatorData:
    id: int = 0
    name: str = ""
    active: bool = True


@dataclass
class Instrument:
    id: int = 0
    name: str = ""
    active: bool = True
