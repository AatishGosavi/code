"""
MasterThresholds — converted from C# MasterThresholds.cs
Loads threshold values from config.txt and parses the [Operators] section.
"""
from __future__ import annotations
import os
from typing import Tuple, List


class MasterThresholds:
    def __init__(self):
        self.AT1310: float = 0.34
        self.AT1550: float = 0.210
        self.AT1383: float = 2.0
        self.Attu1310: float = 0.02
        self.Attu1383: float = 0.02
        self.Attu1550: float = 0.02
        self.Mfdu1310: float = 0.025
        self.Mfdu1383: float = 0.025
        self.Mfdu1550: float = 0.025
        self.StepSize1310: float = 0.01
        self.StepSize1550: float = 0.01
        self.CuttingLen: float = 0.1
        self.StandardLen: float = 4.2

    @classmethod
    def load_from_file(cls, file_path: str) -> Tuple["MasterThresholds", List[str]]:
        """Load thresholds and operator list from config.txt"""
        thresholds = cls()
        operators: List[str] = []

        if not os.path.exists(file_path):
            return thresholds, operators

        # Read masterThresholdmargin first
        margin = 0.0
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if stripped.lower().startswith("#masterthresholdmargin"):
                    parts = stripped.split("=", 1)
                    if len(parts) == 2:
                        try:
                            margin = float(parts[1].strip())
                        except ValueError:
                            pass
                    break

        field_map: dict[str, float] = {}
        operator_section = False

        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                trimmed = line.strip()
                if not trimmed or trimmed.startswith("#"):
                    continue
                if trimmed.lower() == "[operators]":
                    operator_section = True
                    continue
                if operator_section:
                    operators.append(trimmed)
                    continue
                # key,value pair
                parts = trimmed.split(",", 1)
                if len(parts) == 2:
                    try:
                        val = float(parts[1].strip())
                        field_map[parts[0].strip()] = val
                    except ValueError:
                        pass

        # Apply to threshold fields
        for attr in vars(thresholds):
            if attr in field_map:
                v = field_map[attr]
                if v > 0:
                    v = v - margin
                setattr(thresholds, attr, v)

        return thresholds, operators
