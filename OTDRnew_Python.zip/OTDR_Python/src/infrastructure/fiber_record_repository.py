"""
FiberRecordRepository
Works with PostgreSQL (psycopg2) or SQLite (built-in).
SQL Server MERGE  →  INSERT … ON CONFLICT DO UPDATE  (Postgres)
                 →  INSERT OR REPLACE                (SQLite)
"""
from __future__ import annotations
import os
from datetime import date
from typing import List

from src.domain.models import FiberRecord, OperatorData, Instrument
from src.infrastructure.db_connection import (
    create_connection, dict_rows, is_postgres, execute_script,
)


# ── flag helper ────────────────────────────────────────────────────────────

def _read_insert_flag(config_path: str) -> bool:
    """
    Return True only when an UNCOMMENTED line InsertToServerDBTables=1 exists.
    A line starting with '#' is always treated as a comment (disabled).
    """
    if not os.path.exists(config_path):
        return False
    with open(config_path, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if stripped.lower().startswith("inserttoserverdbtables"):
                parts = stripped.split("=", 1)
                if len(parts) == 2:
                    try:
                        return int(parts[1].strip()) == 1
                    except ValueError:
                        pass
    return False


# ── auto-create tables (SQLite only) ──────────────────────────────────────

_SQLITE_DDL = """
CREATE TABLE IF NOT EXISTS fiber_records (
    fiber_id TEXT PRIMARY KEY,
    test_date_and_time TEXT, optical_length REAL, status TEXT,
    reason TEXT, remarks TEXT,
    avg_lsa_1310 REAL, avg_lsa_1550 REAL, avg_lsa_1625 REAL, avg_lsa_1383 REAL,
    avg_max_1310 REAL, avg_max_1550 REAL, avg_max_1625 REAL, avg_max_1383 REAL,
    uni_max_1310 REAL, uni_max_1550 REAL, uni_max_1625 REAL, uni_max_1383 REAL,
    uni_min_1310 REAL, uni_min_1550 REAL, uni_min_1625 REAL, uni_min_1383 REAL,
    top_lsa_1310 REAL, top_lsa_1550 REAL, top_lsa_1625 REAL, top_lsa_1383 REAL,
    bot_lsa_1310 REAL, bot_lsa_1550 REAL, bot_lsa_1625 REAL, bot_lsa_1383 REAL,
    atnuni_1310 REAL, atnuni_1550 REAL, atnuni_1625 REAL, atnuni_1383 REAL,
    mfduni_1310 REAL, mfduni_1550 REAL, mfduni_1625 REAL, mfduni_1383 REAL,
    st13size REAL, st15size REAL, spike REAL,
    operator TEXT, machine_id TEXT, nc_cause TEXT,
    created_date TEXT DEFAULT (datetime('now')),
    updated_date TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS operator_master (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    operator TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS instrument_master (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    instrument TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS nc_cause_master (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nc_cause TEXT NOT NULL
);
"""

_SQLITE_SEED = """
INSERT OR IGNORE INTO operator_master (operator, active) VALUES
    ('Ramesh',1),('Suresh',1),('Priya',1),('Dinesh',1),('Admin',1);
INSERT OR IGNORE INTO instrument_master (instrument, active) VALUES
    ('OTDR 1',1),('OTDR 2',1);
"""


def ensure_tables() -> None:
    """Create SQLite tables + seed data if they don't exist yet."""
    if not is_postgres():
        execute_script(_SQLITE_DDL)
        execute_script(_SQLITE_SEED)


# ── upsert SQL ─────────────────────────────────────────────────────────────

_COLS = (
    "fiber_id, test_date_and_time, optical_length, status, reason, remarks, "
    "avg_lsa_1310, avg_lsa_1550, avg_lsa_1625, avg_lsa_1383, "
    "avg_max_1310, avg_max_1550, avg_max_1625, avg_max_1383, "
    "uni_max_1310, uni_max_1550, uni_max_1625, uni_max_1383, "
    "uni_min_1310, uni_min_1550, uni_min_1625, uni_min_1383, "
    "top_lsa_1310, top_lsa_1550, top_lsa_1625, top_lsa_1383, "
    "bot_lsa_1310, bot_lsa_1550, bot_lsa_1625, bot_lsa_1383, "
    "atnuni_1310,  atnuni_1550,  atnuni_1625,  atnuni_1383, "
    "mfduni_1310,  mfduni_1550,  mfduni_1625,  mfduni_1383, "
    "st13size, st15size, spike, operator, machine_id, nc_cause"
)

_UPDATE_SET = ", ".join(
    f"{c.strip()} = EXCLUDED.{c.strip()}"
    for c in _COLS.split(",")
    if c.strip() != "fiber_id"
)


def _build_upsert_pg() -> str:
    placeholders = ", ".join(f"%({c.strip()})s" for c in _COLS.split(","))
    return (
        f"INSERT INTO fiber_records ({_COLS}, created_date, updated_date) "
        f"VALUES ({placeholders}, NOW(), NOW()) "
        f"ON CONFLICT (fiber_id) DO UPDATE SET {_UPDATE_SET}, updated_date = NOW();"
    )


def _build_upsert_sqlite() -> str:
    # SQLite uses positional ? placeholders
    col_list = [c.strip() for c in _COLS.split(",")]
    placeholders = ", ".join("?" * len(col_list))
    return (
        f"INSERT OR REPLACE INTO fiber_records ({_COLS}) "
        f"VALUES ({placeholders});"
    )


def _record_to_params_pg(f: FiberRecord) -> dict:
    return {
        "fiber_id": f.fiber_id,
        "test_date_and_time": f.test_date_and_time,
        "optical_length": f.optical_length,
        "status": f.status,
        "reason": f.reason,
        "remarks": f.remarks,
        "avg_lsa_1310": f.avg_lsa_1310, "avg_lsa_1550": f.avg_lsa_1550,
        "avg_lsa_1625": f.avg_lsa_1625, "avg_lsa_1383": f.avg_lsa_1383,
        "avg_max_1310": f.avg_max_1310, "avg_max_1550": f.avg_max_1550,
        "avg_max_1625": f.avg_max_1625, "avg_max_1383": f.avg_max_1383,
        "uni_max_1310": f.uni_max_1310, "uni_max_1550": f.uni_max_1550,
        "uni_max_1625": f.uni_max_1625, "uni_max_1383": f.uni_max_1383,
        "uni_min_1310": f.uni_min_1310, "uni_min_1550": f.uni_min_1550,
        "uni_min_1625": f.uni_min_1625, "uni_min_1383": f.uni_min_1383,
        "top_lsa_1310": f.top_lsa_1310, "top_lsa_1550": f.top_lsa_1550,
        "top_lsa_1625": f.top_lsa_1625, "top_lsa_1383": f.top_lsa_1383,
        "bot_lsa_1310": f.bot_lsa_1310, "bot_lsa_1550": f.bot_lsa_1550,
        "bot_lsa_1625": f.bot_lsa_1625, "bot_lsa_1383": f.bot_lsa_1383,
        "atnuni_1310":  f.atnuni_1310,  "atnuni_1550":  f.atnuni_1550,
        "atnuni_1625":  f.atnuni_1625,  "atnuni_1383":  f.atnuni_1383,
        "mfduni_1310":  f.mfduni_1310,  "mfduni_1550":  f.mfduni_1550,
        "mfduni_1625":  f.mfduni_1625,  "mfduni_1383":  f.mfduni_1383,
        "st13size": f.st13size or 0, "st15size": f.st15size or 0,
        "spike":    f.spike or 0,
        "operator": f.operator, "machine_id": f.machine_id, "nc_cause": f.nc_cause,
    }


def _record_to_params_sqlite(f: FiberRecord) -> tuple:
    d = _record_to_params_pg(f)
    return tuple(d[c.strip()] for c in _COLS.split(","))


# ── public API ─────────────────────────────────────────────────────────────

def insert_fiber_records(fiber_records: List[FiberRecord], config_path: str) -> str:
    """
    Upsert fiber records into the database.
    Respects InsertToServerDBTables flag in config.txt:
      - Commented / =0 → skip, return info message.
      - =1 (uncommented) → write to DB.
    """
    if not _read_insert_flag(config_path):
        return "InsertToServerDBTables flag is disabled in config.txt. Skipping DB write."

    ensure_tables()
    try:
        conn = create_connection()
        cur = conn.cursor()
        if is_postgres():
            sql = _build_upsert_pg()
            for f in fiber_records:
                cur.execute(sql, _record_to_params_pg(f))
        else:
            sql = _build_upsert_sqlite()
            for f in fiber_records:
                cur.execute(sql, _record_to_params_sqlite(f))
        conn.commit()
        cur.close()
        conn.close()
        return f"Data inserted ({len(fiber_records)} records)."
    except Exception as ex:
        return f"DB error: {ex}"


def get_fiber_records_by_date(from_date: date, to_date: date) -> List[dict]:
    ensure_tables()
    if is_postgres():
        sql = """
            SELECT fiber_id AS "Fiber ID", test_date_and_time AS "Test Date and Time",
                optical_length AS "Optical Length", status AS "STATUS",
                reason AS "REASON", remarks AS "REMARKS",
                avg_lsa_1310 AS "Avg ATN1310", avg_lsa_1550 AS "Avg ATN1550",
                avg_lsa_1625 AS "Avg ATN1625", avg_lsa_1383 AS "Avg ATN1383",
                avg_max_1310 AS "AvgMax1310", avg_max_1550 AS "AvgMax1550",
                top_lsa_1310 AS "TOP LSA 1310", top_lsa_1550 AS "TOP LSA 1550",
                bot_lsa_1310 AS "BOT LSA 1310", bot_lsa_1550 AS "BOT LSA 1550",
                atnuni_1310 AS "ATNUNI1310", atnuni_1550 AS "ATNUNI1550",
                mfduni_1310 AS "MFDUNI1310", mfduni_1550 AS "MFDUNI1550",
                st13size, st15size, spike,
                operator AS "OPERATOR", machine_id AS "Machine ID",
                created_date AS "CreatedDate", updated_date AS "UpdatedDate"
            FROM fiber_records
            WHERE created_date::date BETWEEN %(from_date)s AND %(to_date)s
            ORDER BY created_date DESC;
        """
        conn = create_connection()
        from psycopg2.extras import RealDictCursor
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(sql, {"from_date": from_date, "to_date": to_date})
    else:
        sql = """
            SELECT fiber_id, test_date_and_time, optical_length, status,
                reason, remarks, avg_lsa_1310, avg_lsa_1550, avg_lsa_1625, avg_lsa_1383,
                avg_max_1310, avg_max_1550, top_lsa_1310, top_lsa_1550,
                bot_lsa_1310, bot_lsa_1550, atnuni_1310, atnuni_1550,
                mfduni_1310, mfduni_1550, st13size, st15size, spike,
                operator, machine_id, created_date, updated_date
            FROM fiber_records
            WHERE date(created_date) BETWEEN ? AND ?
            ORDER BY created_date DESC;
        """
        conn = create_connection()
        cur = conn.cursor()
        cur.execute(sql, (str(from_date), str(to_date)))
    rows = dict_rows(cur)
    cur.close()
    conn.close()
    return rows


def get_fiber_records_by_date_operator(
    from_date: date, to_date: date, operator: str, hourly_wise: bool = False
) -> List[dict]:
    ensure_tables()
    if is_postgres():
        if hourly_wise:
            sql = """
                SELECT operator, created_date::date AS "TestDate",
                    SUM(CASE WHEN EXTRACT(HOUR FROM created_date)=0  THEN 1 ELSE 0 END) AS "0AM",
                    SUM(CASE WHEN EXTRACT(HOUR FROM created_date)=6  THEN 1 ELSE 0 END) AS "6AM",
                    SUM(CASE WHEN EXTRACT(HOUR FROM created_date)=12 THEN 1 ELSE 0 END) AS "12PM",
                    SUM(CASE WHEN EXTRACT(HOUR FROM created_date)=18 THEN 1 ELSE 0 END) AS "6PM"
                FROM fiber_records
                WHERE created_date::date BETWEEN %(from_date)s AND %(to_date)s
                GROUP BY operator, created_date::date ORDER BY operator, "TestDate";
            """
        else:
            sql = """
                SELECT operator, created_date::date AS "TestDate",
                    COUNT(*) AS "TotalBobbins",
                    SUM(CASE WHEN UPPER(status)='PASS'   THEN 1 ELSE 0 END) AS "PassCount",
                    SUM(CASE WHEN UPPER(status)='FAIL'   THEN 1 ELSE 0 END) AS "FailCount",
                    SUM(CASE WHEN UPPER(status)='REW'    THEN 1 ELSE 0 END) AS "ReworkCount",
                    SUM(CASE WHEN UPPER(status)='RETEST' THEN 1 ELSE 0 END) AS "RetestCount"
                FROM fiber_records
                WHERE created_date::date BETWEEN %(from_date)s AND %(to_date)s
                GROUP BY operator, created_date::date ORDER BY operator, "TestDate";
            """
        from psycopg2.extras import RealDictCursor
        conn = create_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(sql, {"from_date": from_date, "to_date": to_date})
    else:
        if hourly_wise:
            sql = """
                SELECT operator, date(created_date) AS TestDate,
                    SUM(CASE WHEN CAST(strftime('%H',created_date) AS INT)=0  THEN 1 ELSE 0 END) AS "0AM",
                    SUM(CASE WHEN CAST(strftime('%H',created_date) AS INT)=6  THEN 1 ELSE 0 END) AS "6AM",
                    SUM(CASE WHEN CAST(strftime('%H',created_date) AS INT)=12 THEN 1 ELSE 0 END) AS "12PM",
                    SUM(CASE WHEN CAST(strftime('%H',created_date) AS INT)=18 THEN 1 ELSE 0 END) AS "6PM"
                FROM fiber_records
                WHERE date(created_date) BETWEEN ? AND ?
                GROUP BY operator, date(created_date) ORDER BY operator, TestDate;
            """
        else:
            sql = """
                SELECT operator, date(created_date) AS TestDate,
                    COUNT(*) AS TotalBobbins,
                    SUM(CASE WHEN UPPER(status)='PASS'   THEN 1 ELSE 0 END) AS PassCount,
                    SUM(CASE WHEN UPPER(status)='FAIL'   THEN 1 ELSE 0 END) AS FailCount,
                    SUM(CASE WHEN UPPER(status)='REW'    THEN 1 ELSE 0 END) AS ReworkCount,
                    SUM(CASE WHEN UPPER(status)='RETEST' THEN 1 ELSE 0 END) AS RetestCount
                FROM fiber_records
                WHERE date(created_date) BETWEEN ? AND ?
                GROUP BY operator, date(created_date) ORDER BY operator, TestDate;
            """
        conn = create_connection()
        cur = conn.cursor()
        cur.execute(sql, (str(from_date), str(to_date)))
    rows = dict_rows(cur)
    cur.close()
    conn.close()
    return rows


def get_all_active_operators() -> List[OperatorData]:
    ensure_tables()
    conn = create_connection()
    cur = conn.cursor()
    if is_postgres():
        cur.execute("SELECT id, operator AS name, active FROM operator_master WHERE active=TRUE ORDER BY operator;")
    else:
        cur.execute("SELECT id, operator AS name, active FROM operator_master WHERE active=1 ORDER BY operator;")
    rows = dict_rows(cur)
    cur.close()
    conn.close()
    return [OperatorData(id=r["id"], name=r["name"], active=bool(r["active"])) for r in rows]


def get_all_active_instruments() -> List[Instrument]:
    ensure_tables()
    conn = create_connection()
    cur = conn.cursor()
    if is_postgres():
        cur.execute("SELECT id, instrument AS name, active FROM instrument_master WHERE active=TRUE ORDER BY instrument;")
    else:
        cur.execute("SELECT id, instrument AS name, active FROM instrument_master WHERE active=1 ORDER BY instrument;")
    rows = dict_rows(cur)
    cur.close()
    conn.close()
    return [Instrument(id=r["id"], name=r["name"], active=bool(r["active"])) for r in rows]
