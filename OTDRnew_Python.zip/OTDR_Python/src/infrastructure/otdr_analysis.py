"""
OtdrAnalysis — converted from C# frmotdr.Analyze() and frmotdr.Process() methods.
Pure business logic, no UI dependencies.
"""
from __future__ import annotations
from typing import List, Tuple

from src.domain.models import (
    OtdrRecord, SpikeRecord, CutInstruction, CutInstructionProcess, AttenuationRecord,
)
from src.domain.master_thresholds import MasterThresholds


# ---------------------------------------------------------------------------
# Analyze
# ---------------------------------------------------------------------------

def analyze(
    records: List[OtdrRecord],
    spikes_list: List[SpikeRecord],
    master: MasterThresholds,
) -> Tuple[List[OtdrRecord], List[CutInstruction]]:
    """Evaluate each OtdrRecord against thresholds and produce CutInstruction list."""
    cuts: List[CutInstruction] = []

    def _add(rec: OtdrRecord, reason: str, nc_clause: str, status: str,
             param: str = "", value: str = "", master_val: str = "",
             is_step: bool = False, step_type: str = "", position: float = -1.0):
        pos = position if position >= 0 else rec.dist_position
        cuts.append(CutInstruction(
            fibre_id=rec.fibre_id,
            fibre_length=rec.fiber_length,
            status=status,
            position=pos,
            is_step=is_step,
            step_type=step_type,
            reason=reason,
            nc_clause=nc_clause,
            parameter=param,
            value=value,
            master_value=master_val,
            attenuation_record=rec.attenuation_record,
        ))

    for rec in records:
        fiber_diff = abs(rec.fiber_length * 1000 - rec.fiber_length_be * 1000)
        if fiber_diff > 25:
            _add(rec,
                 reason=f"Fiber length difference exceeds 25 m ({fiber_diff:.2f} m)",
                 nc_clause="", status="RETEST",
                 param="LENGTH",
                 value=f"{rec.fiber_length} and {rec.fiber_length_be}",
                 master_val=str(master.AT1310))
            continue

        # --- Spikes for this fibre ---
        fibre_spikes = [s for s in spikes_list if s.fibre_id.upper() == rec.fibre_id.upper()]
        existing_steps = [c for c in cuts if c.fibre_id.upper() == rec.fibre_id.upper() and c.is_step]

        if fibre_spikes and not existing_steps:
            for spike in fibre_spikes:
                record_spike = False
                if spike.type.upper() == "STEP" and spike.spike_value > master.StepSize1550 and spike.spike_type == 1550:
                    record_spike = True
                if spike.type.upper() == "STEP" and spike.spike_value > master.StepSize1310 and spike.spike_type == 1310:
                    record_spike = True
                if spike.type.upper() == "REFLECTANCE":
                    record_spike = True

                if record_spike:
                    if spike.type.upper() == "REFLECTANCE":
                        reason = f"Spike@{spike.spike_type}"
                        nc_clause = f"Step At {spike.spike_type} nm"
                    else:
                        reason = f"{spike.type}@{spike.spike_type}"
                        nc_clause = f"Step At {spike.spike_type} nm"

                    cuts.append(CutInstruction(
                        fibre_id=spike.fibre_id,
                        fibre_length=rec.fiber_length,
                        is_step=True,
                        step_type=str(spike.spike_type),
                        position=spike.spike_position,
                        nc_clause=nc_clause,
                        reason=reason,
                        status="REW",
                        value=str(spike.spike_value),
                        attenuation_record=rec.attenuation_record,
                    ))

        if rec.dist_position > 0:
            # ATTU checks
            if abs(rec.avg_lsa_1310 - rec.avg_sec_loss_1310) > master.Attu1310:
                _add(rec, "ATTU1310", "Bend Trace At 1310 nm", "REW",
                     "AvgLsa1310", str(rec.avg_lsa_1310), str(master.Attu1310))

            if abs(rec.avg_lsa_1383 - rec.avg_sec_loss_1383) > master.Attu1383 and rec.dist_position > 0.5:
                _add(rec, "ATTU1383", "Bend Trace At 1383 nm", "REW",
                     "AvgLsa1383", str(rec.avg_lsa_1383), str(master.Attu1383))

            if abs(rec.avg_lsa_1550 - rec.avg_sec_loss_1550) > master.Attu1550:
                _add(rec, "ATTU1550", "Bend Trace At 1550 nm", "REW",
                     "ATTU1550", str(abs(rec.avg_lsa_1550 - rec.avg_sec_loss_1550)), str(master.Attu1550))

            # MFD checks
            if rec.mfd_1310 > master.Mfdu1310:
                _add(rec, "BC@1310", "Bend Trace At 1310 nm", "REW")
            if rec.mfd_1383 > master.Mfdu1383:
                _add(rec, "BC@1383", "Bend Trace At 1383 nm", "REW")
            if rec.mfd_1550 > master.Mfdu1550:
                _add(rec, "BC@1550", "Bend Trace At 1550 nm", "REW")

            # HA flags
            if rec.ha_1310:
                _add(rec, "HA1310", "Sectional Fail", "REW")
            if rec.ha_1550:
                _add(rec, "HA1550", "Sectional Fail", "REW")
            if rec.ha_1383:
                _add(rec, "HA1383", "Sectional Fail", "REW")

            # If no cut recorded yet → PASS
            has_cut = any(c.fibre_id == rec.fibre_id for c in cuts)
            if not has_cut:
                _add(rec, "", "", "PASS", position=0.0)
            else:
                # Remove PASS if there's a REW
                has_rew = any(c.fibre_id == rec.fibre_id and c.status == "REW" for c in cuts)
                if has_rew:
                    cuts[:] = [c for c in cuts if not (c.fibre_id == rec.fibre_id and c.status == "PASS")]

    return records, cuts


# ---------------------------------------------------------------------------
# Process (cluster + cut instruction builder)
# ---------------------------------------------------------------------------

def _fill_attenuation(cut_proc: CutInstructionProcess,
                      record: AttenuationRecord,
                      otdr_data: List[OtdrRecord],
                      otdr_no: str, operator: str) -> None:
    cut_proc.test_time = record.test_time
    cut_proc.top_lsa_1310 = record.top_lsa_1310; cut_proc.top_max_1310 = record.top_max_1310
    cut_proc.top_min_1310 = record.top_min_1310; cut_proc.bot_lsa_1310 = record.bot_lsa_1310
    cut_proc.bot_max_1310 = record.bot_max_1310; cut_proc.bot_min_1310 = record.bot_min_1310
    cut_proc.avg_lsa_1310 = record.avg_lsa_1310; cut_proc.avg_max_1310 = record.avg_max_1310

    cut_proc.top_lsa_1550 = record.top_lsa_1550; cut_proc.top_max_1550 = record.top_max_1550
    cut_proc.top_min_1550 = record.top_min_1550; cut_proc.bot_lsa_1550 = record.bot_lsa_1550
    cut_proc.bot_max_1550 = record.bot_max_1550; cut_proc.bot_min_1550 = record.bot_min_1550
    cut_proc.avg_lsa_1550 = record.avg_lsa_1550; cut_proc.avg_max_1550 = record.avg_max_1550

    cut_proc.top_lsa_1625 = record.top_lsa_1625; cut_proc.top_max_1625 = record.top_max_1625
    cut_proc.top_min_1625 = record.top_min_1625; cut_proc.bot_lsa_1625 = record.bot_lsa_1625
    cut_proc.bot_max_1625 = record.bot_max_1625; cut_proc.bot_min_1625 = record.bot_min_1625
    cut_proc.avg_lsa_1625 = record.avg_lsa_1625; cut_proc.avg_max_1625 = record.avg_max_1625
    cut_proc.avg_min_1625 = record.avg_min_1625

    cut_proc.top_lsa_1383 = record.top_lsa_1383; cut_proc.top_max_1383 = record.top_max_1383
    cut_proc.top_min_1383 = record.top_min_1383; cut_proc.bot_lsa_1383 = record.bot_lsa_1383
    cut_proc.bot_max_1383 = record.bot_max_1383; cut_proc.bot_min_1383 = record.bot_min_1383
    cut_proc.avg_lsa_1383 = record.avg_lsa_1383; cut_proc.avg_max_1383 = record.avg_max_1383
    cut_proc.avg_min_1383 = record.avg_min_1383

    cut_proc.unimax_1310 = max(record.top_max_1310, record.bot_max_1310)
    cut_proc.unimax_1383 = max(record.top_max_1383, record.bot_max_1383)
    cut_proc.unimax_1550 = max(record.top_max_1550, record.bot_max_1550)
    cut_proc.unimax_1625 = max(record.top_max_1625, record.bot_max_1625)

    cut_proc.unimin_1310 = min(record.top_min_1310, record.bot_min_1310)
    cut_proc.unimin_1383 = min(record.top_min_1383, record.bot_min_1383)
    cut_proc.unimin_1550 = min(record.top_min_1550, record.bot_min_1550)
    cut_proc.unimin_1625 = min(record.top_min_1625, record.bot_min_1625)

    if otdr_data:
        cut_proc.atnuni_1310 = max((r.attnu_1310 for r in otdr_data), default=0.0)
        cut_proc.atnuni_1383 = max((r.attnu_1383 for r in otdr_data), default=0.0)
        cut_proc.atnuni_1550 = max((r.attnu_1550 for r in otdr_data), default=0.0)
        cut_proc.atnuni_1625 = max((r.attnu_1625 for r in otdr_data), default=0.0)
        cut_proc.mfduni_1310 = max((r.mfd_1310 for r in otdr_data), default=0.0)
        cut_proc.mfduni_1383 = max((r.mfd_1383 for r in otdr_data), default=0.0)
        cut_proc.mfduni_1550 = max((r.mfd_1550 for r in otdr_data), default=0.0)
        cut_proc.mfduni_1625 = max((r.mfd_1625 for r in otdr_data), default=0.0)

    cut_proc.otdr_no = otdr_no
    cut_proc.operator = operator


def _merge_instructions(a: str, b: str) -> str:
    parts = [p.strip() for p in ((a or "") + "," + (b or "")).split(",") if p.strip()]
    return ",".join(dict.fromkeys(parts))  # preserve order, deduplicate


def process(
    otdr_record_data: List[OtdrRecord],
    cuts: List[CutInstruction],
    master: MasterThresholds,
    otdr_no: str = "",
    operator: str = "",
) -> List[CutInstructionProcess]:
    """Cluster cuts per fibre, decide PASS/REW/FAIL, build CutInstructionProcess list."""
    result: List[CutInstructionProcess] = []
    sr_no = 0

    grouped: dict[str, List[CutInstruction]] = {}
    for c in cuts:
        grouped.setdefault(c.fibre_id, [])
        grouped[c.fibre_id].append(c)

    for fibre_id, lst in grouped.items():
        lst.sort(key=lambda x: x.position)
        fibre_results: List[CutInstructionProcess] = []
        fibre_otdr_data = [r for r in otdr_record_data if r.fibre_id == fibre_id]

        spike_cuts = sorted([x for x in lst if x.is_step], key=lambda x: x.step_type)
        work_list = spike_cuts if spike_cuts else lst

        start = 0
        while start < len(work_list):
            end = start
            while (end + 1 < len(work_list) and
                   work_list[end + 1].position - work_list[end].position <= master.StandardLen):
                end += 1

            first = work_list[start]
            last = work_list[end]
            rec_attn = first.attenuation_record or AttenuationRecord()

            is_fail = False
            remaining = first.fibre_length - first.position
            last_remaining = last.fibre_length - last.position

            if spike_cuts and first.position == last.position and start == end:
                if first.position >= master.StandardLen:
                    pass  # bobbin available
                else:
                    is_fail = remaining < master.StandardLen or last_remaining < master.StandardLen
            else:
                if not spike_cuts:
                    is_fail = remaining < master.StandardLen and last_remaining < master.StandardLen
                else:
                    is_fail = remaining < master.StandardLen or last_remaining < master.StandardLen

            if last_remaining < master.StandardLen:
                last_remaining = last.fibre_length
            else:
                last_remaining = last.position + master.CuttingLen

            if first.position < master.StandardLen:
                first.position = 0

            start_cut = first.position - master.CuttingLen
            if start_cut <= 0:
                start_cut = 0
            if last_remaining >= last.fibre_length:
                last_remaining = last.fibre_length

            cut_instruction = f"Cut from {start_cut:.3f} km to {last_remaining:.3f} ({first.reason}:{first.value}),"

            if spike_cuts and first.step_type == "1550":
                cp = CutInstructionProcess(
                    fibre_id=fibre_id,
                    fiber_length=first.fibre_length,
                    reason=first.reason,
                    nc_clause=first.nc_clause,
                    position=first.position,
                    st15size=float(first.value) if first.value else 0.0,
                    cutting_instruction="Rewind Whole Length",
                    status="REW",
                )
            else:
                st13 = 0.0
                spk = 0.0
                if first.is_step and "STEP" in first.reason.upper() and first.step_type == "1310":
                    try:
                        st13 = float(first.value)
                    except ValueError:
                        pass
                if first.is_step and "SPIKE" in first.reason:
                    try:
                        spk = float(first.value)
                    except ValueError:
                        pass

                cp = CutInstructionProcess(
                    fibre_id=fibre_id,
                    fiber_length=first.fibre_length,
                    reason=first.reason,
                    nc_clause=first.nc_clause,
                    st13size=st13,
                    spike=spk,
                    position=first.position,
                    cutting_instruction="" if first.status == "PASS" else cut_instruction,
                    status="FAIL" if is_fail else first.status,
                )

            _fill_attenuation(cp, rec_attn, fibre_otdr_data, otdr_no, operator)
            fibre_results.append(cp)
            start = end + 1

        # Final segment validation
        fibre_fail = True
        if fibre_results:
            total_len = fibre_results[0].fiber_length
            positions = sorted(r.position for r in fibre_results)
            positions = [0.0] + positions + [total_len]
            for j in range(len(positions) - 1):
                if positions[j + 1] - positions[j] >= master.StandardLen:
                    fibre_fail = False
                    for item in fibre_results:
                        if item.status == "FAIL":
                            item.status = "REW"
                    break

        for fr in fibre_results:
            sr_no += 1
            fr.sr_no = sr_no
            if fibre_fail:
                fr.status = "FAIL"

            existing = next((r for r in result if r.fibre_id == fr.fibre_id), None)
            if existing:
                if not fibre_fail:
                    existing.cutting_instruction = _merge_instructions(
                        existing.cutting_instruction, fr.cutting_instruction
                    )
                    if "CUT" in (existing.cutting_instruction or "").upper():
                        existing.status = "REW"
                        fr.status = "REW"
                else:
                    existing.status = "FAIL"
            else:
                result.append(fr)

    # Clean up double commas
    for r in result:
        if r.cutting_instruction:
            while ",," in r.cutting_instruction:
                r.cutting_instruction = r.cutting_instruction.replace(",,", ",")

    return result
