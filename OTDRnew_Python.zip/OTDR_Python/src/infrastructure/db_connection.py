"""
Database connection factory.
- Prefers PostgreSQL (psycopg2) when available.
- Automatically falls back to SQLite (built-in, zero install) otherwise.
"""
from __future__ import annotations
import json
import os
import sqlite3

# Try to import psycopg2; if missing, fall back to SQLite
try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    _PSYCOPG2_AVAILABLE = True
except ImportError:
    _PSYCOPG2_AVAILABLE = False

# ── connection config ──────────────────────────────────────────────────────
_pg_connection_string: str = "postgresql://postgres:postgres@localhost:5432/db_otdr"
_sqlite_path: str = ""          # set after config load


def load_connection_string(config_path: str) -> None:
    """Load connection string from appsettings.json and resolve SQLite path."""
    global _pg_connection_string, _sqlite_path
    config_dir = os.path.dirname(config_path)
    _sqlite_path = os.path.join(config_dir, "otdr.db")   # default SQLite file

    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        cs = cfg.get("ConnectionStrings", {}).get("PostgreSQL", "")
        if cs:
            _pg_connection_string = cs
        sqlite_override = cfg.get("ConnectionStrings", {}).get("SQLite", "")
        if sqlite_override:
            _sqlite_path = sqlite_override


def is_postgres() -> bool:
    return _PSYCOPG2_AVAILABLE


def get_connection_string() -> str:
    return _pg_connection_string if _PSYCOPG2_AVAILABLE else f"sqlite:///{_sqlite_path}"


# ── public helpers ─────────────────────────────────────────────────────────

def create_connection():
    """Return a live DB connection (psycopg2 or sqlite3)."""
    if _PSYCOPG2_AVAILABLE:
        return psycopg2.connect(_pg_connection_string)
    else:
        conn = sqlite3.connect(_sqlite_path)
        conn.row_factory = sqlite3.Row
        return conn


def execute_script(sql: str) -> None:
    """Run a multi-statement DDL script (used by auto-create)."""
    conn = create_connection()
    if _PSYCOPG2_AVAILABLE:
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute(sql)
        cur.close()
    else:
        conn.executescript(sql)
    conn.close()


def dict_rows(cursor) -> list[dict]:
    """Convert cursor rows to list of plain dicts regardless of DB driver."""
    if _PSYCOPG2_AVAILABLE:
        return [dict(r) for r in cursor.fetchall()]
    else:
        return [dict(r) for r in cursor.fetchall()]
