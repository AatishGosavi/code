"""
OtdrParser — converted from C# frmotdr.ParseFileAsync + Analyze + Process methods.
Pure Python, no UI dependencies.
"""
from __future__ import annotations
import re
import os
import time
from typing import List, Tuple, Dict, Optional

from src.domain.models import (
    OtdrRecord, SpikeRecord, CutInstruction, CutInstructionProcess,
    AttenuationRecord, FiberRecord,
)
from src.domain.master_thresholds import MasterThresholds
from src.domain.mapper import to_fiber_record


# ---------------------------------------------------------------------------
# File readiness helpers
# ---------------------------------------------------------------------------

def is_file_ready(file_path: str) -> bool:
    try:
        initial = os.path.getsize(file_path)
        time.sleep(0.5)
        if os.path.getsize(file_path) != initial:
            return False
        with open(file_path, "r", encoding="utf-8", errors="ignore"):
            pass
        return True
    except Exception:
        return False


def is_file_locked(file_path: str) -> bool:
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore"):
            pass
        return False
    except (IOError, PermissionError):
        return True


def contains_end_time(file_path: str) -> bool:
    try:
        has_length = False
        has_end = False
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                l = line.strip().upper()
                if not has_length and l.startswith("LENGTH FROM BE"):
                    has_length = True
                if not has_end and (l.startswith("END TIME:") or l.startswith("END TIME :")):
                    has_end = True
                if has_length and has_end:
                    return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# Main parser
# ---------------------------------------------------------------------------

def parse_file(
    file_path: str,
    master_thresholds: MasterThresholds,
    plant: str = "",
    otdr_no: str = "",
) -> Tuple[List[OtdrRecord], List[CutInstruction], List[SpikeRecord]]:
    """
    Parse a single .rpt file. Returns (records, cuts, spikes).
    Converted from C# ParseFileAsync in frmotdr.cs.
    """
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    records: List[OtdrRecord] = []
    cuts: List[CutInstruction] = []
    spikes: List[SpikeRecord] = []

    fibre_id: str = ""
    fiber_length: float = 0.0
    fiber_length_be: float = 0.0
    avg_lsa_1310 = avg_lsa_1550 = avg_lsa_1383 = avg_lsa_1625 = 0.0

    top1310: Dict[int, float] = {}; bot1310: Dict[int, float] = {}; avg1310: Dict[int, float] = {}
    top1550: Dict[int, float] = {}; bot1550: Dict[int, float] = {}; avg1550: Dict[int, float] = {}
    top1383: Dict[int, float] = {}; bot1383: Dict[int, float] = {}; avg1383: Dict[int, float] = {}
    top1625: Dict[int, float] = {}; bot1625: Dict[int, float] = {}; avg1625: Dict[int, float] = {}
    dist_position: Dict[int, float] = {}

    current_block: Optional[str] = None
    cnt_count = 0
    record = AttenuationRecord()

    def _last_float(s: str) -> Optional[float]:
        parts = s.split()
        if not parts:
            return None
        try:
            return float(parts[-1])
        except ValueError:
            return None

    i = 0
    while i < len(lines):
        raw = lines[i]
        line = raw.strip()
        i += 1
        if not line:
            continue

        # START TIME
        if line.upper().startswith("START TIME:"):
            record.test_time = line[len("START TIME:"):].strip()
            continue

        # Attenuation scalar values
        uline = line.upper()
        v = _last_float(line)
        if v is not None:
            if uline.startswith("TOP LSA ATTENUATION 1310"):  record.top_lsa_1310 = v
            elif uline.startswith("TOP MAX ATTENUATION 1310"): record.top_max_1310 = v
            elif uline.startswith("TOP MIN ATTENUATION 1310"): record.top_min_1310 = v
            elif uline.startswith("BOT LSA ATTENUATION 1310"): record.bot_lsa_1310 = v
            elif uline.startswith("BOT MAX ATTENUATION 1310"): record.bot_max_1310 = v
            elif uline.startswith("BOT MIN ATTENUATION 1310"): record.bot_min_1310 = v
            elif uline.startswith("AVG LSA ATTENUATION 1310"): record.avg_lsa_1310 = v; avg_lsa_1310 = v
            elif uline.startswith("AVG MAX ATTENUATION 1310"): record.avg_max_1310 = v
            elif uline.startswith("AVG MIN ATTENUATION 1310"): record.avg_min_1310 = v

            elif uline.startswith("TOP LSA ATTENUATION 1550"): record.top_lsa_1550 = v
            elif uline.startswith("TOP MAX ATTENUATION 1550"): record.top_max_1550 = v
            elif uline.startswith("TOP MIN ATTENUATION 1550"): record.top_min_1550 = v
            elif uline.startswith("BOT LSA ATTENUATION 1550"): record.bot_lsa_1550 = v
            elif uline.startswith("BOT MAX ATTENUATION 1550"): record.bot_max_1550 = v
            elif uline.startswith("BOT MIN ATTENUATION 1550"): record.bot_min_1550 = v
            elif uline.startswith("AVG LSA ATTENUATION 1550"): record.avg_lsa_1550 = v; avg_lsa_1550 = v
            elif uline.startswith("AVG MAX ATTENUATION 1550"): record.avg_max_1550 = v
            elif uline.startswith("AVG MIN ATTENUATION 1550"): record.avg_min_1550 = v

            elif uline.startswith("TOP LSA ATTENUATION 1383"): record.top_lsa_1383 = v
            elif uline.startswith("TOP MAX ATTENUATION 1383"): record.top_max_1383 = v
            elif uline.startswith("TOP MIN ATTENUATION 1383"): record.top_min_1383 = v
            elif uline.startswith("BOT LSA ATTENUATION 1383"): record.bot_lsa_1383 = v
            elif uline.startswith("BOT MAX ATTENUATION 1383"): record.bot_max_1383 = v
            elif uline.startswith("BOT MIN ATTENUATION 1383"): record.bot_min_1383 = v
            elif uline.startswith("AVG LSA ATTENUATION 1383"): record.avg_lsa_1383 = v; avg_lsa_1383 = v
            elif uline.startswith("AVG MAX ATTENUATION 1383"): record.avg_max_1383 = v
            elif uline.startswith("AVG MIN ATTENUATION 1383"): record.avg_min_1383 = v

            elif uline.startswith("TOP LSA ATTENUATION 1625"): record.top_lsa_1625 = v
            elif uline.startswith("TOP MAX ATTENUATION 1625"): record.top_max_1625 = v
            elif uline.startswith("TOP MIN ATTENUATION 1625"): record.top_min_1625 = v
            elif uline.startswith("BOT LSA ATTENUATION 1625"): record.bot_lsa_1625 = v
            elif uline.startswith("BOT MAX ATTENUATION 1625"): record.bot_max_1625 = v
            elif uline.startswith("BOT MIN ATTENUATION 1625"): record.bot_min_1625 = v
            elif uline.startswith("AVG LSA ATTENUATION 1625"): record.avg_lsa_1625 = v; avg_lsa_1625 = v
            elif uline.startswith("AVG MAX ATTENUATION 1625"): record.avg_max_1625 = v
            elif uline.startswith("AVG MIN ATTENUATION 1625"): record.avg_min_1625 = v

        # FIBER ID
        if uline.startswith("FIBER ID"):
            fibre_id = line[len("FIBER ID"):].strip().split()[0] if line[len("FIBER ID"):].strip() else ""
            continue

        # FIBRE LENGTH
        if uline.startswith("FIBRE LENGTH") or uline.startswith("FIBER LENGTH"):
            fv = _last_float(line)
            if fv is not None:
                fiber_length = fv
            continue

        # LENGTH FROM BE
        if uline.startswith("LENGTH FROM BE"):
            fv = _last_float(line)
            if fv is not None:
                fiber_length_be = fv
            continue

        # STEP SIZE AT
        if uline.startswith("STEP SIZE AT"):
            m = re.search(r"STEP SIZE AT\s+(\d+)", uline)
            spike_type = int(m.group(1)) if m else 0
            while i < len(lines):
                data = lines[i].strip()
                i += 1
                if not data:
                    continue
                du = data.upper()
                if du.startswith("SPIKE (REFLECTANCE)") or du.startswith("STEP SIZE AT") or du.startswith("TOP SECTIONAL LOSS"):
                    i -= 1
                    break
                parts = data.split()
                if len(parts) >= 2:
                    try:
                        loss, pos = float(parts[0]), float(parts[1])
                        spikes.append(SpikeRecord(
                            fibre_id=fibre_id, barcode_id=fibre_id,
                            type="Step", spike_type=spike_type,
                            spike_value=loss, spike_position=pos,
                            plant=plant, otdr_no=otdr_no,
                        ))
                    except ValueError:
                        pass
            continue

        # SPIKE (REFLECTANCE)
        if uline.startswith("SPIKE (REFLECTANCE)"):
            tokens = line.split()
            spike_type = 0
            for t in reversed(tokens):
                if t.isdigit():
                    spike_type = int(t)
                    break
            while i < len(lines):
                data = lines[i].strip()
                i += 1
                if not data:
                    continue
                du = data.upper()
                if du.startswith("STEP SIZE AT") or du.startswith("TOP SECTIONAL LOSS"):
                    i -= 1
                    break
                parts = data.split()
                if len(parts) >= 2:
                    try:
                        val, pos = float(parts[0]), float(parts[1])
                        spikes.append(SpikeRecord(
                            fibre_id=fibre_id, barcode_id=fibre_id,
                            type="Reflectance", spike_type=spike_type,
                            spike_value=val, spike_position=pos,
                            plant=plant, otdr_no=otdr_no,
                        ))
                    except ValueError:
                        pass
            continue

        # Sectional loss block headers
        block_map = {
            "TOP SECTIONAL LOSS (1310)": "TOP1310",
            "BOT SECTIONAL LOSS (1310)": "BOT1310",
            "AVG SECTIONAL LOSS (1310)": "AVG1310",
            "TOP SECTIONAL LOSS (1383)": "TOP1383",
            "BOT SECTIONAL LOSS (1383)": "BOT1383",
            "AVG SECTIONAL LOSS (1383)": "AVG1383",
            "TOP SECTIONAL LOSS (1550)": "TOP1550",
            "BOT SECTIONAL LOSS (1550)": "BOT1550",
            "AVG SECTIONAL LOSS (1550)": "AVG1550",
            "TOP SECTIONAL LOSS (1625)": "TOP1625",
            "BOT SECTIONAL LOSS (1625)": "BOT1625",
            "AVG SECTIONAL LOSS (1625)": "AVG1625",
        }
        matched_block = next((v for k, v in block_map.items() if uline.startswith(k)), None)
        if matched_block:
            current_block = matched_block
            cnt_count = 0
            continue

        # Data inside a sectional loss block
        if current_block:
            parts = line.split()
            if len(parts) >= 2:
                try:
                    loss, dist = float(parts[0]), float(parts[1])
                    if current_block == "AVG1310":
                        dist_position[cnt_count] = dist
                    target = {
                        "TOP1310": top1310, "BOT1310": bot1310, "AVG1310": avg1310,
                        "TOP1383": top1383, "BOT1383": bot1383, "AVG1383": avg1383,
                        "TOP1550": top1550, "BOT1550": bot1550, "AVG1550": avg1550,
                        "TOP1625": top1625, "BOT1625": bot1625, "AVG1625": avg1625,
                    }.get(current_block)
                    if target is not None:
                        target[cnt_count] = loss
                    cnt_count += 1
                except ValueError:
                    pass

    # Build OtdrRecord list
    max_count = max(
        (len(d) for d in [top1310, bot1310, avg1310, top1383, bot1383, avg1383,
                           top1550, bot1550, avg1550] if d),
        default=0,
    )

    for cnt in range(max_count):
        rev1310 = len(bot1310) - cnt - 1
        rev1383 = len(bot1383) - cnt - 1
        rev1550 = len(bot1550) - cnt - 1
        rev1625 = len(bot1625) - cnt - 1

        rec = OtdrRecord(
            fibre_id=fibre_id,
            fiber_length=fiber_length,
            fiber_length_be=fiber_length_be,
            dist_position=dist_position.get(cnt, 0.0),
            length_mm=dist_position.get(cnt, 0.0) * 1000,

            top_sec_loss_1310=top1310.get(cnt, 0.0),
            bot_sec_loss_1310=bot1310.get(rev1310, 0.0),
            avg_sec_loss_1310=avg1310.get(cnt, 0.0),

            top_sec_loss_1383=top1383.get(cnt, 0.0),
            bot_sec_loss_1383=bot1383.get(rev1383, 0.0),
            avg_sec_loss_1383=avg1383.get(cnt, 0.0),

            top_sec_loss_1550=top1550.get(cnt, 0.0),
            bot_sec_loss_1550=bot1550.get(rev1550, 0.0),
            avg_sec_loss_1550=avg1550.get(cnt, 0.0),

            top_sec_loss_1625=top1625.get(cnt, 0.0),
            bot_sec_loss_1625=bot1625.get(rev1625, 0.0),
            avg_sec_loss_1625=avg1625.get(cnt, 0.0),

            avg_lsa_1310=avg_lsa_1310,
            avg_lsa_1383=avg_lsa_1383,
            avg_lsa_1550=avg_lsa_1550,
            avg_lsa_1625=avg_lsa_1625,
            attenuation_record=record,
        )

        if rec.avg_sec_loss_1310 != 0:
            rec.attnu_1310 = abs(rec.avg_lsa_1310 - rec.avg_sec_loss_1310)
        if rec.avg_sec_loss_1383 != 0:
            rec.attnu_1383 = abs(rec.avg_lsa_1383 - rec.avg_sec_loss_1383)
        if rec.avg_sec_loss_1550 != 0:
            rec.attnu_1550 = abs(rec.avg_lsa_1550 - rec.avg_sec_loss_1550)
        if rec.avg_sec_loss_1625 != 0:
            rec.attnu_1625 = abs(rec.avg_lsa_1625 - rec.avg_sec_loss_1625)

        if rec.bot_sec_loss_1310 != 0 and rec.top_sec_loss_1310 != 0:
            rec.mfd_1310 = abs(rec.top_sec_loss_1310 - rec.bot_sec_loss_1310)
        if rec.bot_sec_loss_1383 != 0 and rec.top_sec_loss_1383 != 0:
            rec.mfd_1383 = abs(rec.top_sec_loss_1383 - rec.bot_sec_loss_1383)
        if rec.bot_sec_loss_1550 != 0 and rec.top_sec_loss_1550 != 0:
            rec.mfd_1550 = abs(rec.top_sec_loss_1550 - rec.bot_sec_loss_1550)
        if rec.bot_sec_loss_1625 != 0 and rec.top_sec_loss_1625 != 0:
            rec.mfd_1625 = abs(rec.top_sec_loss_1625 - rec.bot_sec_loss_1625)

        rec.ha_1310 = rec.avg_sec_loss_1310 > master_thresholds.AT1310
        rec.ha_1383 = rec.avg_sec_loss_1383 > master_thresholds.AT1383
        rec.ha_1550 = rec.avg_sec_loss_1550 > master_thresholds.AT1550

        records.append(rec)

    return records, cuts, spikes
