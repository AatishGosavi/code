"""
FiberRecordRepository — PostgreSQL only.
SQL Server MERGE → PostgreSQL INSERT … ON CONFLICT DO UPDATE.
"""
from __future__ import annotations
import os
from datetime import date
from typing import List

from psycopg2.extras import RealDictCursor

from src.domain.models import FiberRecord, OperatorData, Instrument
from src.infrastructure.db_connection import create_connection


# ---------------------------------------------------------------------------
# Flag helper
# ---------------------------------------------------------------------------

def _read_insert_flag(config_path: str) -> bool:
    """
    Return True only when an UNCOMMENTED line InsertToServerDBTables=1 exists.
    A line starting with '#' is always a comment → disabled.

    Examples:
      #InsertToServerDBTables=1  → disabled (comment)
      InsertToServerDBTables=0   → disabled
      InsertToServerDBTables=1   → ENABLED ✅
    """
    if not os.path.exists(config_path):
        return False
    with open(config_path, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if stripped.lower().startswith("inserttoserverdbtables"):
                parts = stripped.split("=", 1)
                if len(parts) == 2:
                    try:
                        return int(parts[1].strip()) == 1
                    except ValueError:
                        pass
    return False


# ---------------------------------------------------------------------------
# Upsert SQL  (INSERT … ON CONFLICT DO UPDATE — PostgreSQL equivalent of MERGE)
# ---------------------------------------------------------------------------

_UPSERT_SQL = """
INSERT INTO fiber_records (
    fiber_id, test_date_and_time, optical_length, status, reason, remarks,
    avg_lsa_1310, avg_lsa_1550, avg_lsa_1625, avg_lsa_1383,
    avg_max_1310, avg_max_1550, avg_max_1625, avg_max_1383,
    uni_max_1310, uni_max_1550, uni_max_1625, uni_max_1383,
    uni_min_1310, uni_min_1550, uni_min_1625, uni_min_1383,
    top_lsa_1310, top_lsa_1550, top_lsa_1625, top_lsa_1383,
    bot_lsa_1310, bot_lsa_1550, bot_lsa_1625, bot_lsa_1383,
    atnuni_1310,  atnuni_1550,  atnuni_1625,  atnuni_1383,
    mfduni_1310,  mfduni_1550,  mfduni_1625,  mfduni_1383,
    st13size, st15size, spike,
    operator, machine_id, nc_cause,
    created_date, updated_date
) VALUES (
    %(fiber_id)s, %(test_date_and_time)s, %(optical_length)s, %(status)s,
    %(reason)s, %(remarks)s,
    %(avg_lsa_1310)s, %(avg_lsa_1550)s, %(avg_lsa_1625)s, %(avg_lsa_1383)s,
    %(avg_max_1310)s, %(avg_max_1550)s, %(avg_max_1625)s, %(avg_max_1383)s,
    %(uni_max_1310)s, %(uni_max_1550)s, %(uni_max_1625)s, %(uni_max_1383)s,
    %(uni_min_1310)s, %(uni_min_1550)s, %(uni_min_1625)s, %(uni_min_1383)s,
    %(top_lsa_1310)s, %(top_lsa_1550)s, %(top_lsa_1625)s, %(top_lsa_1383)s,
    %(bot_lsa_1310)s, %(bot_lsa_1550)s, %(bot_lsa_1625)s, %(bot_lsa_1383)s,
    %(atnuni_1310)s,  %(atnuni_1550)s,  %(atnuni_1625)s,  %(atnuni_1383)s,
    %(mfduni_1310)s,  %(mfduni_1550)s,  %(mfduni_1625)s,  %(mfduni_1383)s,
    %(st13size)s, %(st15size)s, %(spike)s,
    %(operator)s, %(machine_id)s, %(nc_cause)s,
    NOW(), NOW()
)
ON CONFLICT (fiber_id) DO UPDATE SET
    test_date_and_time = EXCLUDED.test_date_and_time,
    optical_length     = EXCLUDED.optical_length,
    status             = EXCLUDED.status,
    reason             = EXCLUDED.reason,
    remarks            = EXCLUDED.remarks,
    avg_lsa_1310 = EXCLUDED.avg_lsa_1310, avg_lsa_1550 = EXCLUDED.avg_lsa_1550,
    avg_lsa_1625 = EXCLUDED.avg_lsa_1625, avg_lsa_1383 = EXCLUDED.avg_lsa_1383,
    avg_max_1310 = EXCLUDED.avg_max_1310, avg_max_1550 = EXCLUDED.avg_max_1550,
    avg_max_1625 = EXCLUDED.avg_max_1625, avg_max_1383 = EXCLUDED.avg_max_1383,
    uni_max_1310 = EXCLUDED.uni_max_1310, uni_max_1550 = EXCLUDED.uni_max_1550,
    uni_max_1625 = EXCLUDED.uni_max_1625, uni_max_1383 = EXCLUDED.uni_max_1383,
    uni_min_1310 = EXCLUDED.uni_min_1310, uni_min_1550 = EXCLUDED.uni_min_1550,
    uni_min_1625 = EXCLUDED.uni_min_1625, uni_min_1383 = EXCLUDED.uni_min_1383,
    top_lsa_1310 = EXCLUDED.top_lsa_1310, top_lsa_1550 = EXCLUDED.top_lsa_1550,
    top_lsa_1625 = EXCLUDED.top_lsa_1625, top_lsa_1383 = EXCLUDED.top_lsa_1383,
    bot_lsa_1310 = EXCLUDED.bot_lsa_1310, bot_lsa_1550 = EXCLUDED.bot_lsa_1550,
    bot_lsa_1625 = EXCLUDED.bot_lsa_1625, bot_lsa_1383 = EXCLUDED.bot_lsa_1383,
    atnuni_1310  = EXCLUDED.atnuni_1310,  atnuni_1550  = EXCLUDED.atnuni_1550,
    atnuni_1625  = EXCLUDED.atnuni_1625,  atnuni_1383  = EXCLUDED.atnuni_1383,
    mfduni_1310  = EXCLUDED.mfduni_1310,  mfduni_1550  = EXCLUDED.mfduni_1550,
    mfduni_1625  = EXCLUDED.mfduni_1625,  mfduni_1383  = EXCLUDED.mfduni_1383,
    st13size     = EXCLUDED.st13size,
    st15size     = EXCLUDED.st15size,
    spike        = EXCLUDED.spike,
    operator     = EXCLUDED.operator,
    machine_id   = EXCLUDED.machine_id,
    nc_cause     = EXCLUDED.nc_cause,
    updated_date = NOW();
"""


def _to_params(f: FiberRecord) -> dict:
    return {
        "fiber_id": f.fiber_id,
        "test_date_and_time": f.test_date_and_time,
        "optical_length": f.optical_length,
        "status": f.status,
        "reason": f.reason,
        "remarks": f.remarks,
        "avg_lsa_1310": f.avg_lsa_1310, "avg_lsa_1550": f.avg_lsa_1550,
        "avg_lsa_1625": f.avg_lsa_1625, "avg_lsa_1383": f.avg_lsa_1383,
        "avg_max_1310": f.avg_max_1310, "avg_max_1550": f.avg_max_1550,
        "avg_max_1625": f.avg_max_1625, "avg_max_1383": f.avg_max_1383,
        "uni_max_1310": f.uni_max_1310, "uni_max_1550": f.uni_max_1550,
        "uni_max_1625": f.uni_max_1625, "uni_max_1383": f.uni_max_1383,
        "uni_min_1310": f.uni_min_1310, "uni_min_1550": f.uni_min_1550,
        "uni_min_1625": f.uni_min_1625, "uni_min_1383": f.uni_min_1383,
        "top_lsa_1310": f.top_lsa_1310, "top_lsa_1550": f.top_lsa_1550,
        "top_lsa_1625": f.top_lsa_1625, "top_lsa_1383": f.top_lsa_1383,
        "bot_lsa_1310": f.bot_lsa_1310, "bot_lsa_1550": f.bot_lsa_1550,
        "bot_lsa_1625": f.bot_lsa_1625, "bot_lsa_1383": f.bot_lsa_1383,
        "atnuni_1310":  f.atnuni_1310,  "atnuni_1550":  f.atnuni_1550,
        "atnuni_1625":  f.atnuni_1625,  "atnuni_1383":  f.atnuni_1383,
        "mfduni_1310":  f.mfduni_1310,  "mfduni_1550":  f.mfduni_1550,
        "mfduni_1625":  f.mfduni_1625,  "mfduni_1383":  f.mfduni_1383,
        "st13size":  f.st13size  or 0,
        "st15size":  f.st15size  or 0,
        "spike":     f.spike     or 0,
        "operator":  f.operator,
        "machine_id": f.machine_id,
        "nc_cause":  f.nc_cause,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def insert_fiber_records(fiber_records: List[FiberRecord], config_path: str) -> str:
    """
    Upsert fiber records into PostgreSQL fiber_records table.
    Only runs when InsertToServerDBTables=1 (uncommented) in config.txt.
    """
    if not _read_insert_flag(config_path):
        return "InsertToServerDBTables is disabled in config.txt — skipping DB write."

    try:
        conn = create_connection()
        conn.autocommit = False
        cur = conn.cursor()
        for f in fiber_records:
            cur.execute(_UPSERT_SQL, _to_params(f))
        conn.commit()
        cur.close()
        conn.close()
        return f"Saved {len(fiber_records)} record(s) to fiber_records."
    except Exception as ex:
        return f"DB error: {ex}"


def get_fiber_records_by_date(from_date: date, to_date: date) -> List[dict]:
    sql = """
        SELECT
            fiber_id            AS "Fiber ID",
            test_date_and_time  AS "Test Date and Time",
            optical_length      AS "Optical Length",
            status              AS "STATUS",
            reason              AS "REASON",
            remarks             AS "REMARKS",
            avg_lsa_1310        AS "Avg ATN1310",
            avg_lsa_1550        AS "Avg ATN1550",
            avg_lsa_1625        AS "Avg ATN1625",
            avg_lsa_1383        AS "Avg ATN1383",
            avg_max_1310        AS "AvgMax1310",
            avg_max_1550        AS "AvgMax1550",
            avg_max_1625        AS "AvgMax1625",
            avg_max_1383        AS "AvgMax1383",
            uni_max_1310        AS "Max ATN1310",
            uni_max_1550        AS "Max ATN1550",
            uni_max_1625        AS "Max ATN1625",
            uni_max_1383        AS "Max ATN1383",
            uni_min_1310        AS "Min ATN1310",
            uni_min_1550        AS "Min ATN1550",
            uni_min_1625        AS "Min ATN1625",
            uni_min_1383        AS "Min ATN1383",
            top_lsa_1310        AS "TOP LSA ATTENUATION 1310",
            top_lsa_1550        AS "TOP LSA ATTENUATION 1550",
            top_lsa_1625        AS "TOP LSA ATTENUATION 1625",
            top_lsa_1383        AS "TOP LSA ATTENUATION 1383",
            bot_lsa_1310        AS "BOT LSA ATTENUATION 1310",
            bot_lsa_1550        AS "BOT LSA ATTENUATION 1550",
            bot_lsa_1625        AS "BOT LSA ATTENUATION 1625",
            bot_lsa_1383        AS "BOT LSA ATTENUATION 1383",
            atnuni_1310         AS "ATNUNI1310",
            atnuni_1550         AS "ATNUNI1550",
            atnuni_1625         AS "ATNUNI1625",
            atnuni_1383         AS "ATNUNI1383",
            mfduni_1310         AS "MFDUNI1310",
            mfduni_1550         AS "MFDUNI1550",
            mfduni_1625         AS "MFDUNI1625",
            mfduni_1383         AS "MFDUNI1383",
            st13size, st15size, spike,
            operator            AS "OPERATOR",
            machine_id          AS "Machine ID",
            created_date        AS "CreatedDate",
            updated_date        AS "UpdatedDate"
        FROM fiber_records
        WHERE created_date::date BETWEEN %(from_date)s AND %(to_date)s
        ORDER BY created_date DESC;
    """
    conn = create_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute(sql, {"from_date": from_date, "to_date": to_date})
    rows = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    return rows


def get_fiber_records_by_date_operator(
    from_date: date, to_date: date, operator: str, hourly_wise: bool = False
) -> List[dict]:
    if hourly_wise:
        sql = """
            SELECT
                operator,
                created_date::date AS "TestDate",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 0  THEN 1 ELSE 0 END) AS "0AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 1  THEN 1 ELSE 0 END) AS "1AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 2  THEN 1 ELSE 0 END) AS "2AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 3  THEN 1 ELSE 0 END) AS "3AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 4  THEN 1 ELSE 0 END) AS "4AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 5  THEN 1 ELSE 0 END) AS "5AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 6  THEN 1 ELSE 0 END) AS "6AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 7  THEN 1 ELSE 0 END) AS "7AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 8  THEN 1 ELSE 0 END) AS "8AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 9  THEN 1 ELSE 0 END) AS "9AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 10 THEN 1 ELSE 0 END) AS "10AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 11 THEN 1 ELSE 0 END) AS "11AM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 12 THEN 1 ELSE 0 END) AS "12PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 13 THEN 1 ELSE 0 END) AS "1PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 14 THEN 1 ELSE 0 END) AS "2PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 15 THEN 1 ELSE 0 END) AS "3PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 16 THEN 1 ELSE 0 END) AS "4PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 17 THEN 1 ELSE 0 END) AS "5PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 18 THEN 1 ELSE 0 END) AS "6PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 19 THEN 1 ELSE 0 END) AS "7PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 20 THEN 1 ELSE 0 END) AS "8PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 21 THEN 1 ELSE 0 END) AS "9PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 22 THEN 1 ELSE 0 END) AS "10PM",
                SUM(CASE WHEN EXTRACT(HOUR FROM created_date) = 23 THEN 1 ELSE 0 END) AS "11PM"
            FROM fiber_records
            WHERE created_date::date BETWEEN %(from_date)s AND %(to_date)s
            GROUP BY operator, created_date::date
            ORDER BY operator, "TestDate";
        """
    else:
        sql = """
            SELECT
                operator,
                created_date::date          AS "TestDate",
                COUNT(*)                    AS "TotalBobbins",
                SUM(CASE WHEN UPPER(status) = 'PASS'   THEN 1 ELSE 0 END) AS "PassCount",
                SUM(CASE WHEN UPPER(status) = 'FAIL'   THEN 1 ELSE 0 END) AS "FailCount",
                SUM(CASE WHEN UPPER(status) = 'REW'    THEN 1 ELSE 0 END) AS "ReworkCount",
                SUM(CASE WHEN UPPER(status) = 'RETEST' THEN 1 ELSE 0 END) AS "RetestCount"
            FROM fiber_records
            WHERE created_date::date BETWEEN %(from_date)s AND %(to_date)s
            GROUP BY operator, created_date::date
            ORDER BY operator, "TestDate";
        """
    conn = create_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute(sql, {"from_date": from_date, "to_date": to_date})
    rows = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    return rows


def get_all_active_operators() -> List[OperatorData]:
    conn = create_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute(
        "SELECT id, operator AS name, active FROM operator_master "
        "WHERE active = TRUE ORDER BY operator;"
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return [OperatorData(id=r["id"], name=r["name"], active=r["active"]) for r in rows]


def get_all_active_instruments() -> List[Instrument]:
    conn = create_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute(
        "SELECT id, instrument AS name, active FROM instrument_master "
        "WHERE active = TRUE ORDER BY instrument;"
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return [Instrument(id=r["id"], name=r["name"], active=r["active"]) for r in rows]
