"""
Database connection factory — PostgreSQL only (psycopg2).
Connection string loaded from config/appsettings.json.
"""
from __future__ import annotations
import json
import os

import psycopg2
from psycopg2.extras import RealDictCursor

_connection_string: str = "postgresql://postgres:postgres@localhost:5432/db_otdr"


def load_connection_string(config_path: str) -> None:
    """Load PostgreSQL connection string from appsettings.json."""
    global _connection_string
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        cs = cfg.get("ConnectionStrings", {}).get("PostgreSQL", "")
        if cs:
            _connection_string = cs


def get_connection_string() -> str:
    return _connection_string


def create_connection():
    """Open and return a new psycopg2 connection."""
    return psycopg2.connect(_connection_string)
